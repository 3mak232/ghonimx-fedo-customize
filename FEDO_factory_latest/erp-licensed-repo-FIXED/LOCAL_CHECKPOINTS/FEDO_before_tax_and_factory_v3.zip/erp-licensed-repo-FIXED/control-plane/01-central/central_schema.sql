-- ============================================================
-- لوحة التحكم المركزية (مشروع Supabase منفصل لوحده، مش مشروع أي عميل)
-- شغّله مرة واحدة على مشروع اللوحة الفاضي من SQL Editor.
-- مفيش هنا أي مفتاح سري بتاع العملاء. التحكم بيتم بأوامر موقّعة (Ed25519) بس.
-- ============================================================
BEGIN;
CREATE EXTENSION IF NOT EXISTS pgcrypto;

-- ---------- 1) فريق اللوحة ----------
-- owner: كل حاجة | support: عملاء واشتراكات وإرسال ترخيص | finance: تسجيل مدفوعات
CREATE TABLE panel_staff(
  user_id uuid PRIMARY KEY REFERENCES auth.users ON DELETE CASCADE,
  name text NOT NULL,
  role text NOT NULL CHECK(role IN('owner','support','finance')),
  active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now()
);

-- الدخول مسموح بس لموظف مفعّل وبجلسة MFA (aal2)
CREATE OR REPLACE FUNCTION is_panel_staff(p_roles text[] DEFAULT ARRAY['owner','support','finance'])
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path=public AS $$
  SELECT COALESCE(auth.jwt()->>'aal','aal1')='aal2'
     AND EXISTS(SELECT 1 FROM panel_staff s WHERE s.user_id=auth.uid() AND s.active AND s.role = ANY(p_roles)) $$;

-- ---------- 2) الخطط ----------
CREATE TABLE plans(
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  code text UNIQUE NOT NULL,
  name text NOT NULL,
  price_monthly numeric(12,2) NOT NULL DEFAULT 0,
  currency text NOT NULL DEFAULT 'EGP',
  max_users int CHECK(max_users IS NULL OR max_users>=0),            -- NULL = بدون حد
  max_branches int CHECK(max_branches IS NULL OR max_branches>=0),
  max_warehouses int CHECK(max_warehouses IS NULL OR max_warehouses>=0),
  modules text[],                                                     -- NULL = كل الوحدات
  storage_mb_warn int,
  active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now()
);

-- ---------- 3) العملاء ----------
CREATE TABLE clients(
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),   -- ده الـCLIENT_ID اللي بيتحط secret عند العميل
  name text NOT NULL,
  contact_name text, phone text, email text,
  project_url text,                -- https://xxxx.supabase.co (للمرجع فقط)
  site_url text,
  license_endpoint text,           -- https://xxxx.supabase.co/functions/v1/license-sync
  code_version text,               -- نسخة كود الواجهة المنشورة
  license_seq bigint NOT NULL DEFAULT 0,
  last_ping jsonb, last_ping_at timestamptz,
  notes text,
  active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now()
);

-- ---------- 4) الاشتراكات (اشتراك واحد حالي لكل عميل) ----------
CREATE TABLE subscriptions(
  client_id uuid PRIMARY KEY REFERENCES clients ON DELETE CASCADE,
  plan_id uuid NOT NULL REFERENCES plans,
  extra_users int NOT NULL DEFAULT 0 CHECK(extra_users>=0),       -- زيادة مستخدمين من غير تغيير الخطة
  extra_branches int NOT NULL DEFAULT 0 CHECK(extra_branches>=0),
  extra_warehouses int NOT NULL DEFAULT 0 CHECK(extra_warehouses>=0),
  extra_modules text[] NOT NULL DEFAULT '{}',
  starts_at date NOT NULL DEFAULT current_date,
  expires_at date,
  grace_days int NOT NULL DEFAULT 7 CHECK(grace_days>=0),
  status text NOT NULL DEFAULT 'active' CHECK(status IN('active','grace','readonly','suspended')), -- بتتغيّر يدوي
  message text NOT NULL DEFAULT '',                               -- رسالة تظهر للعميل
  notes text,
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- ---------- 5) المدفوعات اليدوية (للإضافة فقط، مفيش تعديل ولا حذف) ----------
CREATE TABLE payments(
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  client_id uuid NOT NULL REFERENCES clients,
  amount numeric(12,2) NOT NULL CHECK(amount>0),
  currency text NOT NULL DEFAULT 'EGP',
  paid_at date NOT NULL DEFAULT current_date,
  method text NOT NULL DEFAULT 'cash' CHECK(method IN('cash','bank','wallet','instapay','other')),
  period_from date, period_to date,
  reference text, note text,
  created_by uuid DEFAULT auth.uid(),
  created_at timestamptz NOT NULL DEFAULT now()
);

-- ---------- 6) سجل إرسال الترخيص وسجل العمليات ----------
CREATE TABLE license_pushes(
  id bigserial PRIMARY KEY,
  client_id uuid NOT NULL REFERENCES clients ON DELETE CASCADE,
  seq bigint, ok boolean NOT NULL, response text,
  payload jsonb, pushed_by uuid,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE panel_audit(
  id bigserial PRIMARY KEY,
  user_id uuid DEFAULT auth.uid(),
  action text NOT NULL, entity text NOT NULL, entity_id text, details jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE OR REPLACE FUNCTION trg_panel_audit() RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
BEGIN
  INSERT INTO panel_audit(action,entity,entity_id,details)
  VALUES(lower(TG_OP),TG_TABLE_NAME,COALESCE(to_jsonb(NEW)->>'id',to_jsonb(NEW)->>'client_id',to_jsonb(OLD)->>'id',to_jsonb(OLD)->>'client_id'),
         jsonb_build_object('old',to_jsonb(OLD),'new',to_jsonb(NEW)));
  RETURN COALESCE(NEW,OLD);
END $$;
CREATE TRIGGER audit_plans AFTER INSERT OR UPDATE OR DELETE ON plans FOR EACH ROW EXECUTE FUNCTION trg_panel_audit();
CREATE TRIGGER audit_clients AFTER INSERT OR UPDATE OR DELETE ON clients FOR EACH ROW EXECUTE FUNCTION trg_panel_audit();
CREATE TRIGGER audit_subscriptions AFTER INSERT OR UPDATE OR DELETE ON subscriptions FOR EACH ROW EXECUTE FUNCTION trg_panel_audit();
CREATE TRIGGER audit_payments AFTER INSERT ON payments FOR EACH ROW EXECUTE FUNCTION trg_panel_audit();
CREATE TRIGGER audit_staff AFTER INSERT OR UPDATE OR DELETE ON panel_staff FOR EACH ROW EXECUTE FUNCTION trg_panel_audit();

-- ---------- 7) RLS ----------
ALTER TABLE panel_staff ENABLE ROW LEVEL SECURITY;
ALTER TABLE plans ENABLE ROW LEVEL SECURITY;
ALTER TABLE clients ENABLE ROW LEVEL SECURITY;
ALTER TABLE subscriptions ENABLE ROW LEVEL SECURITY;
ALTER TABLE payments ENABLE ROW LEVEL SECURITY;
ALTER TABLE license_pushes ENABLE ROW LEVEL SECURITY;
ALTER TABLE panel_audit ENABLE ROW LEVEL SECURITY;

CREATE POLICY staff_sel ON panel_staff FOR SELECT TO authenticated USING (is_panel_staff() OR user_id=auth.uid());
CREATE POLICY staff_all ON panel_staff FOR ALL TO authenticated USING (is_panel_staff(ARRAY['owner'])) WITH CHECK (is_panel_staff(ARRAY['owner']));

CREATE POLICY plans_sel ON plans FOR SELECT TO authenticated USING (is_panel_staff());
CREATE POLICY plans_all ON plans FOR ALL TO authenticated USING (is_panel_staff(ARRAY['owner'])) WITH CHECK (is_panel_staff(ARRAY['owner']));

CREATE POLICY clients_sel ON clients FOR SELECT TO authenticated USING (is_panel_staff());
CREATE POLICY clients_all ON clients FOR ALL TO authenticated USING (is_panel_staff(ARRAY['owner','support'])) WITH CHECK (is_panel_staff(ARRAY['owner','support']));

CREATE POLICY subs_sel ON subscriptions FOR SELECT TO authenticated USING (is_panel_staff());
CREATE POLICY subs_all ON subscriptions FOR ALL TO authenticated USING (is_panel_staff(ARRAY['owner','support'])) WITH CHECK (is_panel_staff(ARRAY['owner','support']));

CREATE POLICY pay_sel ON payments FOR SELECT TO authenticated USING (is_panel_staff());
-- مفيش policy للكتابة: التسجيل بيتم من record_payment() بس

CREATE POLICY push_sel ON license_pushes FOR SELECT TO authenticated USING (is_panel_staff());
CREATE POLICY audit_sel ON panel_audit FOR SELECT TO authenticated USING (is_panel_staff(ARRAY['owner']));

REVOKE ALL ON ALL TABLES IN SCHEMA public FROM anon;
REVOKE INSERT, UPDATE, DELETE ON payments, license_pushes, panel_audit FROM authenticated;

-- ---------- 8) تسجيل دفعة يدوية (وتمديد الاشتراك لو اتحدد period_to) ----------
CREATE OR REPLACE FUNCTION record_payment(
  p_client uuid, p_amount numeric, p_method text DEFAULT 'cash', p_paid_at date DEFAULT current_date,
  p_period_from date DEFAULT NULL, p_period_to date DEFAULT NULL, p_reference text DEFAULT NULL, p_note text DEFAULT NULL,
  p_extend boolean DEFAULT true)
RETURNS uuid LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
DECLARE pid uuid;
BEGIN
  IF NOT is_panel_staff(ARRAY['owner','finance']) THEN RAISE EXCEPTION 'غير مصرح'; END IF;
  IF p_period_from IS NOT NULL AND p_period_to IS NOT NULL AND p_period_to < p_period_from THEN
    RAISE EXCEPTION 'نهاية الفترة قبل بدايتها'; END IF;
  INSERT INTO payments(client_id,amount,method,paid_at,period_from,period_to,reference,note)
  VALUES(p_client,p_amount,p_method,p_paid_at,p_period_from,p_period_to,p_reference,p_note) RETURNING id INTO pid;
  IF p_extend AND p_period_to IS NOT NULL THEN
    UPDATE subscriptions SET expires_at=GREATEST(COALESCE(expires_at,p_period_to),p_period_to), updated_at=now()
    WHERE client_id=p_client;   -- التمديد في اللوحة بس. الحالة (شغّال/قراءة فقط/موقوف) بتتغيّر يدوي وبتتبعت بعدين
  END IF;
  RETURN pid;
END $$;
REVOKE ALL ON FUNCTION record_payment(uuid,numeric,text,date,date,date,text,text,boolean) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION record_payment(uuid,numeric,text,date,date,date,text,text,boolean) TO authenticated;

-- ---------- 9) تجهيز أمر الترخيص (الحدود الفعلية = الخطة + الإضافات). التوقيع بيتم في دالة push-license ----------
CREATE OR REPLACE FUNCTION prepare_license_push(p_client uuid) RETURNS jsonb
LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
DECLARE c clients%ROWTYPE; s subscriptions%ROWTYPE; pl plans%ROWTYPE; v_seq bigint; mods text[]; payload jsonb;
BEGIN
  IF NOT is_panel_staff(ARRAY['owner','support']) THEN RAISE EXCEPTION 'غير مصرح'; END IF;
  SELECT * INTO c FROM clients WHERE id=p_client;
  IF NOT FOUND THEN RAISE EXCEPTION 'العميل غير موجود'; END IF;
  IF c.license_endpoint IS NULL OR c.license_endpoint='' THEN RAISE EXCEPTION 'رابط license-sync للعميل غير مسجّل'; END IF;
  SELECT * INTO s FROM subscriptions WHERE client_id=p_client;
  IF NOT FOUND THEN RAISE EXCEPTION 'مفيش اشتراك للعميل ده'; END IF;
  SELECT * INTO pl FROM plans WHERE id=s.plan_id;

  IF pl.modules IS NULL THEN mods := NULL;
  ELSE SELECT COALESCE(array_agg(DISTINCT m),'{}') INTO mods FROM unnest(pl.modules || s.extra_modules) m; END IF;

  UPDATE clients SET license_seq=license_seq+1 WHERE id=p_client RETURNING license_seq INTO v_seq;

  payload := jsonb_build_object(
    'v',1, 'type','license', 'client_id',c.id, 'seq',v_seq, 'issued_at',to_char(now() AT TIME ZONE 'utc','YYYY-MM-DD"T"HH24:MI:SS"Z"'),
    'plan_code',pl.code, 'plan_name',pl.name,
    'max_users',CASE WHEN pl.max_users IS NULL THEN NULL ELSE pl.max_users+s.extra_users END,
    'max_branches',CASE WHEN pl.max_branches IS NULL THEN NULL ELSE pl.max_branches+s.extra_branches END,
    'max_warehouses',CASE WHEN pl.max_warehouses IS NULL THEN NULL ELSE pl.max_warehouses+s.extra_warehouses END,
    'modules',to_jsonb(mods), 'storage_mb_warn',pl.storage_mb_warn,
    'status',s.status, 'expires_at',s.expires_at, 'grace_until',CASE WHEN s.expires_at IS NULL THEN NULL ELSE s.expires_at+s.grace_days END,
    'message',s.message);
  RETURN jsonb_build_object('payload',payload,'endpoint',c.license_endpoint);
END $$;
REVOKE ALL ON FUNCTION prepare_license_push(uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION prepare_license_push(uuid) TO authenticated;

-- ---------- 10) شاشة المتابعة: القريب والمتأخر (تنبيه بس، مفيش إيقاف تلقائي) ----------
CREATE OR REPLACE VIEW v_watch WITH (security_invoker=true) AS
SELECT c.id client_id, c.name, c.phone, pl.name plan_name, s.status, s.expires_at,
  (s.expires_at - current_date) days_left,
  CASE WHEN s.expires_at IS NULL THEN 'open'
       WHEN s.expires_at < current_date THEN 'expired'
       WHEN s.expires_at - current_date <= 7 THEN 'due_soon' ELSE 'ok' END expiry_state,
  s.extra_users, c.license_seq, c.last_ping_at,
  c.last_ping->'license'->>'seq' client_seq,
  c.last_ping->'license'->>'schema_version' schema_version,
  c.last_ping->>'users_used' users_used,
  (SELECT max(paid_at) FROM payments p WHERE p.client_id=c.id) last_payment
FROM clients c JOIN subscriptions s ON s.client_id=c.id JOIN plans pl ON pl.id=s.plan_id
WHERE c.active;
GRANT SELECT ON v_watch TO authenticated;

-- ---------- 11) أول مالك: بعد ما تعمل حسابك من Authentication > Users، شغّل (بدّل الـUUID) ----------
-- INSERT INTO panel_staff(user_id,name,role) VALUES('<UUID حسابك>','اسمك','owner');

COMMIT;
