// push-license (في مشروع اللوحة المركزية): بتجهّز أمر الترخيص، توقّعه بالمفتاح الخاص، وتبعته لدالة license-sync عند العميل.
// النشر:  supabase functions deploy push-license          (بتتحقق من JWT المستخدم)
// الـSecrets:  LICENSE_PRIVATE_KEY (PKCS8 base64 من gen_keys.mjs)  و  ADMIN_SECRET_KEY (مفتاح خدمة مشروع اللوحة)
// الطلب:  POST { client_id, mode?: "license" | "ping" }   أو   { all: true } لإرسال كل العملاء النشطين
import { createClient } from "npm:@supabase/supabase-js@2.45.4";

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};
const json = (status: number, body: unknown) =>
  new Response(JSON.stringify(body), { status, headers: { ...cors, "Content-Type": "application/json" } });

const b64d = (s: string) => Uint8Array.from(atob(s), (c) => c.charCodeAt(0));
const b64e = (b: ArrayBuffer) => btoa(String.fromCharCode(...new Uint8Array(b)));

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  if (req.method !== "POST") return json(405, { error: "Method not allowed" });

  const url = Deno.env.get("SUPABASE_URL")!;
  const anon = Deno.env.get("SUPABASE_ANON_KEY")!;
  const svc = Deno.env.get("ADMIN_SECRET_KEY");
  const privB64 = Deno.env.get("LICENSE_PRIVATE_KEY");
  if (!svc || !privB64) return json(500, { error: "Secrets ناقصة: ADMIN_SECRET_KEY / LICENSE_PRIVATE_KEY" });

  // المستخدم بجلسته هو اللي بينادي prepare_license_push، فالتحقق من الصلاحية وMFA بيتم في قاعدة البيانات
  const authHeader = req.headers.get("Authorization") ?? "";
  const user = createClient(url, anon, { global: { headers: { Authorization: authHeader } }, auth: { persistSession: false } });
  const { data: u, error: ue } = await user.auth.getUser();
  if (ue || !u?.user) return json(401, { error: "يجب تسجيل الدخول" });

  let body: { client_id?: string; all?: boolean; mode?: string };
  try { body = await req.json(); } catch { return json(400, { error: "بيانات غير صالحة" }); }

  const admin = createClient(url, svc, { auth: { persistSession: false } });
  const key = await crypto.subtle.importKey("pkcs8", b64d(privB64), { name: "Ed25519" }, false, ["sign"]);

  let ids: string[] = [];
  if (body.all) {
    const { data, error } = await user.from("clients").select("id").eq("active", true);
    if (error) return json(403, { error: error.message });
    ids = (data ?? []).map((r: { id: string }) => r.id);
  } else if (body.client_id) ids = [body.client_id];
  else return json(400, { error: "client_id مطلوب" });

  const results: unknown[] = [];
  for (const id of ids) {
    try {
      let payload: Record<string, unknown>; let endpoint: string; let seq: number | null = null;
      if (body.mode === "ping") {
        const { data: c, error } = await user.from("clients").select("license_endpoint").eq("id", id).single();
        if (error || !c?.license_endpoint) throw new Error("العميل أو رابطه غير موجود");
        endpoint = c.license_endpoint;
        payload = { v: 1, type: "ping", client_id: id, issued_at: new Date().toISOString() };
      } else {
        const { data, error } = await user.rpc("prepare_license_push", { p_client: id });
        if (error) throw new Error(error.message);
        payload = data.payload; endpoint = data.endpoint; seq = Number(payload.seq);
      }

      const text = JSON.stringify(payload);
      const sig = b64e(await crypto.subtle.sign({ name: "Ed25519" }, key, new TextEncoder().encode(text)));
      const ctl = new AbortController(); const t = setTimeout(() => ctl.abort(), 15000);
      const r = await fetch(endpoint, {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ payload: text, sig }), signal: ctl.signal,
      }).finally(() => clearTimeout(t));
      const respText = await r.text();

      if (body.mode === "ping") {
        if (r.ok) await admin.from("clients").update({ last_ping: JSON.parse(respText), last_ping_at: new Date().toISOString() }).eq("id", id);
      } else {
        await admin.from("license_pushes").insert({
          client_id: id, seq, ok: r.ok, response: respText.slice(0, 500), payload, pushed_by: u.user.id,
        });
      }
      results.push({ client_id: id, ok: r.ok, status: r.status, response: respText.slice(0, 300) });
    } catch (e) {
      const msg = e instanceof Error ? e.message : String(e);
      if (body.mode !== "ping") {
        await admin.from("license_pushes").insert({ client_id: id, ok: false, response: msg.slice(0, 500), pushed_by: u.user.id });
      }
      results.push({ client_id: id, ok: false, error: msg });
    }
  }
  return json(200, { results });
});
