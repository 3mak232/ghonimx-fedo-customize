// بيولّد زوج مفاتيح Ed25519 مرة واحدة للوحة كلها.
//   node gen_keys.mjs
// - LICENSE_PRIVATE_KEY  -> secret في دالة push-license في اللوحة المركزية فقط. احفظ نسخة بره الجهاز (password manager).
// - LICENSE_PUBLIC_KEY   -> secret في دالة license-sync عند كل عميل (مش سر، بس لازم يبقى صح).
import { generateKeyPairSync } from "node:crypto";

const { publicKey, privateKey } = generateKeyPairSync("ed25519");
const priv = privateKey.export({ format: "der", type: "pkcs8" }).toString("base64");
const spki = publicKey.export({ format: "der", type: "spki" });
const pub = spki.subarray(spki.length - 32).toString("base64"); // raw 32 bytes

console.log("LICENSE_PRIVATE_KEY=" + priv);
console.log("LICENSE_PUBLIC_KEY=" + pub);
console.error("\nاحفظ المفتاح الخاص في مكان آمن. لو ضاع هتحتاج تغيّر المفتاح العام عند كل عميل.");
