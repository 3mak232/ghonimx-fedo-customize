const URL_='https://rljzchqywvdfkfxuvjag.supabase.co',KEY='sb_publishable_NA_NCMyfDhXXBwmu3FAvlg_n4qrrayZ'; // FIXED for client rljzchq... (was __SUPABASE_URL__ / qzvnuy demo)
const TRUST_KEY='erp_dev_trust';
const trustTok=()=>{try{return localStorage.getItem(TRUST_KEY)||''}catch(_){return ''}};
const newTrustTok=()=>[...crypto.getRandomValues(new Uint8Array(32))].map(b=>b.toString(16).padStart(2,'0')).join('');
const sb=supabase.createClient(URL_,KEY,{global:{headers:{'x-device-trust':trustTok()}}});
console.log('ERP FIXED - URL_ =', URL_); // diagnostic - remove after verification
let me=null,view=localStorage.getItem('erp_v_view')||'dash',C={},cart={s:[],p:[],q:[],t:[]},RT=null,st='',tests=null,per='month',d1='',d2='',payInvoices=[],stk=null;
const ICO_P={check:'<path d="M20 6 9 17l-5-5"/>',x:'<path d="M18 6 6 18M6 6l12 12"/>',gear:'<path d="M18.64 9.80 L21.08 10.53 L21.08 13.47 L18.64 14.20 L18.26 15.14 L19.46 17.39 L17.39 19.46 L15.14 18.26 L14.20 18.64 L13.47 21.08 L10.53 21.08 L9.80 18.64 L8.86 18.26 L6.61 19.46 L4.54 17.39 L5.74 15.14 L5.36 14.20 L2.92 13.47 L2.92 10.53 L5.36 9.80 L5.74 8.86 L4.54 6.61 L6.61 4.54 L8.86 5.74 L9.80 5.36 L10.53 2.92 L13.47 2.92 L14.20 5.36 L15.14 5.74 L17.39 4.54 L19.46 6.61 L18.26 8.86 Z"/><circle cx="12" cy="12" r="3"/>',receipt:'<path d="M6 3h12v18l-3-2-3 2-3-2-3 2z"/><path d="M9 8h6M9 12h6"/>',printer:'<path d="M6 9V3h12v6"/><rect x="4" y="9" width="16" height="8" rx="2"/><path d="M7 14h10v7H7z"/>',building:'<rect x="5" y="3" width="14" height="18" rx="1"/><path d="M9 7h2M13 7h2M9 11h2M13 11h2M10 21v-4h4v4"/>',calendar:'<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M3 10h18M8 3v4M16 3v4"/>',users:'<circle cx="9" cy="8" r="3.5"/><path d="M2.5 20c.8-3.5 3.3-5 6.5-5s5.7 1.5 6.5 5"/><circle cx="17" cy="9" r="2.5"/><path d="M17 14.5c2.2.3 3.6 1.7 4 4.5"/>',save:'<path d="M5 3h11l3 3v15H5z"/><path d="M8 3v5h7V3M8 21v-7h8v7"/>',lockkey:'<rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/>',lock:'<rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/>',heart:'<path d="M12 20s-7-4.4-7-10a4 4 0 0 1 7-2.6A4 4 0 0 1 19 10c0 5.6-7 10-7 10z"/>',box:'<path d="M3 7l9-4 9 4v10l-9 4-9-4z"/><path d="M3 7l9 4 9-4M12 11v10"/>',book:'<path d="M4 4h6a2 2 0 0 1 2 2v14a2 2 0 0 0-2-2H4z"/><path d="M20 4h-6a2 2 0 0 0-2 2v14a2 2 0 0 1 2-2h6z"/>',chart:'<path d="M4 20V4M4 20h16"/><path d="M8 16v-5M12 16V8M16 16v-3"/>',home:'<path d="M3 11l9-7 9 7v9a1 1 0 0 1-1 1h-5v-6H10v6H4a1 1 0 0 1-1-1z"/>',menu:'<path d="M4 7h16M4 12h16M4 17h16"/>',globe:'<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c3 3.5 3 14.5 0 18M12 3c-3 3.5-3 14.5 0 18"/>',shield:'<path d="M12 3l8 3v6c0 4.5-3.4 8-8 9-4.6-1-8-4.5-8-9V6z"/>',camera:'<path d="M4 8h3l2-3h6l2 3h3v11H4z"/><circle cx="12" cy="13" r="3.5"/>'};
const ICO_P2={up:'<path d="M7 17 17 7M9 7h8v8"/>',down:'<path d="M17 7 7 17M15 17H7V9"/>',clock:'<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',box2:'<rect x="4" y="4" width="16" height="16" rx="2"/><path d="M4 12h16"/>',grid:'<rect x="4" y="4" width="7" height="7" rx="1"/><rect x="13" y="4" width="7" height="7" rx="1"/><rect x="4" y="13" width="7" height="7" rx="1"/><rect x="13" y="13" width="7" height="7" rx="1"/>',pulse:'<path d="M3 12h4l2-6 4 12 2-6h6"/>',swaplr:'<path d="M4 8h16M16 4l4 4-4 4M20 16H4M8 12l-4 4 4 4"/>',chevr:'<path d="M9 6l6 6-6 6"/>',chevd:'<path d="M6 9l6 6 6-6"/>',back:'<path d="M9 14 4 9l5-5"/><path d="M4 9h11a5 5 0 0 1 0 10h-3"/>',search:'<circle cx="11" cy="11" r="7"/><path d="M20 20l-4-4"/>',swap:'<path d="M4 8h14l-3-3M20 16H6l3 3"/>'};
function ico(n){return `<svg class="ico" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${ICO_P[n]||ICO_P2[n]||''}</svg>`}
const $=s=>document.querySelector(s),v=id=>{const x=$('#'+id);return x?x.value:''},n=id=>+v(id)||0,e=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
// الأرقام والتواريخ: عامية = أرقام عربية، فصحى/English = أرقام إنجليزية
function locOf(){const m=dialectMode();return m==='eg'?'ar-EG':(m==='msa'?'ar-EG-u-nu-latn':'en-US')}
const fmt=x=>(+x||0).toLocaleString(locOf(),{maximumFractionDigits:2});
let _loading=false,_loaderTimer=null,_loadingLabel='';
function showLoader(title='جاري التحميل...',text='من فضلك انتظر'){
  const box=$('#globalLoader');
  if(!box)return;
  _loading=true; _loadingLabel=title;
  const t=$('#loaderTitle'),x=$('#loaderText');
  if(t)t.textContent=title; if(x)x.textContent=text;
  box.classList.add('show');
  document.querySelectorAll('.brandmark').forEach(m=>m.classList.add('loading'));
}
function hideLoader(){
  _loading=false;
  if(_loaderTimer){clearTimeout(_loaderTimer);_loaderTimer=null;}
  const box=$('#globalLoader'); if(box)box.classList.remove('show');
  document.querySelectorAll('.brandmark').forEach(m=>m.classList.remove('loading'));
}
function withLoading(fn,title='جاري المعالجة...',text='يتم حفظ البيانات بأمان'){
  if(_loaderTimer)clearTimeout(_loaderTimer);
  // Only show the full overlay if the operation actually takes noticeable time.
  _loaderTimer=setTimeout(()=>showLoader(title,text),180);
  return Promise.resolve().then(fn).finally(()=>hideLoader());
}
function goBack(){const p=(window._nav||[]).pop();if(!p)return;view=p;localStorage.setItem('erp_v_view',p);closeMobileNav?.();showPlaceholder();return R('soft')}
function toast(msg){const t=$('#toast');if(!t)return;t.textContent=msg;t.classList.add('show');setTimeout(()=>t.classList.remove('show'),2200)}
function showPlaceholder(){const pg=document.querySelector('.page');if(pg)pg.innerHTML='<div class="page-loading"><div class="pl-spin"></div><p class="muted">جاري فتح الصفحة...</p></div>'}
function go(vw){window.ixMode={};if(vw!==view){window._nav=window._nav||[];window._nav.push(view);if(window._nav.length>20)window._nav.shift()}view=vw;localStorage.setItem('erp_v_view',vw);closeMobileNav?.();showPlaceholder();return R('soft')}

const P={admin:'*',accountant:['dash','prod','cust','supp','sales','purch','po','grn','dn','pay','exp','cash','trf','ret','quo','ord','stmt','emp','prl','asset','bank','price','rep','profit','bud','jr','stk','period','appr','shareholders','chk','comm','taxdoc','org','health','audit'],sales:['dash','prod','cust','sales','dn','ret','quo','ord','stmt','price','comm','taxdoc','appr'],store:['dash','prod','purch','po','grn','dn','ret','trf','stk','mfg']};
const canMaster=()=>!!me&&['admin','accountant','store'].includes(me.role);
const isAdminRole=()=>!!me&&me.role==='admin';
const DISC_MAX_PCT={sales:5};
const canBase=x=>me&&(P[me.role]==='*'||P[me.role].includes(x));
const can=x=>{if(!me)return false;if(x==='cust')return canRaw('cust')||canRaw('supp');return canRaw(x)};const canRaw=x=>{if(x==='health'||x==='devset')return !!me.isDev;if(me.role==='admin')return true;if(!canBase(x))return false;if(customPermMode==='custom')return customPerms.has(x);return true};
const NAV=[['dash','الرئيسية'],['prod','المنتجات'],['cust','الأطراف'],['supp','الموردون'],['sales','المبيعات'],['dn','أذونات التسليم'],['purch','المشتريات'],['po','أوامر الشراء'],['grn','استلامات المشتريات'],['ret','المرتجعات'],['quo','عروض الأسعار'],['ord','أوامر البيع'],['stmt','كشف الحساب'],['pay','المدفوعات'],['exp','المصروفات'],['cash','الخزينة'],['bank','البنوك والتسويات'],['whs','المخازن'],['trf','تحويل مخزني'],['stk','الجرد'],['price','قوائم الأسعار'],['comm','العمولات'],['asset','الأصول الثابتة'],['emp','الموظفون'],['hr','الحضور والإجازات'],['prl','المرتبات'],['mfg','التصنيع'],['pos','نقطة البيع'],['proj','المشروعات والخدمات'],['org','الفروع ومراكز التكلفة'],['period','الفترات المالية'],['appr','الاعتمادات'],['shareholders','المساهمون'],['chk','الشيكات'],['taxdoc','المستندات الضريبية'],['int','التكاملات'],['rep','التقارير'],['jr','الحسابات'],['health','فحص الجاهزية'],['users','المستخدمون'],['audit','سجل العمليات'],['set','الإعدادات والإدارة']];
const rpc=async(f,a={})=>{const{data,error}=await sb.rpc(f,a);if(error)throw error;return data};
const ins=async(t,o)=>{const{data,error}=await sb.from(t).insert(o).select().single();if(error)throw error;return data};
const upd=async(t,id,o)=>{const{error}=await sb.from(t).update(o).eq('id',id);if(error)throw error};
const g=async(t,o,sel='*')=>{let q=sb.from(t).select(sel);if(o)q=q.order(o);const{data,error}=await q;if(error)throw error;return data||[]};
const T=(h,r)=>`<div class="tw tw-stack"><table><tr>${h.map(x=>`<th>${x}</th>`).join('')}</tr>${r.map(x=>`<tr>${x.map((y,i)=>`<td><span class="tk-l">${h[i]??''}</span><span class="tk-v">${y}</span></td>`).join('')}</tr>`).join('')}</table></div>`;
const O=a=>(a||[]).map(x=>`<option value="${x.id}">${e(x.name)}</option>`).join('');
const by=(a,i)=>a.find(x=>x.id==i)||{}; const stkQty=p=>C.stock.filter(s=>s.product_id==p).reduce((a,s)=>a+ +s.qty,0);
const stkQtyWh=(p,w)=>C.stock.filter(s=>s.product_id==p&&s.warehouse_id==w).reduce((a,s)=>a+ +s.qty,0);
async function act(f,okMsg){const keep=view;if(!navigator.onLine){toast('هذه العملية تحتاج اتصالاً بالإنترنت — لم يتم تسجيل أي تغيير');return}return withLoading(async()=>{try{const _r=await f();await loadAll();toast(okMsg?okMsg(_r):'تمت العملية بنجاح')}catch(x){alert(x.message||x.error_description||x);throw x}finally{view=keep;localStorage.setItem('erp_v_view',keep);await R()}})}
function range(){const t=new Date(),f=x=>x.toISOString().slice(0,10);if(per==='today')return[f(t),f(t)];if(per==='week'){const s=new Date(t);s.setDate(t.getDate()-6);return[f(s),f(t)]}if(per==='custom')return[d1||f(t),d2||f(t)];return[f(new Date(t.getFullYear(),t.getMonth(),1)),f(t)]}
async function loadAll(soft){
  if(soft&&C&&Date.now()-(window._lastLoad||0)<60000)return;
  window._lastLoad=Date.now();
  const finance=me&&(me.role==='admin'||me.role==='accountant');
  const cached=k=>{try{return JSON.parse(localStorage.getItem('erp_cache_'+k)||'null')}catch{return null}};
  const saveCache=!soft||Date.now()-(window._lastCacheWrite||0)>300000;
  const safe=async(k,fn)=>{try{const x=await fn();if(saveCache){try{localStorage.setItem('erp_cache_'+k,JSON.stringify(x))}catch(_){}}return x}catch(err){const x=cached(k);if(x)return x;throw err}};
  const[products,customers,suppliers,warehouses,accts,stock,cb,sbal]=await Promise.all([
    safe('products',()=>g('products','name')),safe('customers',()=>g('customers','name')),safe('suppliers',()=>g('suppliers','name')),safe('warehouses',()=>g('warehouses','name')),finance?safe('cash_accounts',()=>g('cash_accounts','name')):Promise.resolve([]),safe('stock',()=>g('stock_balances')),safe('cb',()=>g('customer_balances')),safe('sbal',()=>g('supplier_balances'))]);
  if(saveCache)window._lastCacheWrite=Date.now();
  C={products,customers,suppliers,warehouses,accts,stock,cb,sbal};
}
function masterForm(kind){
 const c=kind==='cust',tbl=c?'customers':'suppliers',L0=c?C.customers:C.suppliers,q=(window._mq||'').trim(),L=q?L0.filter(x=>[e(x.name),e(x.phone),e(x.email)].join(' ').includes(q)):L0;
 const adm=isAdminRole(),canEd=adm||(!c&&me.role==='accountant'),ed=(window._mEdit&&canEd)?L0.find(x=>x.id===window._mEdit):null;
 const editCard=ed?`<div class="card np"><div class="card-title"><b>تعديل: ${e(ed.name)}</b></div><div class="row"><input id="me_n" value="${e(ed.name)}" placeholder="الاسم"><input id="me_h" value="${e(ed.phone||'')}" placeholder="الهاتف"><input id="me_a" value="${e(ed.address||'')}" placeholder="العنوان"><button onclick="act(async()=>{await upd('${tbl}','${ed.id}',{name:v('me_n'),phone:v('me_h')||null,address:v('me_a')||null});window._mEdit=null})">حفظ</button><button class="s" onclick="window._mEdit=null;R()">إلغاء</button></div></div>`:'';
 const acts=x=>{let h='';if(canEd)h+=`<button class="s" onclick="window._mEdit='${x.id}';R()">تعديل</button> <button class="s" onclick="act(()=>upd('${tbl}','${x.id}',{active:${!x.active}}))">${x.active?'تعطيل':'تفعيل'}</button>`;if(c&&adm)h+=` <button class="danger" onclick="delParty('customers','${x.id}')">حذف</button>`;return h};
 return `<h2>${c?'العملاء':'الموردون'}</h2>${editCard}<div class="card np"><div class="row"><input id="mn" placeholder="الاسم"><input id="mh" placeholder="الهاتف"><input id="me2" type="email" placeholder="البريد"><input id="ma" placeholder="العنوان"><input id="mt" type="number" placeholder="مدة السداد بالأيام"><input id="mo" type="number" placeholder="رصيد افتتاحي">${c?'<input id="ml" type="number" placeholder="حد الائتمان">':''}<button onclick="act(async()=>ins('${tbl}',{name:v('mn'),phone:v('mh'),email:v('me2'),address:v('ma'),payment_terms_days:n('mt'),opening_balance:n('mo')${c?',credit_limit:n(\'ml\')':''}}))">إضافة</button></div></div><div class="card np"><input id="mq" placeholder="بحث بالاسم أو الهاتف أو البريد" value="${e(q)}" oninput="mSearch(this)"></div><div class="card">${T(['الاسم','الهاتف','البريد','مدة السداد','الرصيد','الحالة',''],L.map(x=>[e(x.name),e(x.phone),e(x.email),x.payment_terms_days||0,fmt(by(c?C.cb:C.sbal,x.id).balance),x.active?'مفعّل':'معطل',acts(x)]))}</div>`}
function mSearch(el){window._mq=el.value;clearTimeout(window._mqT);window._mqT=setTimeout(()=>{R(1).then(()=>{const q=document.getElementById('mq');if(q){q.focus();q.setSelectionRange(q.value.length,q.value.length)}})},250)}
async function delParty(t,id){if(!confirm('حذف نهائي؟ لا يمكن التراجع.'))return;return act(async()=>{const{data,error}=await sb.from(t).delete().eq('id',id).select();if(error){if(error.code==='23503')throw Error('لا يمكن حذف هذا العميل لوجود فواتير أو حركات مرتبطة به — استخدم "تعطيل" بدلًا من الحذف');throw error}if(!data||!data.length)throw Error('لم يتم الحذف — تحقق من صلاحياتك')})}
async function warehousesView(){
 const L=await g('warehouses','name'),ed=window._wEdit?L.find(x=>x.id===window._wEdit):null;
 return `${sectionHead('المخازن','إضافة مخزن جديد وتعديل اسمه، أو تعطيله.')}
 <div class="card np"><div class="row"><input id="wn" placeholder="اسم المخزن"><button onclick="act(async()=>{if(!v('wn').trim())throw Error('أدخل اسم المخزن');await ins('warehouses',{name:v('wn').trim()})})">إضافة مخزن</button></div></div>
 ${ed?`<div class="card np"><div class="card-title"><b>تعديل: ${e(ed.name)}</b></div><div class="row"><input id="we_n" value="${e(ed.name)}"><button onclick="act(async()=>{await upd('warehouses','${ed.id}',{name:v('we_n').trim()});window._wEdit=null})">حفظ</button><button class="s" onclick="window._wEdit=null;R()">إلغاء</button></div></div>`:''}
 <div class="card">${T(['المخزن','الحالة',''],L.map(x=>[e(x.name),x.active?'مفعّل':'معطل',`<button class="s" onclick="window._wEdit='${x.id}';R()">تعديل</button> <button class="s" onclick="act(()=>upd('warehouses','${x.id}',{active:${!x.active}}))">${x.active?'تعطيل':'تفعيل'}</button>`]))}</div>`}
async function stkApprove(id){return act(async()=>{const items=(window._stkL||[]).map((x,i)=>({product_id:x.product_id,actual_qty:n('sq'+i)}));if(items.some(x=>!(x.actual_qty>=0)))throw Error('الكمية الفعلية لازم تكون رقم صفر أو أكبر');await rpc('approve_stocktake_v2',{p_stocktake:id,p_items:items});stk=null})}
function addLine(k){const p=by(C.products,v('il')),pr=n('ir')||(k==='p'?p.purchase_price:p.sale_price);if(!p.id||n('iq')<=0||pr<0)return alert('بيانات البند غير صحيحة');cart[k].push({product_id:p.id,qty:n('iq'),price:+pr,discount:n('id')});R()}
function cartTable(k){const cr=cart[k]||[],s=k==='s';return cr.length?T(['الصنف','الكمية','السعر','الخصم','الإجمالي',''],cr.map((l,i)=>[e(by(C.products,l.product_id).name),l.qty,l.price,l.discount,fmt(l.qty*l.price-l.discount),`<button class="danger" onclick="cart.${k}.splice(${i},1);R()">حذف</button>`])):''}
async function invoiceView(s){
  const k=s?'s':'p',cr=cart[k],tot=cr.reduce((a,l)=>a+l.qty*l.price-l.discount,0),L=await g(s?'sales_invoice_balances':'purchase_invoice_balances','date');
  const finance=me&&(me.role==='admin'||me.role==='accountant');
  const payBox=finance?`<div class="row"><input id="ipd" type="number" placeholder="المدفوع" value="0"><select id="ia"><option value="">الحساب المالي</option>${O(C.accts)}</select><select id="im"><option value="credit">آجل / جزء آجل</option><option value="cash">نقدي</option><option value="bank">بنك</option><option value="wallet">محفظة</option></select><button onclick="act(()=>saveInvoice(${s?'true':'false'}))">حفظ</button></div>`:`<div class="row"><span class="muted">حفظ على الحساب/آجل — صلاحية الدفع المباشر غير متاحة لهذا الدور.</span><button onclick="act(()=>saveInvoice(${s?'true':'false'}))">حفظ</button></div>`;
  return `<h2>${s?'فواتير المبيعات':'فواتير المشتريات'}</h2><div class="card np"><div class="row"><select id="ip">${O(s?C.customers:C.suppliers)}</select><select id="iw">${O(C.warehouses)}</select><select id="il">${O(C.products.filter(p=>p.active))}</select><input id="iq" type="number" value="1" style="width:80px"><input id="ir" type="number" placeholder="السعر" style="width:100px"><input id="id" type="number" placeholder="خصم" style="width:90px"><button class="s" onclick="addLine('${k}')">+ بند</button></div>${cartTable(k)}<p>الإجمالي قبل الضريبة/الخصم الكلي: <b>${fmt(tot)}</b></p><div class="row"><input id="ig" type="number" placeholder="خصم كلي" value="0"></div>${payBox}</div><div class="card"><b>الفواتير</b>${T(['الرقم','التاريخ','الاستحقاق','الإجمالي','المدفوع المخصص','المتبقي'],L.reverse().map(x=>[e(x.number),x.date,x.due_date||'',fmt(x.total),fmt(x.allocated_paid),fmt(x.outstanding)]))}</div>`;
}
// The invoice save button is rendered separately to keep inline JS readable.
async function saveInvoice(s){
  const k=s?'s':'p',items=cart[k]; if(!items.length)return alert('أضف بنودًا');
  const finance=me&&(me.role==='admin'||me.role==='accountant');
  const paid=finance?n('ipd'):0,account=finance?v('ia'):null,discount=n('ig'),method=finance?v('im'):'credit';
  if(paid>0&&!account)return alert('اختر الحساب المالي');
  const maxPct=me.role==='sales'?+((await g('company_settings').then(x=>x[0]||{})).sales_discount_max_pct??5):undefined;if(s&&maxPct!==undefined&&discount>0){const sub=items.reduce((a,l)=>a+l.qty*l.price-l.discount,0);if(discount>sub*maxPct/100)return alert('أقصى خصم على الفاتورة لدورك '+maxPct+'% من إجمالي الأصناف = '+fmt(sub*maxPct/100))}
  if(s&&window._editInv){const ei=window._editInv;await rpc('edit_sales_invoice',{p_invoice:ei.id,p_customer:v('ip'),p_warehouse:v('iw'),p_items:items,p_paid:paid,p_account:paid?account:null,p_method:method,p_discount:discount});window._editInv=null;cart[k]=[];return}
  await rpc(s?'create_sale':'create_purchase',s?{p_customer:v('ip'),p_warehouse:v('iw'),p_items:items,p_paid:paid,p_account:paid?account:null,p_method:method,p_discount:discount}:{p_supplier:v('ip'),p_warehouse:v('iw'),p_items:items,p_paid:paid,p_account:paid?account:null,p_method:method,p_discount:discount});
  cart[k]=[];
}
async function dash(){const[a,b]=range(),D=await rpc('dashboard_v2',{p_from:a,p_to:b}),low=await g('low_stock');const finance=me.role==='admin'||me.role==='accountant';const k=(t,x)=>`<div class="card k"><span>${t}</span><b>${fmt(x)}</b></div>`;return `<h2>الرئيسية</h2><div class="card np"><select id="per" onchange="per=v('per');R()">${[['today','اليوم'],['week','آخر 7 أيام'],['month','هذا الشهر'],['custom','فترة مخصصة']].map(x=>`<option value="${x[0]}" ${per==x[0]?'selected':''}>${x[1]}</option>`).join('')}</select>${per==='custom'?`<input type="date" id="d1" value="${a}" onchange="d1=v('d1');R()"><input type="date" id="d2" value="${b}" onchange="d2=v('d2');R()">`:''}</div><div class="grid">${k('المبيعات',D.sales)}${finance?k('المشتريات',D.purchases):''}${finance?k('المصروفات',D.expenses):''}${finance?k('صافي الربح المبدئي',D.sales-D.cogs-D.expenses):''}${finance?k('مستحق العملاء',D.receivables):''}${finance?k('مستحق الموردين',D.payables):''}${finance?k('قيمة المخزون',D.inventory_value):''}${k('عدد المنتجات',D.products)}${finance?k('المقبوضات',D.receipts):''}${finance?k('المدفوعات',D.payments_out):''}</div><div class="card"><b>منتجات منخفضة المخزون (${low.length})</b>${low.length?T(['المنتج','الحالي','الحد الأدنى'],low.map(p=>[e(p.name),p.stock,p.min_stock])):'<p>لا يوجد</p>'}</div>${me.role==='admin'?`<div class="card np"><b>اختبار النظام قبل إدخال البيانات الحقيقية</b><p class="muted">ينشئ بيانات TEST مؤقتة، يختبر البيع والشراء والضريبة والمدفوعات والمرتجعات والتحويل والجرد واليومية والتقارير، ثم ينظف كل بيانات الاختبار تلقائيًا.</p><button onclick="runSmokeTest()">تشغيل الاختبار الكامل</button><div id="smokeResult"></div></div>`:''}`}
window._LS=window._LS||{};
function lsCard(key,headers,rows,texts,ph){window._LS[key]={headers,rows,texts};return `<div class="ls-box"><input class="ls-q" placeholder="${e(ph||'بحث...')}" oninput="lsFilter('${key}',this.value)"><div id="ls_${key}">${T(headers,rows)}</div></div>`}
function lsFilter(key,q){const d=window._LS[key];if(!d)return;q=(q||'').trim().toLowerCase();const idx=d.rows.map((r,i)=>i).filter(i=>!q||String(d.texts[i]).toLowerCase().includes(q));const box=document.getElementById('ls_'+key);if(box)box.innerHTML=T(d.headers,idx.map(i=>d.rows[i]))}
const AU_ACT={create:'إنشاء',update:'تعديل',delete:'حذف',void:'إلغاء فاتورة',cancel:'إلغاء',payment:'تسجيل دفعة',transfer:'تحويل',approve:'اعتماد',dispose:'استبعاد أصل',close:'إقفال الفترة',complete:'إكمال',login:'تسجيل دخول'};
const AU_ENT={sales_invoices:'فاتورة بيع',purchase_invoices:'فاتورة شراء',payments:'دفعة',payroll:'كشف مرتب',purchase_returns:'مرتجع شراء',sales_returns:'مرتجع بيع',inventory_trace_events:'حركة تتبع مخزون',stock_balances:'رصيد مخزون',stock_transfers:'تحويل مخزني',stocktakes:'جرد',sales_orders:'أمر بيع',quotations:'عرض سعر',purchase_orders:'أمر شراء',opening_balance_runs:'رصيد افتتاحي',journal_entries:'قيد يومية',goods_receipts:'استلام بضاعة',fixed_assets:'أصل ثابت',fixed_asset_acquisition:'شراء أصل ثابت',expenses:'مصروف',delivery_notes:'إذن تسليم',cheques:'شيك',asset_depreciations:'إهلاك أصل',work_orders:'أمر تصنيع',fiscal_periods:'فترة مالية',cash_transfers:'تحويل بين الحسابات',products:'صنف',customers:'عميل',suppliers:'مورد',warehouses:'مخزن',cash_accounts:'حساب خزينة/بنك',employees:'موظف',profiles:'مستخدم',user_permissions:'صلاحيات مستخدم',company_settings:'إعدادات الشركة'};
const MV_TYPE={Purchase:'شراء',Sale:'بيع','Sales Return':'مرتجع بيع','Purchase Return':'مرتجع شراء','Stock Adjustment':'تسوية جرد','Opening Balance':'رصيد افتتاحي',Transfer:'تحويل مخزني'};
const cday=d=>new Date(d).toLocaleDateString('en-CA',{timeZone:'Africa/Cairo'});
const dayRange=d=>{const st=Date.parse(d+'T00:00:00Z')-86400000;return[new Date(st).toISOString(),new Date(st+3*86400000).toISOString()]};
const auAct=a=>AU_ACT[a]||a||'—';
const auEnt=t=>AU_ENT[t]||t||'—';
function trOpenBtn(kind,id){return `<button class="s" onclick="trOpen('${kind}','${id}')">تفاصيل</button>`}
async function trOpen(kind,id){const t=kind==='stk'?'stock_transfers':'cash_transfers';const{data,error}=await sb.from(t).select('*').eq('id',id).single();if(error)return alert(error.message);let items=[];if(kind==='stk'){const r=await sb.from('stock_transfer_items').select('*').eq('transfer_id',id);if(r.error)return alert(r.error.message);items=r.data||[]}const PN=await profNames();window._trDet={kind,row:data,items,by:PN[data.created_by]||'—'};showModal(trDetHtml(kind))}
function trDetHtml(k){const d=window._trDet;if(!d||d.kind!==k)return '';const r=d.row;const wn=id=>(by(C.warehouses,id).name)||'';const an=id=>(by(C.accts,id).name)||'';let info;if(k==='stk'){info=[['رقم التحويل',r.number],['التاريخ',r.date],['من مخزن',wn(r.from_warehouse)],['إلى مخزن',wn(r.to_warehouse)],['الحالة',r.status||'—'],['ملاحظات',r.notes||'—'],['تم بواسطة',d.by]]}else{info=[['التاريخ',r.date],['من حساب',an(r.from_account)],['إلى حساب',an(r.to_account)],['المبلغ',fmt(r.amount)],['تم بواسطة',d.by]]}const itemsT=k==='stk'?`<h3>الأصناف المحوّلة</h3>${T(['الصنف','الكمية'],d.items.map(x=>[e((by(C.products,x.product_id).name)||'—'),x.qty]))}`:'';return `<div class="card tr-detail"><div class="card-title"><b>تفاصيل ${k==='stk'?'التحويل المخزني':'التحويل بين الحسابات'}</b><button class="s" onclick="closeModal()">إغلاق</button></div>${T(['البند','القيمة'],info.map(([a,b])=>[a,e(String(b))]))}${itemsT}</div>`}
async function stkTransfersHtml(){const L=(await g('stock_transfers','date')).reverse();const wn=id=>(by(C.warehouses,id).name)||'';const rows=L.map(x=>[e(x.number),x.date,e(wn(x.from_warehouse)),e(wn(x.to_warehouse)),x.status,trOpenBtn('stk',x.id)]);const texts=L.map(x=>[e(x.number),x.date,wn(x.from_warehouse),wn(x.to_warehouse),x.status].join(' '));return lsCard('stk_tr',['رقم','التاريخ','من','إلى','الحالة',''],rows,texts,'ابحث برقم التحويل أو اسم المخزن أو التاريخ...')}
async function cashTransfersHtml(){const[L0,PN]=await Promise.all([g('cash_transfers','date'),profNames()]);const L=L0.slice().reverse();const an=id=>(by(C.accts,id).name)||'';const rows=L.map(x=>[x.date,e(an(x.from_account)),e(an(x.to_account)),fmt(x.amount),e(PN[x.created_by]||'—'),trOpenBtn('cash',x.id)]);const texts=L.map(x=>[x.date,an(x.from_account),an(x.to_account),x.amount,PN[x.created_by]||''].join(' '));return lsCard('cash_tr',['التاريخ','من','إلى','المبلغ','تم بواسطة',''],rows,texts,'ابحث باسم الحساب أو المستخدم أو المبلغ أو التاريخ...')}
async function mvHtml(day,PN){const[a,b]=dayRange(day);const{data,error}=await sb.from('stock_movements').select('*').gte('created_at',a).lt('created_at',b).order('created_at',{ascending:false}).limit(3000);if(error)throw error;const L=(data||[]).filter(x=>cday(x.created_at)===day);const pn=id=>(by(C.products,id).name)||'';const wn=id=>(by(C.warehouses,id).name)||'';const tp=t=>MV_TYPE[t]||t;const rows=L.map(x=>[new Date(x.created_at).toLocaleTimeString(locOf(),{hour:'2-digit',minute:'2-digit',timeZone:'Africa/Cairo'}),e(PN[x.user_id]||'—'),e(pn(x.product_id)),e(wn(x.warehouse_id)),e(tp(x.type)),x.qty,`${x.qty_before} ← ${x.qty_after}`]);const texts=L.map(x=>[PN[x.user_id]||'',pn(x.product_id),wn(x.warehouse_id),tp(x.type)].join(' '));return lsCard('mv',['الوقت','المستخدم','الصنف','المخزن','نوع الحركة','الكمية','الرصيد قبل ← بعد'],rows,texts,'ابحث باسم الصنف أو المستخدم أو نوع الحركة...')}
async function auditView(){
 const today=cday(new Date()),day=window._auDay||today,[a,b]=dayRange(day);
 const from14=new Date(Date.now()-14*86400000).toISOString();
 const[ov,q1,PN]=await Promise.all([sb.from('audit_logs').select('created_at').gte('created_at',from14).limit(5000),sb.from('audit_logs').select('*').gte('created_at',a).lt('created_at',b).order('created_at',{ascending:false}).limit(3000),profNames()]);
 if(ov.error)throw ov.error; if(q1.error)throw q1.error;
 const cnt={};(ov.data||[]).forEach(x=>{const d=cday(x.created_at);cnt[d]=(cnt[d]||0)+1});
 const L=(q1.data||[]).filter(x=>cday(x.created_at)===day);
 const rows=L.map(x=>[new Date(x.created_at).toLocaleTimeString(locOf(),{hour:'2-digit',minute:'2-digit',timeZone:'Africa/Cairo'}),e(x.user_name||PN[x.user_id]||'—'),e(auAct(x.action)),e(auEnt(x.entity)),e(auDesc(x))]);
 const texts=L.map(x=>[x.user_name||'',auAct(x.action),auEnt(x.entity),auDesc(x)].join(' '));
 const strip=[...Array(14)].map((_,i)=>cday(new Date(Date.now()-i*86400000))).map(d=>{const lbl=new Date(d+'T12:00:00Z').toLocaleDateString(locOf(),{weekday:'long',day:'numeric',month:'long',timeZone:'Africa/Cairo'});return `<button class="day-btn${d===day?' on':''}" onclick="auDay('${d}')"><b>${lbl}</b><small>${d===today?'اليوم · مفتوح':'مقفول'} · ${cnt[d]||0} عملية</small></button>`}).join('');
 const dl=new Date(day+'T12:00:00Z').toLocaleDateString(locOf(),{weekday:'long',day:'numeric',month:'long',year:'numeric',timeZone:'Africa/Cairo'});
 const mv=await mvHtml(day,PN);
 return `<h2>سجل العمليات</h2>
 <div class="card"><div class="card-title"><b>اختر يوم</b><div class="row"><input type="date" value="${day}" onchange="auDay(this.value)">${day!==today?'<button class="s" onclick="auDay(\''+today+'\')">اليوم</button>':''}</div></div><div class="day-strip">${strip}</div><p class="muted">اليوم الحالي مفتوح وبيتسجل فيه. أي يوم قبله مقفول: بيتعرض للمراجعة بس ومش بيتعدّل.</p></div>
 <div class="card"><div class="card-title"><b>عمليات ${e(dl)}</b><span class="chip ${day===today?'info':'success'}">${day===today?'اليوم (مفتوح)':'يوم مقفول'} · ${L.length} عملية</span></div>${lsCard('audit',['الوقت','المستخدم','نوع العملية','الجزء المتأثر','التفاصيل'],rows,texts,'ابحث باسم المستخدم أو نوع العملية أو التفاصيل...')}</div>
 <h3>حركات المخزون في نفس اليوم</h3><div class="card">${mv}</div>`}
function auDay(d){if(!d)return;window._auDay=(d===cday(new Date()))?null:d;R()}
async function profNames(){try{const P=await g('profiles','name','id,name');return Object.fromEntries(P.map(x=>[x.id,e(x.name)]))}catch(_){return {}}}
function dupProdName(name,exceptId){const n=(name||'').trim().toLowerCase();if(!n)return false;return C.products.some(x=>x.id!==exceptId&&(x.name||'').trim().toLowerCase()===n)}
function productsView(){
 const canM=canMaster(),pe=window._pe?by(C.products,window._pe):null;
 const editCard=(canM&&pe&&pe.id)?`<div class="card np"><div class="card-title"><b>تعديل الصنف: ${e(pe.name)}</b></div><div class="row"><input id="ep_n" value="${e(pe.name)}" placeholder="الاسم"><input id="ep_c" value="${e(pe.code||'')}" placeholder="الكود"><input id="ep_b" value="${e(pe.barcode||'')}" placeholder="باركود"><input id="ep_p" type="number" value="${pe.purchase_price}" placeholder="شراء"><input id="ep_s" type="number" value="${pe.sale_price}" placeholder="بيع"><input id="ep_w" type="number" value="${pe.wholesale_price}" placeholder="جملة"><input id="ep_m" type="number" value="${pe.min_stock}" placeholder="حد إعادة الطلب"><button onclick="act(async()=>{if(dupProdName(v('ep_n'),'${pe.id}'))throw Error('يوجد صنف آخر بنفس الاسم');await upd('products','${pe.id}',{name:v('ep_n'),code:v('ep_c')||null,barcode:v('ep_b')||null,purchase_price:n('ep_p'),sale_price:n('ep_s'),wholesale_price:n('ep_w'),min_stock:n('ep_m')});window._pe=null})">حفظ التعديل</button><button class="s" onclick="window._pe=null;R()">إلغاء</button></div></div>`:'';
 const addCard=canM?`<div class="card np"><div class="row"><input id="pn" placeholder="الاسم"><input id="pc" placeholder="الكود"><input id="pbc" placeholder="باركود"><input id="pp" type="number" placeholder="شراء"><input id="ps" type="number" placeholder="بيع"><input id="pw" type="number" placeholder="جملة"><input id="pm" type="number" placeholder="حد إعادة الطلب"><input id="prq" type="number" placeholder="كمية إعادة الطلب"><input id="pq" type="number" placeholder="الرصيد الافتتاحي (اختياري)"><select id="pwh">${O(C.warehouses)}</select><button onclick="act(async()=>{if(dupProdName(v('pn')))throw Error('يوجد صنف بنفس الاسم بالفعل — عدّل الصنف الموجود بدل إضافة نسخة جديدة');const p=await ins('products',{name:v('pn'),code:v('pc')||null,barcode:v('pbc')||null,purchase_price:n('pp'),sale_price:n('ps'),wholesale_price:n('pw'),min_stock:n('pm'),reorder_qty:n('prq'),avg_cost:n('pp')});if(n('pq')>0)await rpc('set_opening_stock',{p_prod:p.id,p_wh:v('pwh'),p_qty:n('pq')})})">إضافة</button></div><p class="muted">الرصيد الافتتاحي = الكمية الموجودة فعلًا في المخزن المختار وقت بدء استخدام النظام لهذا الصنف. يُسجَّل مرة واحدة فقط؛ بعد ذلك استخدم فاتورة الشراء أو تسوية الجرد لأي تغيير.</p></div>`:`<div class="card np muted">عرض فقط — إضافة الأصناف وتعديلها متاحة للإدارة والمحاسب والمخزن.</div>`;
 const rows=C.products.filter(p=>!window._q||[p.name,p.code,p.barcode].join(' ').includes(window._q)).map(p=>[e(p.code),e(p.name),e(p.barcode),fmt(p.avg_cost),fmt(p.sale_price),`<span class="${stkQty(p.id)<=p.min_stock?'bad':''}">${stkQty(p.id)}</span>`,p.active?'مفعّل':'معطل',canM?`<button class="s" onclick="window._pe='${p.id}';R()">تعديل</button> <button class="s" onclick="act(()=>upd('products','${p.id}',{active:${!p.active}}))">${p.active?'تعطيل':'تفعيل'}</button>`:'']);
 return `${editCard}${addCard}<div class="card"><input id="q" placeholder="بحث" value="${e(window._q||'')}" oninput="qSearch(this)">${T(['الكود','الاسم','الباركود','التكلفة','بيع','المخزون','الحالة',''],rows)}</div>`}
async function payView(){const cu=window._yk!=='supp';const L=cu?C.customers:C.suppliers;const P_=cu?C.cb:C.sbal;return `<h2>المدفوعات والتخصيص</h2><div class="card np"><div class="row"><select id="yk" onchange="window._yk=v('yk')==='receipt'?'cust':'supp';R()"><option value="receipt" ${cu?'selected':''}>مقبوضات عميل</option><option value="payment" ${cu?'':'selected'}>مدفوعات مورد</option></select><select id="yp" onchange="loadPayInvoices()">${O(L)}</select><select id="yinv"><option value="">دفعة على الحساب (بدون تخصيص)</option></select><input id="ya" type="number" placeholder="المبلغ"><select id="yc">${O(C.accts)}</select><button onclick="savePayment()">تسجيل الدفعة</button></div><p class="muted">يمكن ترك الفاتورة فارغة ليصبح المبلغ رصيدًا غير مخصص، ثم تخصيصه لاحقًا.</p></div><div class="card"><b>الأرصدة</b>${T(['الاسم','الرصيد'],L.map(x=>[e(x.name),fmt(by(P_,x.id).balance)]))}</div>`}
async function loadPayInvoices(){const cu=v('yk')==='receipt',id=v('yp');const src=cu?'sales_invoice_balances':'purchase_invoice_balances';const col=cu?'customer_id':'supplier_id';const{data,error}=await sb.from(src).select('*').eq(col,id).gt('outstanding',0).eq('status','Posted').order('date',{ascending:false});if(error)throw error;payInvoices=data||[];const sel=$('#yinv');if(sel)sel.innerHTML='<option value="">دفعة على الحساب (بدون تخصيص)</option>'+payInvoices.map(x=>`<option value="${x.id}">${e(x.number)} — متبقي ${fmt(x.outstanding)}</option>`).join('')}
async function savePayment(){const amt=n('ya'),inv=v('yinv'),kind=v('yk'),party=v('yp'),acct=v('yc');if(!amt||!acct)return alert('أكمل البيانات');const alloc=inv?[{invoice_id:inv,amount:amt}]:[];await act(()=>rpc('record_payment',{p_kind:kind,p_party:party,p_amount:amt,p_account:acct,p_allocations:alloc}));}
async function transferView(){const cr=cart.t||[];
  const rowsHtml=cr.map((x,i)=>`<tr><td class="c-n">${i+1}</td><td><b>${e(by(C.products,x.product_id).name)}</b></td><td class="c-q">${x.qty}</td><td class="c-x"><button class="danger" onclick="cart.t.splice(${i},1);R('soft')">حذف</button></td></tr>`).join('');
  return `${trDetHtml('stk')}<h2>تحويل مخزني</h2>
  <div class="card tr-card">
    <div class="tr-route">
      <label class="tr-f"><span>من مخزن</span><select id="tf">${O(C.warehouses)}</select></label>
      <div class="tr-arrow" aria-hidden="true">←</div>
      <label class="tr-f"><span>إلى مخزن</span><select id="tt">${O(C.warehouses)}</select></label>
    </div>
    <div class="tr-add">
      <label class="tr-f grow"><span>الصنف</span><select id="til">${O(C.products.filter(p=>p.active))}</select></label>
      <label class="tr-f"><span>الكمية</span><input id="tiq" type="number" value="1" inputmode="decimal"></label>
      <button onclick="const p=v('til'),q=n('tiq');if(!(q>0))return alert('الكمية لازم تكون أكبر من صفر');const s=cart.t.find(x=>x.product_id===p);if(s)s.qty+=q;else cart.t.push({product_id:p,qty:q});R('soft')">إضافة للتحويل</button>
    </div>
    <div class="tr-table">${cr.length?`<table class="doc-tbl"><thead><tr><th class="c-n">#</th><th>الصنف</th><th class="c-q">الكمية</th><th class="c-x"></th></tr></thead><tbody>${rowsHtml}</tbody></table>`:'<div class="tr-empty">لم تُضف أصناف للتحويل بعد.</div>'}</div>
    <label class="tr-f"><span>ملاحظات</span><textarea id="tn" rows="2" placeholder="اختياري"></textarea></label>
    <div class="tr-actions"><button onclick="act(async()=>{if(v('tf')===v('tt'))throw Error('اختر مخزنين مختلفين');if(!cart.t.length)throw Error('أضف بندًا');await rpc('create_stock_transfer',{p_from:v('tf'),p_to:v('tt'),p_items:cart.t,p_notes:v('tn')});cart.t=[]})">حفظ التحويل</button></div>
  </div>
  <div class="card">${await stkTransfersHtml()}</div>`;}
async function stocktakeView(){let L=[];if(stk){const{data,error}=await sb.from('stocktake_items').select('*,products(name)').eq('stocktake_id',stk.id).order('id');if(error)throw error;L=data||[]}window._stkL=L;return `<h2>الجرد</h2><div class="card np"><div class="row"><select id="sw">${O(C.warehouses)}</select><button onclick="act(async()=>{stk={id:await rpc('create_stocktake',{p_warehouse:v('sw')})}})">بدء جرد جديد</button></div>${stk?`<p>الجرد الحالي: <span class="pill">جرد #${e(stk.id.slice(-6).toUpperCase())}</span></p>${T(['الصنف','المتوقع','الفعلي'],L.map((x,i)=>[e((x.products||{}).name),x.expected_qty,`<input id="sq${i}" type="number" step="0.001" value="${x.actual_qty??x.expected_qty}" style="width:100px">`]))}<button onclick="stkApprove('${stk.id}')">اعتماد الجرد</button>`:''}</div><div class="card">${T(['رقم','التاريخ','المخزن','الحالة'],(await g('stocktakes','date')).reverse().map(x=>[e(x.number),x.date,e(by(C.warehouses,x.warehouse_id).name),x.status]))}</div>`}

function csvEscape(x){const s=String(x??'');return /[",\n]/.test(s)?'"'+s.replace(/"/g,'""')+'"':s}
async function exportData(kind){const rows=await g(kind,'created_at');downloadCsv(kind+'.csv',rows)}
function downloadTemplate(kind){const templates={products:[{name:'',code:'',barcode:'',category:'',unit:'',purchase_price:'',sale_price:'',wholesale_price:'',min_stock:'',reorder_qty:'',safety_stock:'',lead_time_days:'',notes:''}],customers:[{name:'',phone:'',email:'',address:'',credit_limit:'',payment_terms_days:'',opening_balance:'',notes:''}],suppliers:[{name:'',phone:'',email:'',address:'',payment_terms_days:'',opening_balance:'',notes:''}],opening_stock:[{code:'',qty:''}]};downloadCsv(kind+'_template.csv',templates[kind]||[])}
function downloadCsv(filename,rows){if(!rows.length)return alert('لا توجد بيانات للتصدير');const keys=Object.keys(rows[0]);const body=[keys.map(csvEscape).join(','),...rows.map(r=>keys.map(k=>csvEscape(r[k])).join(','))].join('\n');const blob=new Blob([String.fromCharCode(0xFEFF)+body],{type:'text/csv;charset=utf-8'});const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=filename;a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000)}
function parseCsv(text){const rows=[];let row=[],cell='',quote=false;for(let i=0;i<text.length;i++){const ch=text[i];if(ch==='"'){if(quote&&text[i+1]==='"'){cell+='"';i++}else quote=!quote}else if(ch===','&&!quote){row.push(cell);cell=''}else if((ch==='\n'||ch==='\r')&&!quote){if(ch==='\r'&&text[i+1]==='\n')i++;row.push(cell);if(row.some(x=>x.trim()!==''))rows.push(row);row=[];cell=''}else cell+=ch}row.push(cell);if(row.some(x=>x.trim()!==''))rows.push(row);if(!rows.length)return[];const heads=rows.shift().map(x=>x.trim());return rows.map(r=>Object.fromEntries(heads.map((h,i)=>[h,(r[i]??'').trim()])))}
async function importCsv(kind,input){const file=input.files?.[0];if(!file)return;const text=await file.text();const rows=parseCsv(text);if(!rows.length)return alert('الملف لا يحتوي صفوفًا');const count=await rpc(kind==='products'?'import_products_json':kind==='customers'?'import_customers_json':'import_suppliers_json',{p_rows:rows});alert('تم استيراد '+count+' صف');input.value='';await act(async()=>{})}
async function importOpeningStock(input){const file=input.files?.[0];if(!file)return;const wh=v('osw');if(!wh)return alert('اختر المخزن');const rows=parseCsv(await file.text());if(!rows.length)return alert('الملف لا يحتوي صفوفًا');const count=await rpc('import_opening_stock_json',{p_warehouse:wh,p_rows:rows});alert('تم استيراد '+count+' رصيد');input.value='';await loadAll();await R()}
async function dataView(){const role=me.role;const products=await g('products','name');const customers=await g('customers','name');const suppliers=await g('suppliers','name');const finance=role==='admin'||role==='accountant';return `${sectionHead('استيراد وتصدير البيانات','استيراد CSV للبيانات الأساسية وتصدير نسخة قابلة للفتح في Excel.')}<div class="report-cards">
<div class="card"><div class="card-title"><b>الأصناف</b><span class="trace-badge">${products.length} سجل</span></div><div class="row"><button class="btn soft" onclick="exportData('products')">تصدير CSV</button>${['admin','store'].includes(role)?`<label class="btn" style="display:inline-flex;align-items:center;justify-content:center;cursor:pointer">استيراد CSV<input type="file" accept=".csv,text/csv" style="display:none" onchange="importCsv('products',this)"></label>`:''}</div><p class="muted">الأعمدة الأساسية: name, code, barcode, category, unit, purchase_price, sale_price, wholesale_price, min_stock, reorder_qty, safety_stock, lead_time_days, notes.</p><button class="linkbtn" onclick="downloadTemplate('products')">تحميل نموذج CSV</button></div>
<div class="card"><div class="card-title"><b>العملاء</b><span class="trace-badge">${customers.length} سجل</span></div><div class="row"><button class="btn soft" onclick="exportData('customers')">تصدير CSV</button>${['admin','accountant','sales'].includes(role)?`<label class="btn" style="display:inline-flex;align-items:center;justify-content:center;cursor:pointer">استيراد CSV<input type="file" accept=".csv,text/csv" style="display:none" onchange="importCsv('customers',this)"></label>`:''}</div><p class="muted">الأعمدة الأساسية: name, phone, email, address, credit_limit, payment_terms_days, opening_balance, notes.</p><button class="linkbtn" onclick="downloadTemplate('customers')">تحميل نموذج CSV</button></div>
<div class="card"><div class="card-title"><b>الموردون</b><span class="trace-badge">${suppliers.length} سجل</span></div><div class="row"><button class="btn soft" onclick="exportData('suppliers')">تصدير CSV</button>${['admin','accountant','store'].includes(role)?`<label class="btn" style="display:inline-flex;align-items:center;justify-content:center;cursor:pointer">استيراد CSV<input type="file" accept=".csv,text/csv" style="display:none" onchange="importCsv('suppliers',this)"></label>`:''}</div><p class="muted">الأعمدة الأساسية: name, phone, email, address, payment_terms_days, opening_balance, notes.</p><button class="linkbtn" onclick="downloadTemplate('suppliers')">تحميل نموذج CSV</button></div>${['admin','accountant','store'].includes(role)?`<div class="card"><div class="card-title"><b>الرصيد الافتتاحي للمخزون</b><span class="trace-badge">استيراد CSV</span></div><div class="row"><select id="osw">${O(C.warehouses)}</select><label class="btn" style="display:inline-flex;align-items:center;justify-content:center;cursor:pointer">استيراد ملف<input type="file" accept=".csv,text/csv" style="display:none" onchange="importOpeningStock(this)"></label><button class="btn soft" onclick="downloadTemplate('opening_stock')">تحميل نموذج</button></div><p class="muted">استخدم code أو barcode و qty. سيتم تطبيق الكميات على المخزن المختار من خلال حركة رصيد افتتاحي.</p></div>`:``}
${finance?`<div class="card"><div class="card-title"><b>إرشادات Go-Live</b></div><p>ابدأ بتصدير نسخة احتياطية، ثم استورد الأصناف/العملاء/الموردين، ثم أدخل الأرصدة الافتتاحية، وبعدها ابدأ الحركات اليومية.</p></div>`:''}</div>`}
function syncTrackFields(){const p=by(C.products,v('tp'));if(!p.id)return;const b=$('#tb'),s=$('#ts'),e1=$('#te');if(b)b.checked=!!p.track_batch;if(s)s.checked=!!p.track_serial;if(e1)e1.checked=!!p.track_expiry}
async function traceView(){const TP=C.products.filter(p=>p.active&&(p.track_batch||p.track_serial||p.track_expiry));const [lots,serials,mrp]=await Promise.all([g('inventory_lot_stock','lot_no'),g('inventory_serial_stock','serial_no'),rpc('mrp_replenishment',{p_warehouse:null})]);return `${sectionHead('تتبع المخزون وMRP','إدارة Batch / Serial / Expiry ومقترحات إعادة التوريد بناءً على المخزون والطلبات المفتوحة.')}<div class="card np"><button class="btn soft" onclick="runAdvancedInventoryTest()">اختبار التتبع وMRP والاستيراد</button><div id="advancedTestBox" class="mt10"></div></div>
<div class="card form-card"><div class="card-title"><b>تفعيل التتبع للصنف</b><span class="trace-badge">${TP.length} أصناف متتبعة</span></div><div class="row"><select id="tp" onchange="syncTrackFields()"><option value="">اختر صنفًا</option>${C.products.filter(p=>p.active).map(p=>`<option value="${p.id}">${e(p.name)} — ${p.track_batch?'Batch ':''}${p.track_serial?'Serial ':''}${p.track_expiry?'Expiry':''}</option>`).join('')}</select><label><input type="checkbox" id="tb"> Batch</label><label><input type="checkbox" id="ts"> Serial</label><label><input type="checkbox" id="te"> Expiry</label><button class="btn" onclick="act(()=>rpc('set_product_tracking',{p_product:v('tp'),p_track_batch:$('#tb').checked,p_track_serial:$('#ts').checked,p_track_expiry:$('#te').checked}))">حفظ إعداد التتبع</button></div></div>
<div class="report-cards"><div class="card form-card"><div class="card-title"><b>استلام مخزون متتبع</b></div><div class="row"><select id="rp">${O(TP.length?TP:C.products.filter(p=>p.active))}</select><select id="rw">${O(C.warehouses)}</select><input id="rql" type="text" placeholder="رقم التشغيلة (عند الحاجة)"><input id="re" type="date"><input id="rc" type="number" placeholder="تكلفة الوحدة"><input id="rq" type="number" min="0.001" value="1" placeholder="الكمية"><textarea id="rs" rows="2" placeholder="Serials: واحد في كل سطر"></textarea><button class="btn" onclick="act(()=>rpc('receive_tracked_stock',{p_product:v('rp'),p_warehouse:v('rw'),p_qty:n('rq'),p_unit_cost:n('rc'),p_lot_no:v('rql')||null,p_expiry:v('re')||null,p_serials:v('rs')?v('rs').split(/\n|,/).map(x=>x.trim()).filter(Boolean):[],p_doc_type:'tracked_receipt',p_doc_id:null}))">استلام</button></div></div>
<div class="card form-card"><div class="card-title"><b>صرف مخزون متتبع</b></div><div class="row"><select id="ip">${O(TP.length?TP:C.products.filter(p=>p.active))}</select><select id="iw">${O(C.warehouses)}</select><input id="il" placeholder="رقم التشغيلة"><input id="iq" type="number" min="0.001" value="1"><textarea id="is" rows="2" placeholder="Serials: واحد في كل سطر"></textarea><button class="btn" onclick="act(()=>rpc('issue_tracked_stock',{p_product:v('ip'),p_warehouse:v('iw'),p_qty:n('iq'),p_lot_no:v('il')||null,p_serials:v('is')?v('is').split(/\n|,/).map(x=>x.trim()).filter(Boolean):[],p_doc_type:'tracked_issue',p_doc_id:null}))">صرف</button></div></div></div>
<div class="card form-card"><div class="card-title"><b>توافر البضاعة والعجز</b><span class="muted">كمية كل صنف في كل مخزن، وحالة التوفر وحدّ النقص.</span></div><div class="row"><select id="iavw"><option value="">كل المخازن</option>${O(C.warehouses)}</select><button class="btn soft" onclick="showInventoryAvailability()">تحديث</button></div><div id="availabilityBox"></div></div>
<div class="card form-card"><div class="card-title"><b>بطاقة حركة الصنف</b><span class="muted">وارد / صادر / تسوية / تحويل مع الرصيد قبل وبعد.</span></div><div class="row"><select id="scprod"><option value="">اختر الصنف</option>${O(C.products)}</select><select id="scwh"><option value="">كل المخازن</option>${O(C.warehouses)}</select><input id="scfrom" type="date"><input id="scto" type="date" value="${new Date().toISOString().slice(0,10)}"><button class="btn soft" onclick="showStockCard()">عرض الحركة</button></div><div id="stockCardBox"></div></div>
<div class="card"><div class="card-title"><b>رصيد التشغيلات</b></div>${lots.length?T(['الصنف','التشغيلة','الصلاحية','المخزن','الكمية','الحالة'],lots.map(x=>[e(by(C.products,x.product_id).name),e(x.lot_no),x.expiry_date||'—',e(by(C.warehouses,x.warehouse_id).name),fmt(x.qty),x.expired?chip('منتهي','danger'):chip('سليم','success')])):'<div class="empty">لا توجد تشغيلات.</div>'}</div>
<div class="card"><div class="card-title"><b>Serials</b></div>${serials.length?T(['الصنف','Serial','الحالة','المخزن','الصلاحية'],serials.slice(0,200).map(x=>[e(by(C.products,x.product_id).name),e(x.serial_no),chip(x.status,x.status==='Available'?'success':'warning'),e(by(C.warehouses,x.warehouse_id).name)||'—',x.expired?chip('منتهي','danger'):'—'])):'<div class="empty">لا توجد Serials.</div>'}</div>
<div class="card"><div class="card-title"><b>MRP / اقتراحات إعادة التوريد</b></div>${mrp.length?T(['الصنف','المخزن','متاح','وارد','محجوز','المتوقع','الحد','Safety','اقتراح الشراء','Lead Time'],mrp.slice(0,200).map(x=>[e(x.product_name),e(by(C.warehouses,x.warehouse_id).name),fmt(x.on_hand),fmt(x.incoming),fmt(x.committed),fmt(x.projected),fmt(x.min_stock),fmt(x.safety_stock),fmt(x.suggested_qty),x.lead_time_days])):'<div class="empty success">لا توجد اقتراحات إعادة توريد حاليًا.</div>'}</div>`}
async function showInventoryAvailability(){const box=$('#availabilityBox');if(!box)return;box.innerHTML='<p class="muted">جاري التحميل...</p>';try{const rows=await rpc('inventory_availability',{p_warehouse:v('iavw')||null});box.innerHTML=rows.length?T(['الصنف','المخزن','المتاح','الحد الأدنى','كمية إعادة الطلب','العجز','الحالة'],rows.slice(0,300).map(x=>[e(x.product_name),e(x.warehouse_name),fmt(x.on_hand),fmt(x.min_stock),fmt(x.reorder_qty),fmt(x.shortage_qty),chip(x.status,x.status==='متوفر'?'success':x.status==='عجز'?'warning':'danger')])):'<div class="empty success">لا يوجد عجز حاليًا.</div>'}catch(x){box.innerHTML='<div class="bad">'+e(x.message||x)+'</div>'}}
async function showStockCard(){const box=$('#stockCardBox');if(!box)return;const p=v('scprod');if(!p)return alert('اختر الصنف');box.innerHTML='<p class="muted">جاري التحميل...</p>';try{const from=v('scfrom')||'1900-01-01',to=v('scto')||new Date().toISOString().slice(0,10),rows=await rpc('product_stock_card',{p_product:p,p_warehouse:v('scwh')||null,p_from:from,p_to:to});box.innerHTML=rows.length?T(['التاريخ','المخزن','الحركة','الكمية','قبل','بعد','المستند'],rows.map(x=>[x.movement_date,e(by(C.warehouses,x.warehouse_id).name),e(x.movement_type),fmt(x.qty),fmt(x.qty_before),fmt(x.qty_after),e(x.doc_type||'—')])):'<div class="empty">لا توجد حركات.</div>'}catch(x){box.innerHTML='<div class="bad">'+e(x.message||x)+'</div>'}}

async function runFinalSuite(){return withLoading(async()=>{
  const box=$('#enterpriseTestBox');
  box.innerHTML='<p>جاري تشغيل فحص Go-Live النهائي...</p>';
  try{
    const r=await rpc('run_final_go_live_suite',{});
    const pre=r.preflight||{};
    const rows=[
      ['enterprise',r.enterprise?.ok===true],
      ['advanced inventory',r.advanced?.ok===true],
      ['RLS enabled on public tables',+(pre.rls_missing_tables||0)===0],
      ['no anon table privileges',+(pre.anon_table_privileges||0)===0],
      ['no anon-executable functions',+(pre.anon_executable_functions||0)===0],
      ['security-definer guards',+(pre.weak_security_definer_functions||0)===0],
      ['journal balanced',+(pre.unbalanced_journal_entries||0)===0],
      ['invoice paid sync',+(pre.sales_paid_mismatches||0)===0 && +(pre.purchase_paid_mismatches||0)===0],
      ['serial / lot integrity',+(pre.invalid_serial_rows||0)===0 && +(pre.negative_lot_balances||0)===0],
      ['test data cleaned',+(pre.test_data_residue||0)===0] 
    ];
    box.innerHTML=`<div class="test-summary ${r.ok?'ok':'fail'}">${r.ok?'نجح فحص Go-Live النهائي':'ما زال يحتاج معالجة'}</div>`+rows.map(x=>`<div class="test-row ${x[1]?'pass':'fail'}"><span>${x[1]?ico('check'):ico('x')}</span><b>${e(x[0])}</b><small></small></div>`).join('')+(r.stage?`<p class="muted">المرحلة: ${e(r.stage)}</p>`:'');
  }catch(x){box.innerHTML=`<div class="bad">${e(x.message||x)}</div>`}
},'جاري فحص Go-Live النهائي...','يتم اختبار الأمان والعمليات والتكاملات')}

async function reportsView(){const today=new Date().toISOString().slice(0,10);const [ca,sa]=await Promise.all([rpc('customer_aging',{p_as_of:today}),rpc('supplier_aging',{p_as_of:today})]);return `<h2>التقارير</h2><div class="card"><b>أعمار ديون العملاء</b>${T(['العميل','حالي','1-30','31-60','61-90','90+','رصيد غير مخصص','الصافي'],ca.map(x=>[e(x.name),fmt(x.current_amt),fmt(x.d1_30),fmt(x.d31_60),fmt(x.d61_90),fmt(x.d90_plus),fmt(x.unallocated_credit),fmt(x.total)]))}</div><div class="card"><b>أعمار ديون الموردين</b>${T(['المورد','حالي','1-30','31-60','61-90','90+','دفعات غير مخصصة','الصافي'],sa.map(x=>[e(x.name),fmt(x.current_amt),fmt(x.d1_30),fmt(x.d31_60),fmt(x.d61_90),fmt(x.d90_plus),fmt(x.unallocated_credit),fmt(x.total)]))}</div>`}
async function accountsView(){const A=await rpc('trial_balance',{});return `<h2>الحسابات</h2><div class="card np"><button onclick="act(async()=>{const n=await rpc('rebuild_journal',{});alert('تم تحديث القيود: '+n+' مستند')})">ترحيل القيود</button><button class="s" onclick="journalForm()">قيد يومية يدوي</button></div><div class="card"><b>ميزان المراجعة</b>${T(['الكود','الحساب','النوع','مدين','دائن','الرصيد'],A.map(a=>[e(a.code),e(a.name),a.type,fmt(a.debit),fmt(a.credit),fmt(a.balance)]))}</div>`}
function journalForm(){const opts=C.accounts||[];let A=opts.length?opts:[];if(!A.length){alert('الحسابات يتم تحميلها داخل شاشة الحسابات.');return}$('#app').insertAdjacentHTML('beforeend',`<div id="jm" style="position:fixed;inset:0;background:rgba(16,28,44,.5);display:grid;place-items:center;padding:15px"><div class="card" style="width:min(760px,100%)"><h3>قيد يومية يدوي</h3><input id="jd" type="date" value="${new Date().toISOString().slice(0,10)}"><input id="jx" placeholder="البيان" style="width:55%"><div id="jl"></div><button class="s" onclick="addJournalRow()">+ سطر</button><button onclick="saveJournal()">حفظ القيد</button><button class="danger" onclick="$('#jm').remove()">إغلاق</button></div></div>`);for(let i=0;i<2;i++)addJournalRow()}
function addJournalRow(){const el=$('#jl');if(!el)return;const A=C.accounts||[];const opts=A.map(a=>`<option value="${e(a.code)}">${e(a.code)} - ${e(a.name)}</option>`).join('');el.insertAdjacentHTML('beforeend',`<div class="row jrow"><select class="jacc">${opts}</select><input class="jdv" type="number" placeholder="مدين"><input class="jcv" type="number" placeholder="دائن"></div>`) }
async function saveJournal(){const rows=[...document.querySelectorAll('.jrow')].map(r=>({account_code:r.querySelector('.jacc').value,debit:+r.querySelector('.jdv').value||0,credit:+r.querySelector('.jcv').value||0})).filter(x=>x.debit||x.credit);await act(async()=>{await rpc('create_manual_journal',{p_date:v('jd'),p_description:v('jx'),p_lines:rows});$('#jm').remove()})}
async function employeesView(){const L=await g('employees','name');return `<h2>الموظفون</h2><div class="card np"><div class="row"><input id="en" placeholder="الاسم"><input id="ej" placeholder="الوظيفة"><input id="eh" placeholder="الهاتف"><input id="es" type="number" placeholder="المرتب"><input id="ed2" type="date"><button onclick="act(()=>ins('employees',{name:v('en'),job:v('ej'),phone:v('eh'),salary:n('es'),joining_date:v('ed2')||null}))">إضافة</button></div></div><div class="card">${T(['الاسم','الوظيفة','الهاتف','المرتب','الحالة'],L.map(x=>[e(x.name),e(x.job),e(x.phone),fmt(x.salary),x.active?'نشط':'موقوف']))}</div>`}
async function loadPayrollAdjustments(){
  const emp=v('pe'),mon=v('pmo');
  if(!emp||!mon)return;
  try{
    const r=await rpc('employee_adjustment_totals',{p_employee:emp,p_month:mon+'-01'});
    const row=Array.isArray(r)?r[0]:r;
    if($('#pbn'))$('#pbn').value=+(row?.rewards||0);
    if($('#pd'))$('#pd').value=+(row?.penalties||0);
    toast('تم تحميل المكافآت والجزاءات المعتمدة للشهر');
  }catch(x){toast('تعذر تحميل المكافآت والجزاءات المعتمدة')}
}
function payslipRows(x,E){return [['الموظف',e(by(E,x.employee_id).name||'')],['الشهر',x.month.slice(0,7)],['الأساسي',fmt(x.basic)],['إضافي',fmt(x.overtime)],['مكافآت',fmt(x.bonus)],['سلف',fmt(x.advances)],['خصومات',fmt(x.deductions)],['غياب',fmt(x.absence_deductions)],['الصافي',fmt(x.net)],['الحالة',x.paid?'مدفوع':'غير مدفوع']]}
function payShow(id){window._pv=id;R()}
async function payPrint(id){const[E,L]=await Promise.all([g('employees','name'),g('payroll','month')]);const x=L.find(r=>r.id===id);if(!x)return toast('لم يتم العثور على الكشف');printHtml('كشف مرتب',`<h2>كشف مرتب</h2><table style="width:100%;border-collapse:collapse"><tbody>${payslipRows(x,E).map(r=>`<tr><th style="background:#E6F5F0;text-align:right;width:30%;padding:7px;border:1px solid #E3E0D4">${r[0]}</th><td style="padding:7px;border:1px solid #E3E0D4">${r[1]}</td></tr>`).join('')}</tbody></table>`)}
async function payrollView(){const E=await g('employees','name'),L=await g('payroll','month');const pvr=window._pv?L.find(x=>x.id===window._pv):null,pvHtml=pvr?`<div class="card"><div class="card-title"><b>تفاصيل الكشف</b><div><button class="s" onclick="payPrint('${pvr.id}')">طباعة</button> <button class="s" onclick="window._pv=null;R()">إغلاق</button></div></div>${T(['البند','القيمة'],payslipRows(pvr,E))}</div>`:'';return `<h2>المرتبات</h2><div class="card np"><div class="row"><select id="pe" onchange="loadPayrollAdjustments()">${O(E)}</select><input id="pmo" type="month" onchange="loadPayrollAdjustments()"><input id="pb2" type="number" placeholder="الأساسي"><input id="po" type="number" placeholder="إضافي"><input id="pbn" type="number" placeholder="مكافأة"><input id="pa" type="number" placeholder="سلف"><input id="pd" type="number" placeholder="خصومات"><input id="pab" type="number" placeholder="غياب"><select id="pac">${O(C.accts)}</select><button class="btn soft" onclick="loadPayrollAdjustments()" title="يعيد جلب المكافآت والجزاءات والسلف المعتمدة لهذا الموظف في هذا الشهر">جلب المعتمد للشهر</button><button onclick="act(async()=>{if(!v('pmo'))throw Error('اختر الشهر');await ins('payroll',{employee_id:v('pe'),month:v('pmo')+'-01',basic:n('pb2')||+(by(E,v('pe')).salary),overtime:n('po'),bonus:n('pbn'),advances:n('pa'),deductions:n('pd'),absence_deductions:n('pab')})})">إنشاء كشف</button></div><p class="muted">اختر الموظف والشهر وستُحمَّل المكافآت والجزاءات المعتمدة تلقائيًا، ويمكن تعديل القيم قبل إنشاء الكشف. زر «جلب المعتمد للشهر» لإعادة التحميل فقط. الكشوف المنشأة تظهر في الجدول بالأسفل، ومن عمود الإجراءات: عرض، طباعة، دفع.</p></div>${pvHtml}<div class="card">${T(['الموظف','الشهر','الأساسي','الصافي','الحالة',''],L.reverse().map(x=>[e(by(E,x.employee_id).name),x.month.slice(0,7),fmt(x.basic),fmt(x.net),x.paid?'مدفوع':'غير مدفوع',`<button class="s" onclick="payShow('${x.id}')">عرض</button> <button class="s" onclick="payPrint('${x.id}')">طباعة</button> ${x.paid?'':`<button onclick="act(()=>rpc('pay_payroll',{p_payroll:'${x.id}',p_account:v('pac')}))">دفع</button>`}`]))}</div>`}
async function retView(){const SI=await g('sales_invoices','date'),PI=await g('purchase_invoices','date'),sel=window._rk!=='p',L=sel?SI:PI;return `<h2>المرتجعات</h2><div class="card np"><select id="rk" onchange="window._rk=v('rk');RT=null;R()"><option value="s" ${sel?'selected':''}>مرتجع مبيعات</option><option value="p" ${sel?'':'selected'}>مرتجع مشتريات</option></select><select id="ri">${L.map(x=>`<option value="${x.id}">${e(x.number)} — ${fmt(x.total)}</option>`).join('')}</select><button class="s" onclick="loadRet()">عرض البنود</button>${RT?T(['المنتج','الكمية','كمية المرتجع'],RT.items.map((x,i)=>[e(by(C.products,x.product_id).name),x.qty,`<input id="rq${i}" type="number" step="0.001" value="0" style="width:90px">`]))+`<button onclick="act(async()=>{const items=${JSON.stringify(RT.items).replace(/</g,'\\u003c')}.map((x,i)=>({product_id:x.product_id,qty:n('rq'+i)})).filter(x=>x.qty>0);await rpc('${RT.s?'create_sales_return':'create_purchase_return'}',{p_invoice:'${RT.id}',p_items:items});RT=null})">حفظ المرتجع</button>`:''}</div>`}
async function loadRet(){const s=v('rk')==='s',id=v('ri');const{data,error}=await sb.from(s?'sales_invoice_items':'purchase_invoice_items').select('product_id,qty').eq('invoice_id',id);if(error)throw error;RT={s,id,items:data||[]};R()}
async function quotationsView(){const L=await g('quotations','date'),tot=cart.q.reduce((a,l)=>a+l.qty*l.price-l.discount,0);return `<h2>عروض الأسعار</h2><div class="card np"><div class="row"><select id="ip">${O(C.customers)}</select><select id="il">${O(C.products.filter(p=>p.active))}</select><input id="iq" type="number" value="1" style="width:80px"><input id="ir" type="number" placeholder="السعر"><input id="id" type="number" placeholder="خصم"><button class="s" onclick="addLine('q')">+ بند</button></div>${cartTable('q')}<p>الإجمالي: <b>${fmt(tot)}</b></p><input id="vu" type="date"><button onclick="act(async()=>{await rpc('create_quotation',{p_customer:v('ip'),p_valid:v('vu')||null,p_items:cart.q});cart.q=[]})">حفظ العرض</button></div><div class="card">${T(['رقم','التاريخ','العميل','صالح حتى','الحالة',''],L.reverse().map(x=>[e(x.number),x.date,e(by(C.customers,x.customer_id).name),x.valid_until||'',x.status,x.status==='Open'?`<button onclick="act(()=>rpc('quotation_to_order',{p_quo:'${x.id}',p_warehouse:'${(C.warehouses[0]||{}).id}'}))">تحويل لأمر بيع</button>`:'']))}</div>`}
async function ordersView(){const L=await g('sales_orders','date');return `<h2>أوامر البيع</h2><div class="card np"><select id="oa">${O(C.accts)}</select><input id="op" type="number" placeholder="المدفوع عند التحويل"></div><div class="card">${T(['رقم','التاريخ','العميل','الحالة',''],L.reverse().map(x=>[e(x.number),x.date,e(by(C.customers,x.customer_id).name),x.status,x.status==='Confirmed'?`<button onclick="act(()=>rpc('order_to_invoice',{p_order:'${x.id}',p_paid:n('op'),p_account:n('op')>0?v('oa'):null,p_method:n('op')>0?'cash':'credit'}))">تحويل لفاتورة</button> <button class="s" onclick="act(()=>rpc('cancel_order',{p_order:'${x.id}'}))">إلغاء</button>`:'']))}</div>`}
async function usersView(){const L=await g('profiles','created_at');return `<h2>المستخدمون</h2><div class="card">${T(['الاسم','البريد','الدور','مفعّل'],L.map(u=>[e(u.name),e(u.username),`<select onchange="act(()=>upd('profiles','${u.id}',{role:this.value}))">${['admin','accountant','sales','store'].map(r=>`<option ${u.role===r?'selected':''}>${r}</option>`).join('')}</select>`,`<input type="checkbox" ${u.active?'checked':''} ${u.id===me.id?'disabled':''} onchange="act(()=>upd('profiles','${u.id}',{active:this.checked}))">`]))}</div>`}
const sRow=(onclick,icon,title,desc)=>`<button class="st-row" onclick="${onclick}"><span class="st-ic">${icon}</span><span class="st-tx"><b>${title}</b><small>${desc}</small></span><span class="st-ch">‹</span></button>`;
const sLink=(id,icon,title,desc)=>can(id)?sRow(`go('${id}')`,icon,title,desc):'';
const sGroup=(cls,title,rows)=>{const body=rows.filter(Boolean).join('');return body?`<section class="st-group ${cls}"><h3>${title}</h3><div class="st-list">${body}</div></section>`:''};
async function settingsView(){const{data:s,error}=await sb.from('company_settings').select('*').single();if(error)throw error;const adm=me.role==='admin';
 const groups=[
  sGroup('st-g-co','الشركة',[adm?sLink('cosettings',ico('receipt'),'البيانات الأساسية للشركة','اسم الشركة والرقم الضريبي وبادئة الفواتير والضريبة والمخزون وحد الخصم واللوجو.'):'',adm?sLink('printcfg',ico('printer'),'تخصيص الطباعة','اللوجو واسم الشركة والعنوان ولون الخط الفاصل ونص أسفل الطباعة.'):'',adm?sLink('org',ico('building'),'الفروع ومراكز التكلفة','إدارة الهيكل التنظيمي ومراكز التكلفة.'):'',adm?sLink('period',ico('calendar'),'الفترات والإقفال','فتح وإقفال الفترات ومراقبة القيود.'):'']),
  sGroup('st-g-team','الفريق والصلاحيات',[adm?sLink('users',ico('users'),'المستخدمون والصلاحيات','إنشاء المستخدمين، تفعيلهم، واختيار تخصيص الصلاحيات لكل مستخدم.'):'',adm?sLink('appr',ico('check'),'الاعتمادات','إدارة طلبات الاعتماد والموافقات.'):'',adm?sLink('audit',ico('pulse'),'سجل العمليات','مراجعة العمليات والتغييرات.'):'']),
  sGroup('st-g-data','البيانات والنسخ',[sLink('data',ico('swap'),'الاستيراد والتصدير','CSV للبيانات الأساسية والأرصدة الافتتاحية.'),adm?sLink('fullbak',ico('save'),'النسخة الكاملة والاستعادة','نسخة كاملة تتنزل على جهازك (كل البيانات والمستخدمين والملفات)، واستعادتها.'):'',adm?sLink('int',ico('swaplr'),'التكاملات','إدارة الاتصالات والتكاملات الخارجية.'):'']),
  sGroup('st-g-acc','حسابي',[sRow('forgetDevice()',ico('lockkey'),'نسيت الجهاز ده','يلغي الجهاز المتذكر، والدخول الجاي يطلب كود التحقق.'),sRow('toggleDialect()','ع',`اللغة: ${({eg:'عامية مصرية',msa:'فصحى',en:'English'})[dialectMode()]||'عامية مصرية'}`,'اضغط عشان تبدّل بين العامية المصرية والفصحى والإنجليزي (على الجهاز ده).')]),
  sGroup('st-g-dev','المطور',[me.isDev?sLink('health',ico('heart'),'فحص الجاهزية','فحوصات الصحة وGo-Live.'):'',me.isDev?sRow("go('devset')",ico('gear'),'إعدادات المطور','قفل الموقع وفتحه، خروج كل الجلسات، تحديث الواجهة، والفحوصات.'):''])
 ].join('');
 return `${sectionHead('الإعدادات والإدارة','كل أدوات الإدارة في مكان واحد.')}
<div class="st-wrap">${groups}</div>
<div class="card offline-card"><b>النسخ الاحتياطي الكامل</b><p class="muted">النسخة الكاملة (قاعدة البيانات والمستخدمين والملفات) بتتعمل تلقائياً كل يوم على Google Drive، وبتتشفّر. الاستعادة حالياً بتتم من جهاز المطور.</p></div>`}
async function coSettingsView(){const{data:s,error}=await sb.from('company_settings').select('*').single();if(error)throw error;return `${sectionHead('البيانات الأساسية للشركة','بيانات الفواتير والضريبة والمخزون وحد الخصم.')}${coCardHtml(s)}`}
function printSettingsView(){return `${sectionHead('تخصيص الطباعة','إعدادات الطباعة لكل الكشوف والفواتير.')}${printCardHtml()}`}
// ----- التحقق الثنائي: إعدادات المطور (v1.69) -----
async function devMfaCard(){
  let st;try{st=await rpc('admin_mfa_state',{})}catch(x){return `<div class="card"><b>التحقق الثنائي للأدمن</b><p class="bad">تعذر تحميل الإعدادات: ${e(x.message||x)}</p></div>`}
  const methods=st.methods||['totp'];
  const all=[['totp','تطبيق Authenticator (Google / Microsoft)',true],['sms','رسالة SMS على الموبايل',false],['email','كود على الإيميل',false],['whatsapp','واتساب',false]];
  const admins=st.admins||[];
  const pending=admins.filter(a=>a.active&&!a.mfa).length;
  return `<div class="card"><div class="card-title"><b>التحقق الثنائي للأدمن</b> ${chip(st.require?'إجباري':'اختياري',st.require?'warning':'info')}</div>
    <p class="muted">اختار الطرق اللي تتقبل للتحقق. حالياً التطبيق بيدعم Authenticator بس، والباقي يتفتح لما نربط مزوّد له.</p>
    <div class="co-switches">${all.map(([id,lbl,ok])=>`<label class="co-switch"><input type="checkbox" class="mfa_m" value="${id}" ${methods.includes(id)?'checked':''} ${ok?'':'disabled'}><span><b>${e(lbl)}</b>${ok?'':'<small>قريباً</small>'}</span></label>`).join('')}</div>
    <div class="row-btns"><button class="s" onclick="devSaveMfaMethods()">حفظ الطرق</button></div>
    <p class="muted">لما الإجبار يتفعل، أي أدمن أو مطور مش مفعّل التحقق مش هيقدر يوصل للبيانات. ومش هيتفعل غير لما كل الأدمن يكونوا مفعّلين (${pending?'فيه '+pending+' لسه مش مفعّل':'كلهم مفعّلين'}).</p>
    <div class="row-btns"><button class="s" onclick="devToggleMfaRequire(${!st.require})">${st.require?'إيقاف الإجبار':'تفعيل الإجبار'}</button></div>
    ${T(['الاسم','الدور','التحقق'],admins.map(a=>[e(a.name||'—'),a.role==='developer'?'مطور':'أدمن',a.mfa?chip('مفعّل','success'):chip('مش مفعّل','warning')]))}
  </div>`;
}
async function devSaveMfaMethods(){const m=[...document.querySelectorAll('.mfa_m:checked')].map(x=>x.value);await act(async()=>{await rpc('admin_mfa_set_methods',{p_methods:m})})}
async function devToggleMfaRequire(on){if(on&&!confirm('نفعّل إجبار التحقق الثنائي؟ الأدمن اللي مش مفعّله مش هيقدر يوصل للبيانات.'))return;await act(async()=>{await rpc('admin_mfa_set',{p_require:on})})}
// ----- النسخة الكاملة واستعادتها (v1.69) -----
// الملف بيتشفّر في المتصفح (AES-GCM + PBKDF2) قبل ما يتنزل، فالباسوردات مش بتتنزل مفتوحة
const FB_ITER=310000;
const fbB64=buf=>{const a=new Uint8Array(buf);let s='';for(let i=0;i<a.length;i+=0x8000)s+=String.fromCharCode.apply(null,a.subarray(i,i+0x8000));return btoa(s)};
const fbUnB64=s=>Uint8Array.from(atob(s),c=>c.charCodeAt(0));
async function fbKey(pass,salt,iter){const base=await crypto.subtle.importKey('raw',new TextEncoder().encode(pass),'PBKDF2',false,['deriveKey']);return crypto.subtle.deriveKey({name:'PBKDF2',salt,iterations:iter,hash:'SHA-256'},base,{name:'AES-GCM',length:256},false,['encrypt','decrypt'])}
async function fbEncrypt(obj,pass){const salt=crypto.getRandomValues(new Uint8Array(16));const iv=crypto.getRandomValues(new Uint8Array(12));const k=await fbKey(pass,salt,FB_ITER);const ct=await crypto.subtle.encrypt({name:'AES-GCM',iv},k,new TextEncoder().encode(JSON.stringify(obj)));return JSON.stringify({format:'ERP-ENC-1',iter:FB_ITER,salt:fbB64(salt),iv:fbB64(iv),data:fbB64(ct)})}
async function fbDecrypt(text,pass){let j;try{j=JSON.parse(text)}catch(_){throw Error('الملف مش نسخة ERP صحيحة')}if(!j||j.format!=='ERP-ENC-1')throw Error('الملف مش نسخة ERP صحيحة');const k=await fbKey(pass,fbUnB64(j.salt),j.iter);let pt;try{pt=await crypto.subtle.decrypt({name:'AES-GCM',iv:fbUnB64(j.iv)},k,fbUnB64(j.data))}catch(_){throw Error('الباسورد غلط أو الملف اتعدّل')}return JSON.parse(new TextDecoder().decode(pt))}
function fbDownload(text,name){const blob=new Blob([text],{type:'application/octet-stream'});const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(a.href),2000)}
async function fbCall(name,body){const{data,error}=await sb.functions.invoke(name,{body});if(error){let m=error.message||'حصل خطأ';try{const j=await error.context.json();if(j&&j.error)m=j.error}catch(_){}throw Error(m)}if(data&&data.error)throw Error(data.error);return data}
function fullBakView(){
  if(!me||!['admin','developer'].includes(me.realRole))return `<div class="card"><p class="muted">هذه الصفحة للأدمن والمطور.</p></div>`;
  return `${sectionHead('النسخة الكاملة','نسخة كاملة تتنزل على جهازك: كل البيانات والإعدادات والمستخدمين وباسوردتهم وملفات الموقع. مستقلة عن النسخة اليومية على Google Drive.')}
  <div class="card"><div class="card-title"><b>تنزيل نسخة كاملة</b></div>
    <p class="muted">الملف بيتشفّر بالباسورد اللي تكتبه. لو نسيته، الملف مش هيتفتح.</p>
    <div class="fm-grid"><label class="fm-f"><span>باسورد النسخة (8 حروف على الأقل)</span><input id="fb_p1" type="password" autocomplete="new-password"></label><label class="fm-f"><span>اكتب الباسورد تاني</span><input id="fb_p2" type="password" autocomplete="new-password"></label></div>
    <div class="row-btns"><button class="btn" onclick="fbBackup()">تنزيل نسخة كاملة</button></div></div>
  ${me.isDev?`<div class="card"><div class="card-title"><b>استعادة نسخة</b></div>
    <p class="muted">الاستعادة للمطور بس. اختار ملف النسخة واكتب باسورده.</p>
    <div class="fm-grid"><label class="fm-f"><span>ملف النسخة (.erpbak)</span><input id="fb_file" type="file" accept=".erpbak"></label><label class="fm-f"><span>باسورد النسخة</span><input id="fb_rp" type="password" autocomplete="off"></label></div>
    <div class="row-btns"><button class="btn" onclick="fbPrepare()">فحص الملف</button></div>
    <div id="fbSummary"></div></div>`:''}`;
}
async function fbBackup(){
  try{
  const p=v('fb_p1')||'';
  if(p.length<8)return toast('الباسورد لازم يكون 8 حروف على الأقل');
  if(p!==(v('fb_p2')||''))return toast('الباسورد مش متطابق في الخانتين');
  await withLoading(async()=>{
    const data=await fbCall('full-backup',{});
    fbDownload(await fbEncrypt(data,p),'erp_full_backup_'+new Date().toISOString().slice(0,10)+'.erpbak');
    toast('اتنزلت النسخة الكاملة');
  },'جاري تجهيز النسخة الكاملة...','ممكن ياخد وقت لو ملفات الـ Storage كبيرة');
  }catch(x){alert('تعذر تنفيذ العملية: '+(x&&x.message?x.message:x));console.error(x)}
}
let fbRestoreData=null,fbRestorePass='',fbCheckInfo=null;
async function fbPrepare(){
  try{
  if(!me||!me.isDev)return;
  const f=document.getElementById('fb_file')?.files?.[0];const pass=v('fb_rp')||'';
  if(!f)return toast('اختار ملف النسخة الأول');
  if(!pass)return toast('اكتب باسورد النسخة');
  await withLoading(async()=>{
    const data=await fbDecrypt(await f.text(),pass);
    if(data.format!=='ERP-FULLBAK')throw Error('الملف ده مش نسخة كاملة');
    const st=await fbCall('full-restore',{mode:'check'});
    fbRestoreData=data;fbRestorePass=pass;fbCheckInfo=st;
    fbShowSummary(data,st);
  },'جاري فحص الملف...','بنفك التشفير ونتأكد من الداتا الحالية');
  }catch(x){alert('تعذر تنفيذ العملية: '+(x&&x.message?x.message:x));console.error(x)}
}
function fbShowSummary(data,st){
  const pub=data.public||{};
  const tabs=Object.keys(pub).filter(t=>(pub[t].rows||[]).length).length;
  const rows=Object.values(pub).reduce((a,t)=>a+(t.rows||[]).length,0);
  const users=(data.auth?.users?.rows||[]).length;
  const files=(data.storage?.files||[]).length;
  const warn=st.hasData
    ?`<div class="card bad"><b>فيه بيانات موجودة حالياً</b><p>الجداول اللي فيها داتا: ${st.tables.map(t=>e(t)).join('، ')}${st.storageFiles?` · ملفات: ${st.storageFiles}`:''}</p><p>الاستعادة هتمسح كل ده وتكتب النسخة مكانه. هنعمل نسخة أمان من الحالية الأول وتتنزل على جهازك.</p><label class="fm-f"><span>اكتب "استعادة" عشان تأكد</span><input id="fb_confirm" placeholder="استعادة"></label></div>`
    :`<p class="muted">الداتا الحالية فاضية، الاستعادة هتتم مباشرة.</p>`;
  document.getElementById('fbSummary').innerHTML=`<div class="card"><b>ملخص النسخة</b><p class="muted">تاريخ النسخة: ${e(new Date(data.created_at).toLocaleString(locOf()))}</p><p>جداول فيها داتا: ${tabs} · صفوف: ${rows} · مستخدمين: ${users} · ملفات: ${files}</p></div>${warn}<div class="row-btns"><button class="btn" onclick="fbRunRestore()">بدء الاستعادة</button></div>`;
}
async function fbRunRestore(){
  try{
  if(!fbRestoreData||!fbCheckInfo)return;
  if(fbCheckInfo.hasData&&(v('fb_confirm')||'')!=='استعادة')return toast('اكتب كلمة "استعادة" بالظبط عشان تكمل');
  if(!confirm('أكيد؟ الاستعادة هتكتب فوق البيانات الحالية. كل المستخدمين هيتقفلوا، ولازم كل حد يسجل دخول تاني بالباسورد من النسخة.'))return;
  await withLoading(async()=>{
    if(fbCheckInfo.hasData){
      const cur=await fbCall('full-backup',{});
      fbDownload(await fbEncrypt(cur,fbRestorePass),'erp_safety_before_restore_'+new Date().toISOString().slice(0,10)+'.erpbak');
    }
    const r=await fbCall('full-restore',{mode:'restore',data:fbRestoreData});
    fbRestoreData=null;fbRestorePass='';
    const errs=r.errors||[];
    document.getElementById('fbSummary').innerHTML=`<div class="card"><b class="good">تمت الاستعادة</b><p>الملفات اللي اترفعت: ${r.filesUploaded||0}${errs.length?` · فشل: ${errs.length}`:''}</p>${errs.length?`<details><summary>تفاصيل الفشل</summary><pre>${errs.map(x=>e(x)).join('\n')}</pre></details>`:''}<p class="muted">الجلسات اتقفلت، هنخرجك دلوقتي وتسجل دخول تاني.</p></div>`;
    setTimeout(async()=>{try{await sb.auth.signOut()}catch(_){}location.reload()},5000);
  },'جاري الاستعادة...','متقفلش الصفحة لحد ما تخلص');
  }catch(x){alert('تعذر تنفيذ العملية: '+(x&&x.message?x.message:x));console.error(x)}
}
async function runSmokeTest(){const box=$('#smokeResult');if(box)box.innerHTML='<p>جاري الاختبار...</p>';try{const r=await rpc('run_erp_smoke_test',{});const show=z=>typeof z==='object'&&z!==null?JSON.stringify(z):String(z??'');const rows=(r.results||[]).map(x=>{const p=x.pass?ico('check'):ico('x');const vals=Object.entries(x).filter(([k])=>!['test','pass'].includes(k)).map(([k,v])=>`${e(k)}=${e(show(v))}`).join(' | ');return`<div class="${x.pass?'good':'bad'}">${p} ${e(x.test)}${vals?' — '+vals:''}</div>`}).join('');if(box)box.innerHTML=`<div class="card"><b class="${r.ok?'good':'bad'}">${r.ok?'نجح اختبار النظام بالكامل':'فشل اختبار النظام'}</b>${rows}<p>تم تنظيف بيانات الاختبار: ${r.cleaned?'نعم':'لا'}</p></div>`}catch(x){if(box)box.innerHTML=`<div class="card bad">فشل تشغيل الاختبار: ${e(x.message||x)}</div>`}}
function openMobileNav(){const s=document.querySelector('.sidebar');const o=document.querySelector('.mobile-overlay');if(s)s.classList.add('open');if(o)o.classList.add('open');document.body.classList.add('menu-open')}
function closeMobileNav(){const s=document.querySelector('.sidebar');const o=document.querySelector('.mobile-overlay');if(s)s.classList.remove('open');if(o)o.classList.remove('open');document.body.classList.remove('menu-open')}
// --- Enterprise UI layer ---
const navOld = [['dash','الرئيسية'],['prod','الأصناف'],['cust','الأطراف'],['supp','الموردون'],['sales','المبيعات'],['dn','التسليم'],['purch','المشتريات'],['po','أوامر الشراء'],['grn','استلام المشتريات'],['ret','المرتجعات'],['quo','عروض الأسعار'],['ord','أوامر البيع'],['stmt','كشف الحساب'],['pay','التحصيل والمدفوعات'],['exp','المصروفات'],['cash','الخزينة والبنوك'],['bank','البنوك والتسويات'],['whs','المخازن'],['trf','التحويلات المخزنية'],['stk','الجرد'],['price','قوائم الأسعار'],['comm','العمولات'],['asset','الأصول الثابتة'],['emp','الموظفون'],['hr','الموارد البشرية'],['prl','المرتبات'],['period','الفترات والإقفال'],['org','الفروع ومراكز التكلفة'],['trace','تتبع المخزون / MRP'],['data','استيراد وتصدير'],['appr','الاعتمادات'],['taxdoc','المستندات الضريبية'],['users','المستخدمون'],['audit','سجل العمليات'],['health','فحص الجاهزية'],['int','التكاملات'],['set','الإعدادات والإدارة']];
const NAV2=[...navOld, ...NAV.filter(x=>['chk','jr','rep','shareholders'].includes(x[0])), ['profit','الأرباح بالتفاصيل'], ['bud','الموازنة والفعلي']];
const ROLE2={admin:'*',accountant:['dash','prod','cust','supp','sales','quo','ord','dn','ret','purch','po','grn','pay','chk','exp','bud','cash','bank','trf','stk','price','comm','asset','hr','emp','prl','rep','profit','jr','taxdoc','trace','appr','shareholders'],sales:['dash','prod','cust','sales','quo','ord','dn','ret','price','comm'],store:['dash','prod','po','grn','trf','stk','trace']};
P.admin='*'; P.accountant=ROLE2.accountant; P.sales=ROLE2.sales; P.store=ROLE2.store;
NAV.splice(0,NAV.length,...NAV2);
const HIDDEN_MODULES=new Set(['mfg','pos','proj']);
let customPermMode='role',customPerms=new Set();
const NAV_GROUPS=[
  ['الرئيسية',['dash'],'overview'],
  ['المبيعات',['sales','ord','quo','dn','ret','cust','price','comm'],'sales'],
  ['المشتريات',['purch','po','grn'],'purch'],
  ['المخزون',['prod','whs','trf','stk','trace'],'inventory'],
  ['الخزينة والبنوك',['cash','bank','chk','pay','exp'],'treasury'],
  ['المحاسبة والتقارير',['profit','bud','stmt','jr','rep','asset','taxdoc','shareholders'],'accounting'],
  ['الموظفون',['emp','hr','prl'],'hr'],
  ['الإعدادات والإدارة',['set'],'admin']
];
function visibleNav(id){return !HIDDEN_MODULES.has(id)&&can(id)}
function renderNavGroups(){
  const key='erp_v_nav_groups'; let state={}; try{state=JSON.parse(localStorage.getItem(key)||'{}')}catch{}
  const activeGroup=NAV_GROUPS.find(([,ids])=>ids.includes(view));
  return NAV_GROUPS.map(([title,ids,gid])=>{
    const items=ids.map(id=>NAV.find(x=>x[0]===id)).filter(x=>x&&visibleNav(x[0]));
    if(!items.length)return '';
    if(items.length===1&&items[0][1]===title)return `<a class="nav-single${view===items[0][0]?' on':''}" onclick="go('${items[0][0]}')"><span class="nav-dot"></span><span>${title}</span></a>`;
    const isActive=activeGroup&&activeGroup[2]===gid;
    const collapsed=state[gid]===undefined?(gid==='overview'||isActive?'':' collapsed'):(state[gid]?'':' collapsed');
    return `<section class="nav-group${collapsed}" data-group="${gid}"><div class="nav-group-title" onclick="toggleNavGroup('${gid}',event)"><span>${title}</span><button class="nav-toggle" aria-label="فتح ${title}">${collapsed?ico('chevr'):ico('chevd')}</button></div><div class="group-items">${items.map(x=>`<a class="${view===x[0]?'on':''}" onclick="go('${x[0]}');event.stopPropagation()"><span class="nav-dot"></span><span>${x[1]}</span></a>`).join('')}</div></section>`;
  }).join('')+`<div class="side-hint">القائمة مختصرة. الإدارة والاستيراد والنسخ الاحتياطي والصلاحيات داخل الإعدادات.</div>`;
}
function toggleNavGroup(gid,ev){ev.preventDefault();ev.stopPropagation();let state={};try{state=JSON.parse(localStorage.getItem('erp_v_nav_groups')||'{}')}catch{}const curOpen=state[gid]===undefined?(gid==='overview'||NAV_GROUPS.find(x=>x[2]===gid)?.[1].includes(view)):!!state[gid];const next={};Object.keys(state).forEach(k=>{next[k]=false});next[gid]=!curOpen;try{localStorage.setItem('erp_v_nav_groups',JSON.stringify(next))}catch{}R()}
function loadPermissionState(){customPermMode='role';customPerms=new Set();try{const x=JSON.parse(localStorage.getItem('erp_v_custom_perms')||'null');if(x&&x.user_id===me?.id){customPermMode=x.mode||'role';customPerms=new Set(Array.isArray(x.permissions)?x.permissions:[])}}catch{}}
async function loadMyPermissions(){loadPermissionState();if(!me||me.role==='admin')return;try{const r=await rpc('get_my_permissions',{});customPermMode=r?.mode||'role';customPerms=new Set(Array.isArray(r?.permissions)?r.permissions:[]);localStorage.setItem('erp_v_custom_perms',JSON.stringify({user_id:me.id,mode:customPermMode,permissions:[...customPerms]}))}catch{}}

function updateOnlineStatus(){const host=$('#netStatus');if(!host)return;if(navigator.onLine){host.innerHTML='<span class="online-pill"><i class="sync-dot"></i> متصل</span>'}else{host.innerHTML='<span class="offline-pill"><i class="sync-dot"></i> دون اتصال · وضع القراءة</span>'}}
async function cacheAppShell(){try{if('serviceWorker' in navigator) await navigator.serviceWorker.register('./sw.js')}catch{}}
window.addEventListener('online',()=>{updateOnlineStatus();toast('عاد الاتصال بالنظام')});
window.addEventListener('offline',()=>{updateOnlineStatus();toast('انقطع الاتصال — يمكنك متابعة البيانات المخزنة فقط')});

function chip(text,kind='info'){return `<span class="chip ${kind}">${e(text)}</span>`}
function sectionHead(title,sub=''){return `<div class="section-head"><div><h2>${title}</h2>${sub?`<p>${sub}</p>`:''}</div></div>`}
function money(x){return `<span class="money">${fmt(x)} ج.م</span>`}

async function dash(){
 const [a,b]=range(); const D=(await rpc('dashboard_v2',{p_from:a,p_to:b}))||{};
 const low=await g('low_stock');
 const finance=me.role==='admin'||me.role==='accountant';
 let recent=[]; try{recent=await g('sales_invoice_balances','date');recent=recent.slice(-8).reverse()}catch{}
 const hr=new Date().getHours();
 const greet=hr<12?'صباح الخير':hr<17?'مساء الخير':'مساء النور';
 const today=new Date().toLocaleDateString(locOf(),{weekday:'long',day:'numeric',month:'long',year:'numeric'});
 const periods=[['today','اليوم'],['week','آخر 7 أيام'],['month','هذا الشهر'],['custom','فترة مخصصة']];
 const num=x=>Number(x)||0;
 const profit=num(D.sales)-num(D.cogs)-num(D.expenses);
 const products=num(D.products), lowN=low.length;
 const healthy=products>0?Math.max(0,Math.min(100,Math.round((products-lowN)/products*100))):100;
 const rec=num(D.receivables), pay=num(D.payables), mx=Math.max(rec,pay,1);
 const pctOfMin=(s,m)=>{const n=num(m);return n<=0?100:Math.max(0,Math.min(100,Math.round(num(s)/n*100)))};
 const val=(x)=>finance&&typeof x==='number'?fmt(x):x;
 const K=(cls,icon,label,value,hint='')=>`<article class="hm-kpi ${cls}"><div class="hm-ic">${icon}</div><div class="hm-kb"><small>${label}</small><strong>${val(value)}</strong>${hint?`<em>${hint}</em>`:''}</div></article>`;
 const quick=[['أمر شراء',"go('po')",ico('receipt'),'k-blue'],['استلام بضاعة',"go('grn')",ico('box'),'k-teal'],['أصل ثابت',"go('asset')",ico('building'),'k-indigo'],['قيد يومية',"go('jr')",ico('book'),'k-amber'],['تقرير الأرباح',"go('rep')",ico('chart'),'k-green']];
 if(me.isDev) quick.push(['فحص النظام',"go('health')",ico('check'),'k-rose']);
 return `<section class="hm">
 <div class="hm-hero">
  <div class="hm-hero-txt">
   <span class="hm-date">${today}</span>
   <h2>${greet}، ${e(me.name)}</h2>
   <p>نظرة سريعة على أداء النشاط ${per==='today'?'اليوم':'خلال الفترة المختارة'}.</p>
   <div class="hm-hero-btns"><button class="hm-btn hm-btn-main" onclick="go('sales')">+ فاتورة مبيعات</button><button class="hm-btn hm-btn-ghost" onclick="go('trf')">تحويل مخزني</button></div>
  </div>
  <div class="hm-hero-stats">
   ${finance?`<div class="hm-glass"><small>صافي الربح المبدئي</small><b>${fmt(profit)}</b></div>`:''}
   <div class="hm-glass"><small>المبيعات</small><b>${val(num(D.sales))}</b></div>
   <div class="hm-ring" style="--p:${healthy}"><div class="hm-ring-in"><b>${healthy}%</b><small>مخزون سليم</small></div></div>
  </div>
 </div>
 <div class="hm-bar">
  <div class="hm-seg">${periods.map(([k,l])=>`<button class="hm-sb ${per===k?'on':''}" onclick="per='${k}';R()">${l}</button>`).join('')}</div>
  ${per==='custom'?`<div class="hm-dates"><input type="date" id="d1" value="${a}" onchange="d1=v('d1');R()"><input type="date" id="d2" value="${b}" onchange="d2=v('d2');R()"></div>`:''}
 </div>
 <div class="hm-kpis">
  ${K('k-blue',ico('up'),'المبيعات',num(D.sales),'إجمالي الفواتير')}
  ${finance?K('k-green','≡','صافي الربح المبدئي',profit,'المبيعات − التكلفة − المصروفات'):''}
  ${finance?K('k-purple',ico('down'),'المشتريات',D.purchases):''}
  ${finance?K('k-orange','−','المصروفات',D.expenses):''}
  ${finance?K('k-red',ico('clock'),'مستحق العملاء',D.receivables):''}
  ${finance?K('k-amber',ico('clock'),'مستحق الموردين',D.payables):''}
  ${finance?K('k-indigo',ico('box2'),'قيمة المخزون',D.inventory_value):''}
  ${K('k-teal',ico('grid'),'عدد الأصناف',products)}
  ${K('k-rose','!','منخفض المخزون',lowN)}
 </div>
 ${finance?`<div class="hm-card">
  <div class="hm-ch"><b>المركز المالي مع العملاء والموردين</b></div>
  <div class="hm-bars">
   <div><div class="hm-bl"><span>مستحق العملاء</span><b>${money(rec)}</b></div><div class="hm-track"><i style="width:${Math.round(rec/mx*100)}%;background:linear-gradient(90deg,#B93A2F,#B93A2F)"></i></div></div>
   <div><div class="hm-bl"><span>مستحق الموردين</span><b>${money(pay)}</b></div><div class="hm-track"><i style="width:${Math.round(pay/mx*100)}%;background:linear-gradient(90deg,#B8650F,#B8650F)"></i></div></div>
  </div>
 </div>`:''}
 <div class="hm-grid">
  <div class="hm-card">
   <div class="hm-ch"><b>آخر فواتير المبيعات</b><button class="hm-link" onclick="go('sales')">عرض الكل ←</button></div>
   ${recent.length?T(['الفاتورة','التاريخ','الإجمالي','المتبقي'],recent.map(x=>[e(x.number),x.date,money(x.total),money(x.outstanding)])):'<div class="hm-empty">لا توجد فواتير بعد.</div>'}
  </div>
  <div class="hm-card">
   <div class="hm-ch"><b>تنبيهات المخزون</b><button class="hm-link" onclick="go('prod')">الأصناف ←</button></div>
   ${low.length?low.slice(0,8).map(p=>`<div class="hm-alert"><div class="hm-alert-t"><b>${e(p.name)}</b><span>${fmt(p.stock)} / ${fmt(p.min_stock)}</span></div><div class="hm-track sm"><i style="width:${pctOfMin(p.stock,p.min_stock)}%"></i></div></div>`).join(''):'<div class="hm-empty ok">المخزون ضمن الحدود الدنيا '+ico('check')+'</div>'}
  </div>
 </div>
 <div class="hm-card">
  <div class="hm-ch"><b>وصول سريع</b></div>
  <div class="hm-quick">${quick.map(([l,f,i,c])=>`<button class="hm-q ${c}" onclick="${f}"><span>${i}</span>${l}</button>`).join('')}</div>
 </div>
</section>`;
}

async function poView(){
 const L=await g('purchase_orders','date');
 return `${sectionHead('أوامر الشراء','اطلب البضاعة أولًا ثم استلمها ثم أصدر فاتورة المورد.')}
 <div class="card form-card"><div class="row"><select id="posupp">${O(C.suppliers)}</select><select id="powh">${O(C.warehouses)}</select><input id="poexp" type="date"><select id="poprod">${O(C.products.filter(p=>p.active))}</select><input id="poq" type="number" min="0.001" value="1" placeholder="الكمية"><input id="poprice" type="number" min="0" placeholder="سعر الشراء"><button class="btn" onclick="act(async()=>{const it=[{product_id:v('poprod'),qty:n('poq'),price:n('poprice'),discount:0}];await rpc('create_purchase_order',{p_supplier:v('posupp'),p_warehouse:v('powh'),p_items:it,p_expected:v('poexp')||null,p_notes:null})})">+ إنشاء أمر شراء</button></div></div>
 <div class="card">${T(['الرقم','التاريخ','التوريد المتوقع','المورد','الإجمالي','الحالة'],L.reverse().map(x=>[e(x.number),x.date,x.expected_date||'',e(by(C.suppliers,x.supplier_id).name),money(x.total),chip(x.status,x.status==='Cancelled'?'danger':'info')]))}</div>`;
}

async function grnView(){
 const L=await g('purchase_orders','date'); const orders=L.filter(x=>x.status!=='Cancelled');
 return `${sectionHead('استلام المشتريات','استلام المخزون يتم من أمر الشراء وبالكمية المتبقية.')}
 <div class="card form-card"><div class="row"><select id="grpo" onchange="loadGRNItems()"><option value="">اختر أمر شراء</option>${orders.map(x=>`<option value="${x.id}">${e(x.number)} — ${e(by(C.suppliers,x.supplier_id).name)} — ${fmt(x.total)}</option>`).join('')}</select><button class="btn soft" onclick="loadGRNItems()">تحميل البنود</button></div><div id="grnItems" class="mt10"></div></div>`;
}
async function loadGRNItems(){const id=v('grpo');const box=$('#grnItems');if(!id||!box)return;const {data,error}=await sb.from('purchase_order_items').select('*,products(name)').eq('order_id',id).order('id');if(error)throw error;box.innerHTML=T(['الصنف','الكمية المطلوبة','كمية الاستلام','التكلفة'],data.map((x,i)=>[e((x.products||{}).name),x.qty,`<input id="gq${i}" type="number" step="0.001" min="0" value="${x.qty}">`,`<input id="gc${i}" type="number" step="0.0001" value="${x.unit_price}">`]))+`<button class="btn" onclick="act(async()=>{const items=${JSON.stringify(data).replace(/</g,'\\u003c')}.map((x,i)=>({product_id:x.product_id,qty:n('gq'+i),cost:n('gc'+i)})).filter(x=>x.qty>0);await rpc('create_goods_receipt',{p_po:'${id}',p_items:items,p_notes:null})})">اعتماد الاستلام</button>`}

async function dnView(){const L=await g('sales_orders','date');const orders=L.filter(x=>['Confirmed','Partially Delivered'].includes(x.status));return `${sectionHead('أذونات التسليم','افصل حركة المخزون عن الفاتورة، واسمح بالتسليم الجزئي.')}
 <div class="card form-card"><div class="row"><select id="dno" onchange="loadDNItems()"><option value="">اختر أمر بيع</option>${orders.map(x=>`<option value="${x.id}">${e(x.number)} — ${e(by(C.customers,x.customer_id).name)}</option>`).join('')}</select><button class="btn soft" onclick="loadDNItems()">تحميل البنود</button></div><div id="dnItems" class="mt10"></div></div>`}
async function loadDNItems(){const id=v('dno');const box=$('#dnItems');if(!id||!box)return;const {data,error}=await sb.from('sales_order_items').select('*,products(name)').eq('order_id',id).order('id');if(error)throw error;box.innerHTML=T(['الصنف','الكمية المطلوبة','كمية التسليم','السعر'],data.map((x,i)=>[e((x.products||{}).name),x.qty,`<input id="dq${i}" type="number" step="0.001" min="0" value="${x.qty}">`,`<input id="dp${i}" type="number" step="0.0001" value="${x.unit_price}">`]))+`<button class="btn" onclick="act(async()=>{const items=${JSON.stringify(data).replace(/</g,'\\u003c')}.map((x,i)=>({product_id:x.product_id,qty:n('dq'+i),price:n('dp'+i),discount:0})).filter(x=>x.qty>0);await rpc('create_delivery',{p_order:'${id}',p_items:items,p_notes:null})})">تسجيل التسليم</button>`}

async function assetView(){const [A,CAT]=await Promise.all([g('fixed_assets','created_at'),g('asset_categories','name')]);return `${sectionHead('الأصول الثابتة','اقتناء، رسملة، إهلاك واستبعاد — مع القيود المحاسبية.')}
 <div class="card form-card"><div class="row"><input id="acn" placeholder="تصنيف الأصل"><input id="acl" type="number" value="60"><button class="btn soft" onclick="act(()=>ins('asset_categories',{name:v('acn'),default_life_months:n('acl'),asset_account:'1400',depreciation_account:'6200',accumulated_account:'1500'}))">إضافة تصنيف</button></div><hr><div class="row"><input id="afn" placeholder="اسم الأصل"><select id="afc">${O(CAT)}</select><input id="afcost" type="number" placeholder="التكلفة"><input id="afres" type="number" value="0"><input id="aflife" type="number" value="60"><select id="afacct">${O(C.accts)}</select><button class="btn" onclick="act(async()=>{const id=await rpc('create_fixed_asset',{p_name:v('afn'),p_category:v('afc'),p_cost:n('afcost'),p_residual:n('afres'),p_life_months:n('aflife'),p_purchase_date:new Date().toISOString().slice(0,10),p_branch:null});await rpc('capitalize_fixed_asset',{p_asset:id,p_credit_account:v('afacct')})})">إضافة + رسملة</button></div></div>
 <div class="card">${T(['الكود','الأصل','التكلفة','المجمع','الصافي','الحالة','إجراء'],A.map(x=>[e(x.code),e(x.name),money(x.cost),money(x.accumulated_depreciation),money(x.cost-x.accumulated_depreciation),chip(x.status,x.status==='Disposed'?'danger':'success'),x.status==='Active'?`<button class="btn soft" onclick="act(()=>rpc('depreciate_asset',{p_asset:'${x.id}',p_period:new Date().toISOString().slice(0,10)}))">إهلاك</button> <button class="btn danger" onclick="act(()=>rpc('dispose_fixed_asset',{p_asset:'${x.id}',p_date:new Date().toISOString().slice(0,10),p_proceeds:0,p_account:null}))">استبعاد</button>`:'—']))}</div>`}
async function bankView(){const banks=(C.accts||[]).filter(a=>a.type==='bank');const stm=await g('bank_statements','created_at');const lines=await g('bank_statement_lines','created_at');const payments=await g('payments','date');return `${sectionHead('البنوك والتسويات البنكية','إدخال كشوف البنك ومطابقة الحركات مع المقبوضات والمدفوعات.')}
 <div class="card form-card"><div class="row"><select id="bka">${O(banks)}</select><input id="bkn" placeholder="رقم كشف البنك"><input id="bkopen" type="number" placeholder="رصيد أول المدة"><input id="bkclose" type="number" placeholder="رصيد آخر المدة"><button class="btn" onclick="act(()=>ins('bank_statements',{account_id:v('bka'),statement_no:v('bkn'),opening_balance:n('bkopen'),closing_balance:n('bkclose')}))">إنشاء كشف</button></div><hr><div class="row"><select id="bks">${stm.map(x=>`<option value="${x.id}">${e(x.statement_no)}</option>`).join('')}</select><input id="bkdate" type="date" value="${new Date().toISOString().slice(0,10)}"><input id="bkdesc" placeholder="البيان"><input id="bkamt" type="number" placeholder="المبلغ"><select id="bkdir"><option value="credit">داخل</option><option value="debit">خارج</option></select><button class="btn soft" onclick="act(()=>ins('bank_statement_lines',{statement_id:v('bks'),txn_date:v('bkdate'),description:v('bkdesc'),amount:n('bkamt'),direction:v('bkdir')}))">إضافة حركة كشف</button></div><div class="row"><select id="bkl">${lines.filter(x=>!x.reconciled).map(x=>`<option value="${x.id}">${x.txn_date} — ${e(x.description||'')} — ${money(x.amount)}</option>`).join('')}</select><select id="bkp">${payments.map(x=>`<option value="${x.id}">${x.date} — ${money(x.amount)} — ${e(x.doc_ref||'')}</option>`).join('')}</select><button class="btn" onclick="act(()=>rpc('reconcile_bank_line',{p_line:v('bkl'),p_payment:v('bkp')}))">مطابقة</button></div></div>
 <div class="card">${T(['الحساب','الكشف','من','إلى','أول المدة','آخر المدة','الحالة'],stm.map(x=>[e(by(C.accts,x.account_id).name),e(x.statement_no),x.from_date||'',x.to_date||'',money(x.opening_balance),money(x.closing_balance),chip(x.status,x.status==='Reconciled'?'success':'warning')]))}</div>`}
async function priceView(){const [PL,IT]=await Promise.all([g('price_lists','name'),g('price_list_items',null)]);return `${sectionHead('قوائم الأسعار','أسعار بيع حسب العميل والكمية — مع إمكانية تخصيص قائمة افتراضية للعميل.')}
 <div class="card form-card"><div class="row"><input id="pln" placeholder="اسم قائمة الأسعار"><input id="plcur" value="EGP" placeholder="العملة"><button class="btn" onclick="act(()=>ins('price_lists',{name:v('pln'),currency:v('plcur')}))">إنشاء قائمة</button></div><hr><div class="row"><select id="pli">${O(PL)}</select><select id="plp">${O(C.products)}</select><input id="plprice" type="number" step="0.0001" placeholder="السعر"><input id="plmin" type="number" value="1" min="0.001" placeholder="الحد الأدنى"><button class="btn soft" onclick="act(()=>ins('price_list_items',{price_list_id:v('pli'),product_id:v('plp'),price:n('plprice'),min_qty:n('plmin')}))">إضافة سعر</button></div></div>
 <div class="card">${T(['القائمة','الصنف','الحد الأدنى','السعر'],IT.map(x=>[e(by(PL,x.price_list_id).name),e(by(C.products,x.product_id).name),x.min_qty,money(x.price)]))}</div>`}
async function hrView(){const [E,L,Adj,Holi]=await Promise.all([g('employees','name'),g('leave_requests',null),g('employee_adjustments','effective_date'),g('holidays','holiday_date')]);const types=await g('leave_types','name');return `${sectionHead('الموارد البشرية','الحضور والغياب والإجازات والعطلات والمكافآت والجزاءات والربط مع الرواتب.')}
 <div class="card form-card"><div class="row"><select id="he">${O(E)}</select><input id="hd" type="date" value="${new Date().toISOString().slice(0,10)}"><input id="hi" type="datetime-local"><input id="ho" type="datetime-local"><select id="hs"><option>Present</option><option>Late</option><option>Absent</option><option>Leave</option><option>Holiday</option></select><button class="btn" onclick="act(()=>ins('attendance',{employee_id:v('he'),work_date:v('hd'),check_in:v('hi')?new Date(v('hi')).toISOString():null,check_out:v('ho')?new Date(v('ho')).toISOString():null,status:v('hs')}))">تسجيل حضور</button></div><hr><div class="row"><select id="hle">${O(E)}</select><select id="hlt">${O(types)}</select><input id="hf" type="date"><input id="ht" type="date"><input id="hlr" placeholder="السبب"><button class="btn soft" onclick="act(()=>ins('leave_requests',{employee_id:v('hle'),leave_type_id:v('hlt'),from_date:v('hf'),to_date:v('ht'),days:1,reason:v('hlr')}))">طلب إجازة</button></div></div>
 <div class="report-cards"><div class="card form-card"><div class="card-title"><b>مكافأة / جزاء</b><span class="muted">يظهر في سجل الـHR ويُربط بشهر المرتب.</span></div><div class="row"><select id="ae">${O(E)}</select><select id="ak"><option value="reward">مكافأة</option><option value="penalty">جزاء</option></select><input id="aa" type="number" placeholder="المبلغ"><input id="ad" type="date" value="${new Date().toISOString().slice(0,10)}"><input id="am" type="month"><input id="ar" placeholder="السبب"><button class="btn" onclick="act(()=>ins('employee_adjustments',{employee_id:v('ae'),kind:v('ak'),amount:n('aa'),effective_date:v('ad'),payroll_month:v('am')?v('am')+'-01':null,reason:v('ar')}))">إضافة</button></div></div>
 <div class="card form-card"><div class="card-title"><b>العطلات الرسمية</b><span class="muted">تستخدم أيضًا لتحديد حالة Holiday في الحضور.</span></div><div class="row"><input id="hn" placeholder="اسم العطلة"><input id="hdx" type="date"><label><input type="checkbox" id="hp" checked> مدفوعة</label><button class="btn soft" onclick="act(()=>ins('holidays',{name:v('hn'),holiday_date:v('hdx'),paid:$('#hp').checked}))">إضافة عطلة</button></div></div></div>
 <div class="card">${T(['الموظف','من','إلى','الأيام','الحالة','سبب'],L.map(x=>[e(by(E,x.employee_id).name),x.from_date,x.to_date,x.days,chip(x.status,x.status==='Approved'?'success':x.status==='Rejected'?'danger':'warning'),e(x.reason)]))}</div>
 <div class="report-cards"><div class="card">${T(['الموظف','النوع','المبلغ','التاريخ','الشهر','اعتماد'],Adj.map(x=>[e(by(E,x.employee_id).name),x.kind==='reward'?'مكافأة':'جزاء',money(x.amount),x.effective_date,x.payroll_month?x.payroll_month.slice(0,7):'—',chip(x.approved?'معتمد':'معلّق',x.approved?'success':'warning')]))}</div><div class="card">${T(['العطلة','التاريخ','مدفوعة'],Holi.map(x=>[e(x.name),x.holiday_date,x.paid?'نعم':'لا']))}</div></div>`}

async function mfgView(){const products=C.products||[],boms=await g('boms',null),bi=await g('bom_items',null),work=await g('work_orders','date');let factoryRolls=null;try{factoryRolls=await g('factory_rolls','created_at')}catch(_){/* optional experimental migration */}return `${sectionHead('التصنيع','تعريف BOM، المكونات، أوامر التصنيع والتكلفة الفعلية.')}
 <div class="card" role="alert"><b>تنبيه تخصيص المصنع التجريبي:</b> إكمال التصنيع الحالي يخصم الكمية المخططة ويضيف الإنتاج فوراً؛ لا يستخدم لدورة المصنع المطلوبة قبل اكتمال التطوير والاختبارات.</div>
 ${factoryRolls===null?'':`<div class="card"><b>الرولات المسجلة — عرض تجريبي فقط</b><p>الكميات أصلية وليست أرصدة متاحة؛ الصرف والمرتجعات والتصنيع غير مرتبطة بعد.</p>${T(['الرول','الخامة','اللون','العرض','الكمية الأصلية'],factoryRolls.map(x=>[e(x.roll_code),e(by(products,x.product_id).name),e(x.color),fmt(x.width),fmt(x.original_qty)]))}</div>`}
 <div class="card form-card"><div class="row"><select id="mfgt">${O(products)}</select><input id="mfgver" value="1"><button class="btn soft" onclick="act(()=>ins('boms',{product_id:v('mfgt'),version:v('mfgver'),active:true}))">إنشاء BOM</button></div><div class="row"><select id="mfgbom">${boms.map(x=>`<option value="${x.id}">${e(by(products,x.product_id).name)} — ${e(x.version)}</option>`).join('')}</select><select id="mfgcomp">${O(products)}</select><input id="mfgcompq" type="number" step="0.0001" value="1"><button class="btn soft" onclick="act(()=>ins('bom_items',{bom_id:v('mfgbom'),component_product_id:v('mfgcomp'),qty:n('mfgcompq')}))">إضافة مكوّن</button></div><div class="row"><select id="mfgbom2">${boms.map(x=>`<option value="${x.id}">${e(by(products,x.product_id).name)} — ${e(x.version)}</option>`).join('')}</select><select id="mfgwh">${O(C.warehouses)}</select><input id="mfgqty" type="number" value="1"><input id="mfgl" type="number" value="0" placeholder="عمالة"><input id="mfgo" type="number" value="0" placeholder="تحميلات"><button class="btn" onclick="act(()=>rpc('create_work_order',{p_bom:v('mfgbom2'),p_warehouse:v('mfgwh'),p_qty:n('mfgqty'),p_labor:n('mfgl'),p_overhead:n('mfgo')}))">أمر تصنيع</button></div></div>
 <div class="card"><b>المكونات المعرفة</b>${T(['BOM','المكوّن','الكمية'],bi.map(x=>[e(x.bom_id),e(by(products,x.component_product_id).name),x.qty]))}</div><div class="card">${T(['الأمر','التاريخ','الكمية','المادة','الإجمالي','الحالة',''],work.map(x=>[e(x.number),x.date,fmt(x.planned_qty),money(x.material_cost),money(x.total_cost),chip(x.status,x.status==='Completed'?'success':'warning'),x.status==='Completed'?'':`<button class="btn" onclick="act(()=>rpc('complete_work_order',{p_order:'${x.id}'}))">إكمال</button>`]))}</div>`}
async function posView(){const sessions=await g('pos_sessions','opened_at');const inv=await g('sales_invoice_balances','date');return `${sectionHead('نقطة البيع','جلسات كاشير ومتابعة الإغلاق. الفاتورة نفسها تظل جزءًا من النظام المحاسبي.')}
 <div class="card form-card"><div class="row"><select id="psa">${O((C.accts||[]).filter(a=>a.type==='cash'))}</select><input id="pso" type="number" value="0" placeholder="رصيد افتتاحي"><button class="btn" onclick="act(()=>rpc('open_pos_session',{p_account:v('psa'),p_opening:n('pso')}))">فتح جلسة</button></div><div class="row"><select id="pss"><option value="">اختر جلسة مفتوحة</option>${sessions.filter(x=>x.status==='Open').map(x=>`<option value="${x.id}">${e(x.session_no)}</option>`).join('')}</select><input id="psc" type="number" placeholder="النقد الفعلي عند الإغلاق"><button class="btn danger" onclick="act(()=>rpc('close_pos_session',{p_session:v('pss'),p_closing:n('psc')}))">إغلاق الجلسة</button></div><div class="row"><select id="psi"><option value="">اختر فاتورة مدفوعة</option>${inv.filter(x=>x.status==='Posted'&&x.outstanding===0).slice(0,40).map(x=>`<option value="${x.id}">${e(x.number)} — ${fmt(x.total)}</option>`).join('')}</select><select id="pss2"><option value="">جلسة مفتوحة</option>${sessions.filter(x=>x.status==='Open').map(x=>`<option value="${x.id}">${e(x.session_no)}</option>`).join('')}</select><button class="btn soft" onclick="act(()=>rpc('record_pos_sale',{p_session:v('pss2'),p_invoice:v('psi')}))">ربط الفاتورة بالجلسة</button></div></div>
 <div class="card">${T(['الجلسة','الفتح','الإغلاق','افتتاحي','فعلي','الحالة'],sessions.map(x=>[e(x.session_no),new Date(x.opened_at).toLocaleString(locOf()),x.closed_at?new Date(x.closed_at).toLocaleString(locOf()):'—',money(x.opening_cash),x.closing_cash==null?'—':money(x.closing_cash),chip(x.status,x.status==='Closed'?'success':'warning')]))}</div>`}

async function projView(){const [Pj,Tk]=await Promise.all([g('projects',null),g('service_tickets',null)]);return `${sectionHead('المشاريع والخدمات','متابعة المشاريع وتذاكر خدمة العملاء.')}
 <div class="card form-card"><div class="row"><input id="prcode" placeholder="كود المشروع"><input id="prname" placeholder="اسم المشروع"><select id="prcust"><option value="">عميل اختياري</option>${O(C.customers)}</select><input id="prbud" type="number" placeholder="الميزانية"><button class="btn" onclick="act(()=>ins('projects',{code:v('prcode'),name:v('prname'),customer_id:v('prcust')||null,budget:n('prbud'),status:'Open'}))">إنشاء مشروع</button></div><hr><div class="row"><select id="tsc"><option value="">كل العملاء</option>${O(C.customers)}</select><select id="tsp"><option value="">مشروع اختياري</option>${Pj.map(x=>`<option value="${x.id}">${e(x.code)} — ${e(x.name)}</option>`).join('')}</select><input id="tss" placeholder="موضوع التذكرة"><select id="tspv"><option>Normal</option><option>Low</option><option>High</option><option>Urgent</option></select><button class="btn soft" onclick="act(()=>ins('service_tickets',{ticket_no:'T-'+Date.now(),customer_id:v('tsc')||null,project_id:v('tsp')||null,subject:v('tss'),priority:v('tspv')}))">تذكرة جديدة</button></div></div>
 <div class="card">${T(['المشروع','العميل','الميزانية','الحالة'],Pj.map(x=>[e(x.code)+' — '+e(x.name),e(by(C.customers,x.customer_id).name)||'—',money(x.budget),chip(x.status,x.status==='Closed'?'success':'info')]))}</div>`}

async function periodView(){const L=await g('fiscal_periods','start_date');return `${sectionHead('الفترات والإقفال','لا تسمح للنظام بالتعديل على فترة مغلقة إلا بعد فتحها.')}
 <div class="card form-card"><div class="row"><input id="fpn" placeholder="اسم الفترة"><input id="fps" type="date"><input id="fpe" type="date"><button class="btn" onclick="act(()=>ins('fiscal_periods',{name:v('fpn'),start_date:v('fps'),end_date:v('fpe'),status:'Open'}))">إنشاء فترة</button></div></div><div class="card">${T(['الفترة','من','إلى','الحالة',''],L.map(x=>[e(x.name),x.start_date,x.end_date,chip(x.status,x.status==='Closed'?'danger':'success'),x.status==='Closed'?`<button class="btn soft" onclick="act(()=>rpc('reopen_fiscal_period',{p_period:'${x.id}'}))">فتح</button>`:`<button class="btn danger" onclick="act(()=>rpc('close_fiscal_period',{p_period:'${x.id}'}))">إقفال</button>`]))}</div>`}


async function chequeView(){const L=await g('cheques','due_date');return `${sectionHead('الشيكات','شيكات قبض/دفع ومتابعة الاستحقاق والحالة.')}
 <div class="card form-card"><div class="row"><select id="ck"><option value="received">شيك قبض</option><option value="issued">شيك دفع</option></select><input id="cn" placeholder="رقم الشيك"><input id="camt" type="number" placeholder="المبلغ"><input id="cdate" type="date"><select id="cacc">${O(C.accts)}</select><select id="ccust"><option value="">كل العملاء</option>${O(C.customers)}</select><select id="csupp"><option value="">كل الموردين</option>${O(C.suppliers)}</select><button class="btn" onclick="act(()=>rpc('record_cheque',{p_kind:v('ck'),p_cheque_no:v('cn'),p_amount:n('camt'),p_due_date:v('cdate'),p_account:v('cacc'),p_customer:v('ccust')||null,p_supplier:v('csupp')||null,p_doc_ref:null}))">تسجيل شيك</button></div></div>
 <div class="card">${T(['الرقم','النوع','الطرف','المبلغ','الاستحقاق','الحالة',''],L.map(x=>[e(x.cheque_no),x.kind==='received'?'قبض':'دفع',e(by(x.kind==='received'?C.customers:C.suppliers,x.kind==='received'?x.customer_id:x.supplier_id).name),money(x.amount),x.due_date,chip(x.status,x.status==='Cleared'?'success':x.status==='Bounced'?'danger':'warning'),x.status==='Pending'?`<button class="btn soft" onclick="act(()=>rpc('update_cheque_status',{p_cheque:'${x.id}',p_status:'Deposited'}))">إيداع</button>`:''] ))}</div>`}

async function commissionView(){const [R,I,Cm]=await Promise.all([g('commission_rules','name'),g('sales_invoices','date'),g('sales_commissions','created_at')]);return `${sectionHead('العمولات','حساب عمولات البائعين بناءً على صافي المبيعات أو هامش الربح.')}
 <div class="card form-card"><div class="row"><input id="crn" placeholder="اسم القاعدة"><input id="crr" type="number" step="0.0001" placeholder="النسبة %"><select id="crb"><option value="net_sales">صافي المبيعات</option><option value="gross_profit">مجمل الربح</option></select><button class="btn" onclick="act(()=>ins('commission_rules',{name:v('crn'),rate:n('crr'),basis:v('crb')}))">إضافة قاعدة</button></div><hr><div class="row"><select id="cri">${I.filter(x=>x.status==='Posted').map(x=>`<option value="${x.id}">${e(x.number)} — ${money(x.total)}</option>`).join('')}</select><select id="crr2">${O(R)}</select><button class="btn soft" onclick="act(()=>rpc('calculate_sales_commission',{p_invoice:v('cri'),p_rule:v('crr2')}))">حساب عمولة</button></div></div><div class="card">${T(['الفاتورة','البائع','الأساس','العمولة','الحالة'],Cm.map(x=>[e(x.invoice_id),e(x.salesperson_id),money(x.basis_amount),money(x.amount),chip(x.status,x.status==='Paid'?'success':'warning')]))}</div>`}

// ===== المساهمون (v1.93) =====
const shMonthStart=()=>{const d=new Date();return d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-01'};
const shToday=()=>new Date().toISOString().slice(0,10);
const shIsAdmin=()=>!!me&&(me.role==='admin'||me.role==='developer');
function shBal(M,id){let cap=0,due=0;for(const m of M){if(m.shareholder_id!==id)continue;const a=+m.amount;if(m.type==='deposit'||m.type==='profit_reinvest')cap+=a;else if(m.type==='withdraw'||m.type==='loss')cap-=a;else if(m.type==='profit_withdraw')due+=a;else if(m.type==='profit_payout')due-=a}return{cap,due}}
const shModeLabel=m=>m==='withdraw'?'يسحب الربح':'يضيف الربح لرأس المال';
const shChangeHtml=c=>{const r=[];if(c?.name)r.push('الاسم: '+e(c.name));if(c?.phone)r.push('الموبايل: '+e(c.phone));if(c?.email)r.push('الإيميل: '+e(c.email));if(c?.profit_mode)r.push('الربح: '+shModeLabel(c.profit_mode));if(c?.active===false)r.push('موقوف');return r.join('<br>')||'—'};
const shStatusChip=st=>st==='Approved'?chip('تمت الموافقة','success'):st==='Rejected'?chip('مرفوض','info'):chip('بانتظار الموافقة','warning');
async function shareholdersView(){
  const[S,M,avg,R,runs,st]=await Promise.all([g('shareholders','name'),g('shareholder_movements','date'),rpc('shareholder_avg_capital',{p_month:shMonthStart()}),g('shareholder_change_requests','requested_at'),g('shareholder_profit_runs','month'),g('shareholder_settings')]);
  const PN=await profNames();
  const avgBy=Object.fromEntries((avg||[]).map(x=>[x.shareholder_id,+x.avg_capital]));
  const lossMode=(st[0]||{}).loss_mode||'proportional';
  const pending=R.filter(x=>x.status==='Pending');
  const rows=S.map(s=>{const b=shBal(M,s.id);return [
    e(s.name)+(s.active?'':' <span class="chip">موقوف</span>'),e(s.phone||'—'),e(shModeLabel(s.profit_mode)),money(b.cap),money(b.due),money(avgBy[s.id]||0),
    `<button class="btn soft" onclick="shEdit('${s.id}')">تعديل</button> <button class="btn soft" onclick="shMoveForm('${s.id}')">إيداع / سحب</button> <button class="btn soft" onclick="shPayForm('${s.id}')">صرف مستحق</button>`]});
  const adminTools=shIsAdmin()?`<div class="row"><input type="month" id="shdm" value="${shMonthStart().slice(0,7)}"><button class="btn" onclick="shDistribute()">توزيع أرباح الشهر</button>
    <select id="shlm" onchange="act(()=>rpc('shareholder_set_loss_mode',{p_mode:this.value}))"><option value="proportional" ${lossMode==='proportional'?'selected':''}>الخسارة بنفس النسبة</option><option value="carry_forward" ${lossMode==='carry_forward'?'selected':''}>ترحيل الخسارة للشهر الجاي</option></select></div>`:'';
  const isAdm=shIsAdmin();
  const pendingHtml=isAdm&&pending.length?`<div class="card"><h3>طلبات تعديل بيانات مساهمين (تحتاج موافقتك)</h3>${T(['المساهم','التعديل المطلوب','طلب من','التاريخ',''],pending.map(x=>[(x.shareholder_id?nameOf(S,x.shareholder_id):e(x.changes?.name||'مساهم جديد')),shChangeHtml(x.changes),PN[x.requested_by]||'—',new Date(x.requested_at).toLocaleString(locOf()),`<button class="btn" onclick="shDecide('${x.id}',true)">موافقة</button> <button class="btn danger" onclick="shDecide('${x.id}',false)">رفض</button>`]))}</div>`:'';
  const mine=!isAdm?R.filter(x=>x.requested_by===me?.id):[];
  const myHtml=mine.length?`<div class="card"><h3>طلباتي</h3>${T(['المساهم','التعديل المطلوب','التاريخ','الحالة'],mine.map(x=>[(x.shareholder_id?nameOf(S,x.shareholder_id):e(x.changes?.name||'مساهم جديد')),shChangeHtml(x.changes),new Date(x.requested_at).toLocaleString(locOf()),shStatusChip(x.status)]))}</div>`:'';
  const runsHtml=runs.length?T(['الشهر','صافي الربح','متوسط رأس المال','الحالة'],runs.map(r=>[e(String(r.month).slice(0,7)),money(r.net_profit),money(r.total_avg_capital),chip(r.status,r.status==='Distributed'?'success':r.status==='Carried'?'warning':'info')])):'<div class="empty">لا توجد توزيعات بعد</div>';
  const reqHtml=(pendingHtml+myHtml)||'<div class="empty">لا توجد طلبات</div>';
  const reqCount=isAdm?pending.length:mine.length;
  const listHtml=S.length?T(['الاسم','الموبايل','طريقة الربح','رأس المال الحالي','المستحق للصرف','متوسط الشهر الحالي',''],rows):'<div class="empty">لا يوجد مساهمون بعد</div>';
  window._shReqHtml=reqHtml; window._shReqData={R,S,PN,isAdm,meId:me?.id}; window._shListHtml=listHtml; window._shData={S,M,avgBy,runs,PN}; window._shRows=rows; window._shHeaders=['الاسم','الموبايل','طريقة الربح','رأس المال الحالي','المستحق للصرف','متوسط الشهر الحالي','']; window._shSearch=S.map(x=>`${x.name||''} ${x.phone||''} ${x.email||''}`.toLowerCase());
  return `${sectionHead('المساهمون','رأس المال والأرباح الشهرية. تعديل البيانات من المحاسب بيحتاج موافقة الأدمن.')}
  <div class="card form-card"><div class="row"><button class="btn" onclick="shEdit(null)">+ إضافة مساهم</button><button class="btn soft" onclick="shShowRequests()">الطلبات (${reqCount})</button><button class="btn soft" onclick="shShowList()">المساهمون الحاليون (${S.length})</button><button class="btn soft" onclick="shPrintMembers()">طباعة بيانات المساهمين</button><button class="btn soft" onclick="shPrintDistributions()">طباعة توزيعات الأرباح</button></div>${adminTools}</div>
  <div class="card"><h3>توزيعات الأرباح</h3>${runsHtml}</div>`;
}
function shReqTab(t){window._shReqTab=t;shShowRequests()}
function shShowRequests(){
  const d=window._shReqData||{R:[],S:[],PN:{},isAdm:false,meId:null};
  const scoped=d.R.filter(x=>d.isAdm||x.requested_by===d.meId);
  const tab=window._shReqTab||'Pending';
  const cnt=k=>k==='all'?scoped.length:scoped.filter(x=>x.status===k).length;
  const tabs=[['Pending','قيد الانتظار'],['Approved','موافق عليه'],['Rejected','مرفوض'],['all','الكل']];
  const tabsHtml=tabs.map(([k,l])=>`<button class="btn ${tab===k?'':'soft'}" onclick="shReqTab('${k}')">${l} (${cnt(k)})</button>`).join('');
  const list=scoped.filter(x=>tab==='all'||x.status===tab);
  const nameOfReq=x=>x.shareholder_id?e(d.S.find(s=>s.id===x.shareholder_id)?.name||'—'):e(x.changes?.name||'مساهم جديد');
  const body=list.length?T(['المساهم','التعديل المطلوب','طلب من','التاريخ','الحالة'],list.map(x=>[
    nameOfReq(x),
    shChangeHtml(x.changes),
    d.PN[x.requested_by]||'—',
    new Date(x.requested_at).toLocaleString(locOf()),
    shStatusChip(x.status)+(d.isAdm&&x.status==='Pending'?` <button class="btn" onclick="shDecide('${x.id}',true)">موافقة</button> <button class="btn danger" onclick="shDecide('${x.id}',false)">رفض</button>`:'')
  ])):'<div class="empty">لا توجد طلبات في هذا القسم</div>';
  showModal(`<h3>طلبات تعديل المساهمين</h3><div class="row" style="margin-bottom:10px">${tabsHtml}</div><div>${body}</div>`,'<button class="btn soft" onclick="closeModal()">إغلاق</button>',true);
}
function shShowList(){showModal(`<h3>المساهمون الحاليون</h3><input id="shq" type="search" placeholder="بحث بالاسم أو الموبايل أو الإيميل" oninput="shFilterList()" style="width:100%;margin:6px 0 10px"><div id="shListBody">${window._shListHtml||''}</div>`,'<button class="btn soft" onclick="closeModal()">إغلاق</button>',true)}
function shFilterList(){
  const q=(v('shq')||'').trim().toLowerCase();
  const rows=window._shRows||[],txt=window._shSearch||[];
  const keep=rows.filter((_,i)=>!q||(txt[i]||'').includes(q));
  const box=document.getElementById('shListBody');if(!box)return;
  box.innerHTML=keep.length?T(window._shHeaders,keep):'<div class="empty">لا توجد نتائج</div>';
}
const SH_PROFIT_TYPES={profit_reinvest:'إعادة استثمار',profit_withdraw:'ربح مستحق للصرف',profit_payout:'صرف ربح',loss:'خسارة'};
function shPrintMembers(){
  const d=window._shData;if(!d)return toast('حدّث الصفحة وجرّب تاني');
  let tc=0,td=0;
  const rows=d.S.map(x=>{const b=shBal(d.M,x.id);tc+=b.cap;td+=b.due;return `<tr><td>${e(x.name)}</td><td>${e(x.phone||'—')}</td><td>${e(x.email||'—')}</td><td>${e(shModeLabel(x.profit_mode))}</td><td>${x.active?'مفعّل':'موقوف'}</td><td>${money(b.cap)}</td><td>${money(b.due)}</td></tr>`}).join('');
  printHtml('بيانات المساهمين',`<h2>بيانات المساهمين</h2><p class="muted">تاريخ الطباعة: ${new Date().toLocaleDateString(locOf())}</p><table><tr><th>الاسم</th><th>الموبايل</th><th>الإيميل</th><th>طريقة الربح</th><th>الحالة</th><th>رأس المال</th><th>المستحق للصرف</th></tr>${rows}<tr class="tot"><td colspan="5">الإجمالي</td><td>${money(tc)}</td><td>${money(td)}</td></tr></table>`);
}
function shPrintDistributions(){
  const d=window._shData;if(!d)return toast('حدّث الصفحة وجرّب تاني');
  const name=id=>e(d.S.find(x=>x.id===id)?.name||'—');
  const runsRows=d.runs.map(r=>`<tr><td>${e(String(r.month).slice(0,7))}</td><td>${money(r.net_profit)}</td><td>${money(r.total_avg_capital)}</td><td>${e(r.status==='Distributed'?'تم التوزيع':r.status==='Carried'?'مرحّل':'مستهلك')}</td></tr>`).join('');
  const movs=d.M.filter(m=>SH_PROFIT_TYPES[m.type]).sort((a,b)=>String(a.date).localeCompare(String(b.date)));
  const movRows=movs.map(m=>`<tr><td>${e(String(m.date).slice(0,10))}</td><td>${name(m.shareholder_id)}</td><td>${e(SH_PROFIT_TYPES[m.type])}</td><td>${money(m.amount)}</td></tr>`).join('');
  printHtml('توزيعات الأرباح',`<h2>توزيعات الأرباح</h2><p class="muted">تاريخ الطباعة: ${new Date().toLocaleDateString(locOf())}</p>
    <h3>الشهور</h3><table><tr><th>الشهر</th><th>صافي الربح</th><th>متوسط رأس المال</th><th>الحالة</th></tr>${runsRows||'<tr><td colspan="4">لا توجد توزيعات</td></tr>'}</table>
    <h3>تفاصيل الحركات</h3><table><tr><th>التاريخ</th><th>المساهم</th><th>النوع</th><th>المبلغ</th></tr>${movRows||'<tr><td colspan="4">لا توجد حركات أرباح</td></tr>'}</table>`);
}
function nameOf(S,id){const s=S.find(x=>x.id===id);return s?e(s.name):''}
async function shEdit(id){
  const S=id?(await g('shareholders')).find(x=>x.id===id):null;
  showModal(`<h3>${S?'تعديل بيانات مساهم':'مساهم جديد'}</h3>
    <div class="row"><input id="shn" placeholder="الاسم" value="${e(S?.name||'')}"><input id="shp" placeholder="الموبايل" value="${e(S?.phone||'')}"></div>
    <div class="row"><input id="she" placeholder="الإيميل" value="${e(S?.email||'')}"><select id="shm"><option value="reinvest" ${S?.profit_mode!=='withdraw'?'selected':''}>يضيف الربح لرأس المال</option><option value="withdraw" ${S?.profit_mode==='withdraw'?'selected':''}>يسحب الربح</option></select></div>
    <p class="muted">${shIsAdmin()?'التعديل هيتطبق فوراً.':'التعديل هيتبعت للأدمن للموافقة.'}</p>`,
    `<button class="btn" onclick="shSave('${id||''}')">حفظ</button>`);
}
async function shSave(id){const data={name:v('shn').trim(),phone:v('shp').trim(),email:v('she').trim(),profit_mode:v('shm')};closeModal();await act(()=>rpc('shareholder_save',{p_id:id||null,p_data:data}),r=>r?.status==='pending'?'تم إرسال طلبك للإدارة للموافقة':'تم حفظ بيانات المساهم')}
function shMoveForm(id){
  showModal(`<h3>إيداع أو سحب من رأس المال</h3>
    <div class="row"><select id="shtype"><option value="deposit">إيداع</option><option value="withdraw">سحب</option></select><input id="shamt" type="number" min="0" step="0.01" placeholder="المبلغ"></div>
    <div class="row"><input id="shdate" type="date" value="${shToday()}"><input id="shnote" placeholder="ملاحظة"></div>`,
    `<button class="btn" onclick="shMove('${id}')">تنفيذ</button>`);
}
async function shMove(id){const t=v('shtype'),amt=+v('shamt'),d=v('shdate'),n=v('shnote');closeModal();await act(()=>rpc('shareholder_capital_move',{p_shareholder:id,p_type:t,p_amount:amt,p_date:d,p_notes:n||null}))}
function shPayForm(id){
  showModal(`<h3>صرف ربح مستحق</h3>
    <div class="row"><input id="shamt" type="number" min="0" step="0.01" placeholder="المبلغ"><input id="shdate" type="date" value="${shToday()}"></div>
    <div class="row"><input id="shnote" placeholder="ملاحظة"></div>`,
    `<button class="btn" onclick="shPay('${id}')">صرف</button>`);
}
async function shPay(id){const amt=+v('shamt'),d=v('shdate'),n=v('shnote');closeModal();await act(()=>rpc('shareholder_pay_profit',{p_shareholder:id,p_amount:amt,p_date:d,p_notes:n||null}))}
async function shDistribute(){
  const m=v('shdm');if(!m)return toast('اختار الشهر الأول');
  const ok=confirm('هيتم توزيع أرباح/خسائر الشهر '+m+' على المساهمين وتسجيل القيود. متأكد؟');if(!ok)return;
  await act(async()=>{const r=await rpc('shareholder_distribute_profit',{p_month:m+'-01'});if(r.status==='distributed')alert('تم التوزيع: صافي '+fmt(r.net)+' | تم إضافته لرأس المال '+fmt(r.reinvested)+' | مستحق للصرف '+fmt(r.payable)+' | خسارة '+fmt(r.loss));else if(r.status==='carried')alert('الخسارة اترحّلت للشهر الجاي');else alert('مفيش ربح ولا خسارة في الشهر ده')});
}
async function shDecide(id,ok){closeModal();await act(()=>rpc('shareholder_decide_change',{p_request:id,p_approve:ok,p_notes:null}))}

async function approvalView(){const L=await g('approval_requests','requested_at');return `${sectionHead('الاعتمادات','مراجعة واعتماد العمليات قبل ترحيلها أو حسب سياسة الشركة.')}<div class="card">${L.length?T(['العملية','الحالة','طالب الاعتماد','التاريخ','ملاحظات',''],L.map(x=>[e(x.entity),chip(x.status,x.status==='Approved'?'success':x.status==='Rejected'?'danger':'warning'),e(x.requested_by),new Date(x.requested_at).toLocaleString(locOf()),e(x.notes||''),x.status==='Pending'?`<button class="btn" onclick="act(()=>rpc('decide_approval',{p_request:'${x.id}',p_approve:true,p_notes:null}))">اعتماد</button> <button class="btn danger" onclick="act(()=>rpc('decide_approval',{p_request:'${x.id}',p_approve:false,p_notes:null}))">رفض</button>`:''])):'<div class="empty">لا توجد طلبات اعتماد</div>'}</div>`}

async function taxdocView(){const L=await g('tax_documents','created_at');return `${sectionHead('المستندات الضريبية','حالة تجهيز وإرسال المستندات. التكامل الرسمي مع الجهة الضريبية يحتاج بيانات اعتماد/API حقيقية.')}<div class="card form-card"><div class="row"><select id="tdi">${(await g('sales_invoices','date')).filter(x=>x.status==='Posted').map(x=>`<option value="${x.id}">${e(x.number)}</option>`).join('')}</select><button class="btn" onclick="act(()=>rpc('register_tax_document',{p_invoice:v('tdi')}))">تسجيل مستند</button></div></div><div class="card">${T(['الفاتورة','الحالة','UUID الخارجي','Submission','آخر تحديث',''],L.map(x=>[e(x.invoice_id),chip(x.status,x.status==='Accepted'?'success':x.status==='Rejected'?'danger':'warning'),e(x.external_uuid||'—'),e(x.submission_id||'—'),new Date(x.updated_at).toLocaleString(locOf()),x.status==='Pending'?`<button class="btn soft" onclick="act(()=>rpc('update_tax_document',{p_doc:'${x.id}',p_status:'Submitted',p_external_uuid:null,p_submission_id:null,p_error:null}))">تحديث Submitted</button>`:'']))}</div>`}

async function integrationsView(){const [Cnx,Ev]=await Promise.all([g('integration_connections','created_at'),g('integration_events','created_at')]);return `${sectionHead('التكاملات','طبقة موحدة لتتبع Shopify / WooCommerce / Salla / Magento / Custom. لا يتم إرسال بيانات خارجية تلقائيًا قبل ضبط الاتصال.')}<div class="card form-card"><div class="row"><select id="iprov"><option>Shopify</option><option>WooCommerce</option><option>Salla</option><option>Magento</option><option>Custom</option></select><input id="inm" placeholder="اسم الاتصال"><input id="iurl" placeholder="Base URL"><button class="btn" onclick="act(()=>ins('integration_connections',{provider:v('iprov'),name:v('inm'),base_url:v('iurl'),active:false,config:{}}))">إضافة اتصال</button></div></div><div class="card">${T(['المزود','الاسم','الرابط','نشط'],Cnx.map(x=>[e(x.provider),e(x.name),e(x.base_url||'—'),chip(x.active?'نعم':'لا',x.active?'success':'warning')]))}</div><div class="card">${T(['التاريخ','الاتجاه','النوع','الحالة','الخطأ'],Ev.map(x=>[new Date(x.created_at).toLocaleString(locOf()),x.direction,x.event_type,chip(x.status,x.status==='Succeeded'?'success':x.status==='Failed'?'danger':'warning'),e(x.error_message||'—')]))}</div>`}

async function orgView(){const [B,CC]=await Promise.all([g('branches','name'),g('cost_centers','code')]);return `${sectionHead('الفروع ومراكز التكلفة','الأبعاد التنظيمية التي تربط الحركات والتقارير.')}<div class="card form-card"><div class="row"><input id="obn" placeholder="اسم الفرع"><input id="obc" placeholder="الكود"><button class="btn" onclick="act(()=>ins('branches',{name:v('obn'),code:v('obc')}))">إضافة فرع</button><input id="occ" placeholder="كود المركز"><input id="ocn" placeholder="اسم المركز"><button class="btn soft" onclick="act(()=>ins('cost_centers',{code:v('occ'),name:v('ocn')}))">إضافة مركز تكلفة</button></div></div><div class="report-cards"><div class="card">${T(['الفرع','الكود','الحالة'],B.map(x=>[e(x.name),e(x.code||'—'),chip(x.active?'نشط':'موقوف',x.active?'success':'warning')]))}</div><div class="card">${T(['الكود','المركز','الحالة'],CC.map(x=>[e(x.code),e(x.name),chip(x.active?'نشط':'موقوف',x.active?'success':'warning')]))}</div></div>`}

async function healthView(){return `${sectionHead('فحص الجاهزية','اختبار شامل قبل Go-Live. الاختبار ينشئ بيانات مؤقتة ويقوم بتنظيفها.')}
 <div class="card health-banner"><div><b>Enterprise Health Check</b><p class="muted">يفحص التوازن المحاسبي، السالب بالمخزون، الباركودات، الفترات والاعتمادات.</p></div><button class="btn soft" onclick="runHealthCheck()">فحص سريع</button></div>
 <div id="healthBox" class="card"><p class="muted">لم يتم إجراء الفحص بعد.</p></div>${me&&me.isDev?`<div class="card"><div class="card-title"><b>اختبار شامل بكل الـworkflows</b></div><p class="muted">Purchase → GRN → Sale → Delivery → Assets → Bank → Manufacturing → POS → HR → Commissions → Cheques → Tax Docs → Integrations → Period Lock → Journal → Reports + failure paths.</p><button class="btn" onclick="runEnterpriseTest()">تشغيل الاختبار الكامل</button> <button class="btn soft" onclick="runFinalSuite()">اختبار Go-Live النهائي</button><div id="enterpriseTestBox" class="mt10"></div></div><div class="card"><div class="card-title"><b>اختبار المخزون الذكي</b></div><p class="muted">Batch / Expiry / Serial / MRP / CSV Import.</p><button class="btn soft" onclick="runAdvancedInventoryTest()">تشغيل الاختبار المتقدم</button><div id="advancedTestBox" class="mt10"></div></div>`:''}`}
async function runHealthCheck(){return withLoading(async()=>{const box=$('#healthBox');try{const r=await rpc('health_check_enterprise',{});box.innerHTML=`<div class="health-grid"><div>${chip(r.ok?'سليم':'يحتاج مراجعة',r.ok?'success':'danger')}</div><div>Duplicate barcodes: <b>${r.duplicate_barcodes}</b></div><div>Unbalanced entries: <b>${r.unbalanced_journal_entries}</b></div><div>Journal lines both sides: <b>${r.journal_lines_both_sides}</b></div><div>Negative stock: <b>${r.negative_stock_rows}</b></div><div>Negative cash: <b>${r.negative_cash_rows}</b></div><div>Sales overpaid: <b>${r.paid_over_total_sales}</b></div><div>Purchase overpaid: <b>${r.paid_over_total_purchases}</b></div><div>Pending approvals: <b>${r.pending_approvals}</b></div><div>Tax docs pending/rejected: <b>${r.pending_tax_documents}</b></div><div>Integration failures: <b>${r.failed_integrations}</b></div></div>`}catch(x){box.innerHTML=`<div class="bad">${e(x.message||x)}</div>`}finally{}},'جاري الفحص...','جارٍ التحقق من صحة قاعدة البيانات')}
async function runEnterpriseTest(){return withLoading(async()=>{const box=$('#enterpriseTestBox');box.innerHTML='<p>جاري تشغيل الاختبار الشامل...</p>';try{const r=await rpc('run_erp_go_live_test',{});const rows=(r.results||[]).map(x=>`<div class="test-row ${x.pass?'pass':'fail'}"><span>${x.pass?ico('check'):ico('x')}</span><b>${e(x.test)}</b><small>${e(x.detail||'')}</small></div>`).join('');box.innerHTML=`<div class="test-summary ${r.ok?'ok':'fail'}">${r.ok?'نجح الاختبار الشامل':'فشل الاختبار'}${r.cleaned?' · تم تنظيف البيانات':''}</div>${r.error?`<div class="bad">${e(r.error)}</div>`:''}${rows}`; }catch(x){box.innerHTML=`<div class="bad">${e(x.message||x)}</div>`}finally{}},'جاري اختبار النظام...','يتم تشغيل سيناريوهات الـERP')}
async function runAdvancedInventoryTest(){return withLoading(async()=>{const box=$('#advancedTestBox');if(box)box.innerHTML='<p>جاري اختبار التتبع وMRP والاستيراد...</p>';try{const r=await rpc('run_advanced_inventory_test',{});const rows=(r.results||[]).map(x=>`<div class="test-row ${x.pass?'pass':'fail'}"><span>${x.pass?ico('check'):ico('x')}</span><b>${e(x.test)}</b><small>${e(x.detail||'')}</small></div>`).join('');if(box)box.innerHTML=`<div class="test-summary ${r.ok?'ok':'fail'}">${r.ok?'نجح اختبار المخزون الذكي':'فشل الاختبار'}${r.cleaned?' · تم تنظيف البيانات':''}</div>${r.error?`<div class="bad">${e(r.error)}</div>`:''}${rows}`;}catch(x){if(box)box.innerHTML=`<div class="bad">${e(x.message||x)}</div>`}finally{}},'جاري اختبار المخزون...','يتم اختبار Batch / Serial / MRP')}

const RP_DEF=[
 ['tb','ميزان المراجعة','إجمالي الأرصدة المدينة والدائنة لكل حساب. لو الإجمالين متساويين يبقى الدفاتر متوازنة.'],
 ['bs','المركز المالي','الأصول والخصوم وحقوق الملكية في تاريخ اليوم.'],
 ['ag','أعمار الديون','المبالغ المستحقة على العملاء والموردين مقسّمة حسب عدد أيام التأخير.'],
 ['inv','تقييم المخزون','قيمة كل صنف في المخزن حسب متوسط التكلفة.'],
 ['cf','التدفق النقدي','الفلوس الداخلة والخارجة خلال الشهر الحالي.'],
 ['pl','الأرباح والخسائر','صافي الربح للشهر الحالي من الإيرادات والمصروفات.']
];
function rpHidden(){try{return JSON.parse(localStorage.getItem('erp_rep_hidden')||'[]')}catch(_){return[]}}
function rpToggle(id){let a=rpHidden();a=a.includes(id)?a.filter(x=>x!==id):[...a,id];try{localStorage.setItem('erp_rep_hidden',JSON.stringify(a))}catch(_){}R()}
function rpShowAll(){try{localStorage.removeItem('erp_rep_hidden')}catch(_){}R()}
function rpCard(id,body){const d=RP_DEF.find(x=>x[0]===id);const hid=rpHidden().includes(id);return `<div class="card rp-card${hid?' rp-off':''}" data-rp="${id}"><div class="card-title rp-head"><div><b>${d[1]}</b><small class="muted rp-d">${d[2]}</small></div><span class="rp-acts"><button class="btn soft sm" onclick="exportCard(this)">Excel</button><button class="btn soft sm" onclick="rpToggle('${id}')">${hid?'إظهار':'إخفاء'}</button></span></div><div class="rp-body">${body}</div></div>`}
function exportCard(btn){
  const card=btn.closest('.card');if(!card)return;
  const rows=[];
  card.querySelectorAll('tr').forEach(tr=>{
    const cells=[...tr.children].filter(c=>c.tagName==='TH'||c.tagName==='TD');
    if(!cells.length)return;
    rows.push(cells.map(c=>{const v=c.querySelector('.tk-v');return (v||c).textContent.replace(/\s+/g,' ').trim()}));
  });
  if(!rows.length){toast('مفيش جدول يتصدّر في الكارت ده');return}
  const csv='﻿'+rows.map(r=>r.map(csvEscape).join(',')).join('\r\n');
  const title=(card.querySelector('b')?.textContent||'report').replace(/[\\/:*?"<>|]+/g,'-');
  const a=document.createElement('a');
  a.href=URL.createObjectURL(new Blob([csv],{type:'text/csv;charset=utf-8'}));
  a.download=title+'-'+new Date().toISOString().slice(0,10)+'.csv';
  document.body.appendChild(a);a.click();setTimeout(()=>{URL.revokeObjectURL(a.href);a.remove()},1000);
}
async function reportsView(){
  const today=new Date().toISOString().slice(0,10);const first=today.slice(0,8)+'01';
  const hid=rpHidden();
  const [ca,sa,tb,bs,inv,cf,pl]=await Promise.all([
    rpc('customer_aging',{p_as_of:today}),rpc('supplier_aging',{p_as_of:today}),rpc('trial_balance',{}),rpc('balance_sheet',{p_as_of:today}),rpc('inventory_valuation',{}),rpc('cashflow_summary',{p_from:first,p_to:today}),rpc('profit_loss',{p_from:first,p_to:today})
  ]);
  const hiddenNote=hid.length?`<div class="rp-bar"><span class="muted">مخفي: ${hid.length} تقرير</span><button class="btn soft sm" onclick="rpShowAll()">إظهار الكل</button></div>`:'';
  const bodies={
    tb:T(['الحساب','مدين','دائن','الرصيد'],tb.map(x=>[e(x.name),money(x.debit),money(x.credit),money(Math.abs(x.balance))])),
    bs:T(['الحساب','النوع','الرصيد'],bs.map(x=>[e(x.name),x.type,money(Math.abs(x.balance))])),
    ag:`<div class="rp-sub">العملاء</div>${T(['العميل','حالي','1-30','31-60','61-90','90+','الإجمالي'],ca.map(x=>[e(x.name),money(x.current_amt),money(x.d1_30),money(x.d31_60),money(x.d61_90),money(x.d90_plus),money(x.total)]))}<div class="rp-sub">الموردون</div>${T(['المورد','حالي','1-30','31-60','61-90','90+','الإجمالي'],sa.map(x=>[e(x.name),money(x.current_amt),money(x.d1_30),money(x.d31_60),money(x.d61_90),money(x.d90_plus),money(x.total)]))}`,
    inv:T(['الصنف','الكمية','التكلفة','القيمة'],inv.slice(0,100).map(x=>[e(x.product_name),fmt(x.qty),money(x.avg_cost),money(x.value)])),
    cf:T(['داخل','خارج','صافي'],cf.map(x=>[money(x.inflow),money(x.outflow),money(x.net)])),
    pl:pl.length?T(['البند','القيمة'],pl.map(x=>[e(x.account_name||x.metric||x.name||x.label||''),money(x.amount??x.value??x.total)])):'<div class="empty">لا توجد بيانات للفترة الحالية.</div>'
  };
  return `${sectionHead('التقارير والتحليلات','اختار التقارير اللي محتاجها: تقدر تخفي اللي مش بتستخدمه، وتصدّر أي تقرير لـ Excel بزرار واحد.')}${hiddenNote}<div class="report-cards">${RP_DEF.map(d=>rpCard(d[0],bodies[d[0]])).join('')}</div>`;
}


// ===== الأرباح بالتفاصيل (v1.82) =====
let PF={p:'month',from:'',to:''};
const pfFmtD=x=>`${x.getFullYear()}-${String(x.getMonth()+1).padStart(2,'0')}-${String(x.getDate()).padStart(2,'0')}`;
function pfRange(){const t=new Date(),y=t.getFullYear(),m=t.getMonth();
  switch(PF.p){
    case 'today':return[pfFmtD(t),pfFmtD(t)];
    case 'week':{const s=new Date(t);s.setDate(t.getDate()-6);return[pfFmtD(s),pfFmtD(t)]}
    case 'lastmonth':return[pfFmtD(new Date(y,m-1,1)),pfFmtD(new Date(y,m,0))];
    case 'year':return[pfFmtD(new Date(y,0,1)),pfFmtD(t)];
    case 'custom':return[PF.from||pfFmtD(new Date(y,m,1)),PF.to||pfFmtD(t)];
    default:return[pfFmtD(new Date(y,m,1)),pfFmtD(t)];
  }}
async function pfLoad(from,to){
  const [items,rets,exps,pays]=await Promise.all([
    sb.from('sales_invoice_items').select('invoice_id,product_id,qty,line_total,unit_cost,products(name),sales_invoices!inner(date,status)').eq('sales_invoices.status','Posted').gte('sales_invoices.date',from).lte('sales_invoices.date',to),
    sb.from('sales_return_items').select('return_id,product_id,qty,line_total,products(name),sales_returns!inner(date,invoice_id)').gte('sales_returns.date',from).lte('sales_returns.date',to),
    sb.from('expenses').select('category,amount,date').gte('date',from).lte('date',to),
    sb.from('payroll').select('net,month').gte('month',from.slice(0,8)+'01').lte('month',to)
  ]);
  for(const r of [items,rets,exps,pays]) if(r.error) throw r.error;
  const R_rets=rets.data||[];
  const invIds=[...new Set(R_rets.map(x=>x.sales_returns?.invoice_id).filter(Boolean))];
  const costMap=new Map();
  if(invIds.length){const c=await sb.from('sales_invoice_items').select('invoice_id,product_id,unit_cost').in('invoice_id',invIds);if(c.error)throw c.error;(c.data||[]).forEach(x=>costMap.set(x.invoice_id+'|'+x.product_id,+x.unit_cost||0))}
  return {items:items.data||[],rets:R_rets,exps:exps.data||[],pays:pays.data||[],costMap};
}
function pfCalc(D){
  const prod=new Map(), day=new Map();
  const P=(pid,name)=>{if(!prod.has(pid))prod.set(pid,{name:name||'—',qty:0,sales:0,cost:0});const p=prod.get(pid);if(name&&p.name==='—')p.name=name;return p};
  const Dd=(d)=>{if(!day.has(d))day.set(d,{p:0});return day.get(d)};
  let sales=0,cogs=0,retS=0,retC=0;
  for(const x of D.items){
    const s=+x.line_total||0, c=(+x.qty||0)*(+x.unit_cost||0);
    sales+=s; cogs+=c;
    const p=P(x.product_id,x.products?.name); p.qty+=+x.qty||0; p.sales+=s; p.cost+=c;
    const d=x.sales_invoices?.date; if(d) Dd(d).p+=s-c;
  }
  for(const x of D.rets){
    const s=+x.line_total||0, c=(+x.qty||0)*(D.costMap.get(x.sales_returns?.invoice_id+'|'+x.product_id)||0);
    retS+=s; retC+=c;
    const p=P(x.product_id,x.products?.name); p.qty-=+x.qty||0; p.sales-=s; p.cost-=c;
    const d=x.sales_returns?.date; if(d) Dd(d).p-=(s-c);
  }
  const netS=sales-retS, netC=cogs-retC, gp=netS-netC;
  const expCat=new Map(); let expTotal=0;
  for(const x of D.exps){const a=+x.amount||0;expTotal+=a;const k=x.category||'غير مصنف';expCat.set(k,(expCat.get(k)||0)+a)}
  const payTotal=D.pays.reduce((t,x)=>t+(+x.net||0),0);
  const beforePay=gp-expTotal, np=beforePay-payTotal;
  return {sales,retS,netS,cogs,retC,netC,gp,expTotal,expCat,payTotal,beforePay,np,prod,day};
}
async function profitView(){
  const [from,to]=pfRange();
  const D=await pfLoad(from,to), C=pfCalc(D);
  const pc=(x,base)=>base>0?`${(x/base*100).toFixed(1)}%`:'—';
  const presets=[['today','اليوم'],['week','آخر 7 أيام'],['month','هذا الشهر'],['lastmonth','الشهر اللي فات'],['year','هذه السنة'],['custom','فترة مخصصة']];
  const rows=[
    ['إجمالي المبيعات',C.sales,'',''],
    ['مرتجعات المبيعات',-C.retS,'',''],
    ['صافي المبيعات',C.netS,'b',pc(C.netS,C.netS)],
    ['تكلفة البضاعة المباعة',-C.netC,'',pc(C.netC,C.netS)],
    ['مجمل الربح',C.gp,'b',pc(C.gp,C.netS)],
    ['المصروفات',-C.expTotal,'',pc(C.expTotal,C.netS)],
    ['الربح بعد المصروفات',C.beforePay,'b',pc(C.beforePay,C.netS)],
    ['المرتبات (حسب الشهر)',-C.payTotal,'',pc(C.payTotal,C.netS)],
    ['صافي الربح',C.np,'big',pc(C.np,C.netS)]
  ];
  const list=rows.map(([l,v,k,p])=>`<div class="pf-row ${k}"><span>${l}</span><b>${money(v)}</b><em>${p}</em></div>`).join('');
  const prods=[...C.prod.entries()].map(([id,p])=>({id,...p,profit:p.sales-p.cost})).filter(p=>p.qty!==0||p.sales!==0).sort((a,b)=>b.profit-a.profit);
  const days=[...C.day.entries()].sort((a,b)=>a[0]<b[0]?-1:1).slice(-62);
  const maxAbs=Math.max(1,...days.map(([,v])=>Math.abs(v.p)));
  const bars=days.length?`<div class="pf-bars">${days.map(([d,v])=>`<div class="pf-bar" title="${d}"><i class="${v.p<0?'neg':''}" style="height:${Math.max(4,Math.round(Math.abs(v.p)/maxAbs*100))}%"></i><small>${d.slice(8)}</small></div>`).join('')}</div>`:'<div class="empty">لا توجد مبيعات في الفترة.</div>';
  const expRows=[...C.expCat.entries()].sort((a,b)=>b[1]-a[1]).map(([k,v])=>[e(k),money(v),pc(v,C.expTotal)]);
  const isEmpty=!D.items.length&&!D.exps.length&&!D.pays.length;
  return sectionHead('الأرباح بالتفاصيل','احسب الربح لأي فترة: مبيعات، مرتجعات، تكلفة، مصروفات، ومرتبات.')+
  `<div class="card np pf-top"><div class="hm-seg">${presets.map(([k,l])=>`<button class="hm-sb ${PF.p===k?'on':''}" onclick="PF.p='${k}';R()">${l}</button>`).join('')}</div>${PF.p==='custom'?`<div class="hm-dates"><input type="date" value="${from}" onchange="PF.from=this.value;R()"><input type="date" value="${to}" onchange="PF.to=this.value;R()"></div>`:`<span class="muted">من ${from} إلى ${to}</span>`}</div>`+
  `<div class="pf-kpis">
     <div class="pf-k k-blue"><small>صافي المبيعات</small><b>${fmt(C.netS)}</b></div>
     <div class="pf-k k-green"><small>مجمل الربح</small><b>${fmt(C.gp)}</b><em>${pc(C.gp,C.netS)} هامش</em></div>
     <div class="pf-k k-orange"><small>المصروفات + المرتبات</small><b>${fmt(C.expTotal+C.payTotal)}</b></div>
     <div class="pf-k ${C.np>=0?'k-green':'k-red'}"><small>صافي الربح</small><b>${fmt(C.np)}</b><em>${pc(C.np,C.netS)} هامش</em></div>
   </div>`+
  (isEmpty?`<div class="card"><div class="empty">لا توجد حركات في هذه الفترة.</div></div>`:'')+
  `<div class="pf-grid"><div class="card"><div class="card-title"><b>قائمة الربح</b></div><div class="pf-list">${list}</div></div>
   <div class="card"><div class="card-title"><b>الربح اليومي</b><span class="muted">آخر ${days.length} يوم بمبيعات</span></div>${bars}</div></div>`+
  `<div class="pf-grid"><div class="card"><div class="card-title"><b>الأصناف حسب الربح</b><span class="muted">${prods.length} صنف</span></div>${prods.length?T(['الصنف','الكمية','المبيعات','التكلفة','الربح','الهامش'],prods.slice(0,100).map(p=>[e(p.name),fmt(p.qty),money(p.sales),money(p.cost),money(p.profit),pc(p.profit,p.sales)])):'<div class="empty">لا توجد أصناف مباعة.</div>'}</div>
   <div class="card"><div class="card-title"><b>المصروفات حسب البند</b></div>${expRows.length?T(['البند','المبلغ','النسبة'],expRows):'<div class="empty">لا توجد مصروفات في الفترة.</div>'}</div></div>`+
  `<p class="muted pf-note">الأرقام من فواتير البيع المرحّلة، ومرتجعات البيع، والمصروفات، ومرتبات الأشهر داخل الفترة. الضريبة مش داخلة في الربح. تكلفة المرتجع محسوبة بتكلفة الصنف وقت البيع.</p>`;
}

// Override dashboard test to call the enterprise suite.
const PERMISSION_GROUPS=[
  ['المبيعات',[['sales','المبيعات'],['quo','عروض الأسعار'],['ord','أوامر البيع'],['dn','التسليم'],['cust','الأطراف'],['ret','المرتجعات'],['comm','العمولات'],['price','قوائم الأسعار']]],
  ['المشتريات',[['purch','المشتريات'],['po','أوامر الشراء'],['grn','استلام المشتريات'],['supp','الموردون']]],
  ['المخزون',[['prod','الأصناف'],['trf','التحويلات المخزنية'],['stk','الجرد'],['trace','تتبع وحركة الصنف']]],
  ['المالية',[['pay','المدفوعات'],['exp','المصروفات'],['cash','الخزينة'],['bank','البنوك والتسويات'],['chk','الشيكات'],['stmt','كشف الحساب'],['jr','المحاسبة العامة'],['asset','الأصول الثابتة'],['taxdoc','المستندات الضريبية'],['rep','التقارير']]],
  ['الموظفون',[['emp','الموظفون'],['hr','الحضور والإجازات'],['prl','المرتبات']]],
  ['الأساسيات',[['dash','الرئيسية']]]
];
let permEditorUser=null,permEditorMode='role',permEditorSet=new Set();
async function openPermissionEditor(id){const r=await rpc('admin_get_user_permissions',{p_user:id});if(!r)throw Error('تعذر تحميل الصلاحيات');permEditorUser=id;permEditorMode=r.mode||'role';permEditorSet=new Set(Array.isArray(r.permissions)?r.permissions:[]);R()}
function togglePerm(key,checked){if(checked)permEditorSet.add(key);else permEditorSet.delete(key)}
async function savePermissionEditor(){if(!permEditorUser)return;await act(async()=>{await rpc('save_user_permissions',{p_user:permEditorUser,p_permissions:[...permEditorSet]});await openPermissionEditor(permEditorUser)});toast('تم حفظ الصلاحيات المخصصة')}
async function resetPermissionEditor(){if(!permEditorUser)return;await act(async()=>{await rpc('reset_user_permissions',{p_user:permEditorUser});await openPermissionEditor(permEditorUser)});toast('تم إرجاع المستخدم لصلاحيات الدور الأساسي')}
async function usersView(){
  const L=(await g('profiles','created_at')).filter(u=>me.isDev||u.role!=='developer');
  const target=L.find(x=>x.id===permEditorUser);
  const editor=target&&!['admin','developer'].includes(target.role)?`<div class="card"><div class="card-title"><div><b>تخصيص الصلاحيات: ${e(target.name)}</b><div class="muted">الدور الأساسي: ${e(target.role)} · التخصيص هنا يضيّق صلاحيات الدور ولا يوسعها.</div></div><span class="chip ${permEditorMode==='custom'?'warning':'success'}">${permEditorMode==='custom'?'مخصص':'حسب الدور'}</span></div>${PERMISSION_GROUPS.map(([title,items])=>`<div class="perm-group"><h4>${title}</h4><div class="perm-grid">${items.map(([id,label])=>{const allowed=canBaseForRole(target.role,id);const checked=permEditorSet.has(id);return `<label class="perm-item ${allowed?'':'disabled'}"><input type="checkbox" ${checked?'checked':''} ${allowed?'':'disabled'} onchange="togglePerm('${id}',this.checked)"><span>${label}</span>${allowed?'':'<small>خارج الدور</small>'}</label>`}).join('')}</div></div>`).join('')}<div class="row"><button class="btn" onclick="savePermissionEditor()">حفظ التخصيص</button><button class="btn soft" onclick="resetPermissionEditor()">إرجاع لصلاحيات الدور</button></div></div>`:'';
  return `${sectionHead('المستخدمون والصلاحيات','الدور الأساسي يحدد الحد الأعلى، والتخصيص يختار ما يظهر لهذا المستخدم.')}
  ${me.role==='admin'?addUserCard():''}
  <div class="card">${T(['الاسم','البريد','الدور الأساسي','الوضع','مفعّل','التخصيص'],L.map(u=>[e(u.name),e(u.username),(u.role==='admin'||u.role==='developer')?'<b>admin</b>':`<select ${u.id===me.id?'disabled':''} onchange="act(()=>upd('profiles','${u.id}',{role:this.value}))">${(me.isDev?['accountant','sales','store','developer']:['accountant','sales','store']).map(r=>`<option value="${r}" ${u.role===r?'selected':''}>${r}</option>`).join('')}</select>`,chip((u.role==='admin'||u.role==='developer')?'كامل':(u.permissions_mode==='custom'?'مخصص':'حسب الدور'),(u.role==='admin'||u.role==='developer')?'success':u.permissions_mode==='custom'?'warning':'info'),`<input type="checkbox" ${u.active?'checked':''} ${u.id===me.id?'disabled':''} onchange="act(()=>upd('profiles','${u.id}',{active:this.checked}))">`,(u.role==='admin'||u.role==='developer')?'<span class="muted">صلاحيات المدير كاملة</span>':`<button class="btn soft" onclick="openPermissionEditor('${u.id}')">تخصيص</button>`]))}</div>${editor}`;
}
function addUserCard(){
  const roles=['accountant','sales','store','admin',...(me.isDev?['developer']:[])];
  return `<div class="card form-card"><div class="card-title"><b>إضافة مستخدم جديد</b><span class="muted">الحساب بيتفعّل فوراً بالدور اللي تختاره</span></div><div class="row"><input id="nu_name" placeholder="الاسم"><input id="nu_user" placeholder="اسم المستخدم (للدخول)" autocomplete="off"><input id="nu_email" type="email" placeholder="الإيميل"><input id="nu_phone" type="tel" placeholder="الموبايل (+20...)"><input id="nu_pass" type="password" placeholder="كلمة السر (8 حروف على الأقل)"><select id="nu_role">${roles.map(r=>`<option value="${r}">${r}</option>`).join('')}</select><button class="btn" onclick="createAppUser()">إضافة المستخدم</button></div></div>`;
}
async function createAppUser(){
  const name=v('nu_name').trim(), username=v('nu_user').trim(), email=v('nu_email').trim(), phone=v('nu_phone').replace(/\s+/g,''), password=v('nu_pass'), role=v('nu_role');
  if(!name||!username||!email||!phone||password.length<8){toast('أدخل الاسم واسم المستخدم والإيميل والموبايل وكلمة سر 8 حروف على الأقل');return}
  await act(async()=>{
    const{data,error}=await sb.functions.invoke('admin-create-user',{body:{name,username,email,phone,password,role}});
    if(error){let msg=error.message;try{const j=await error.context.json();if(j&&j.error)msg=j.error}catch(_){}throw Error(msg)}
    if(data&&data.error)throw Error(data.error);
  });
  R();
}
function canBaseForRole(role,id){return role==='admin'||(Array.isArray(ROLE2[role])&&ROLE2[role].includes(id))}

async function accountsView(){
 const tb=await rpc('trial_balance',{});return `${sectionHead('المحاسبة العامة','دفتر أستاذ، ميزان مراجعة وقيود يدوية.')}
 <div class="card form-card"><div class="row"><input id="jd" type="date" value="${new Date().toISOString().slice(0,10)}"><input id="jdesc" placeholder="وصف القيد"><input id="jc1" placeholder="كود الحساب المدين"><input id="ja1" type="number" placeholder="المبلغ"><input id="jc2" placeholder="كود الحساب الدائن"><input id="ja2" type="number" placeholder="المبلغ"><button class="btn" onclick="act(()=>rpc('create_manual_journal',{p_date:v('jd'),p_description:v('jdesc'),p_lines:[{account_code:v('jc1'),debit:n('ja1'),credit:0},{account_code:v('jc2'),debit:0,credit:n('ja2')}]}))">حفظ قيد</button><button class="btn soft" onclick="act(()=>rpc('rebuild_journal',{}))">تحديث اليومية</button></div></div><div class="card">${T(['الكود','الحساب','النوع','مدين','دائن','الرصيد'],tb.map(x=>[e(x.code),e(x.name),x.type,money(x.debit),money(x.credit),money(Math.abs(x.balance))]))}</div>`}

async function cashView(){const CH=await cashTransfersHtml();return `${sectionHead('الخزينة','الحسابات النقدية والتحويلات الداخلية.')}<div class=\"card form-card\"><div class=\"row\"><input id=\"an\" placeholder=\"اسم حساب\"><select id=\"at\"><option value=\"cash\">خزينة</option><option value=\"bank\">بنك</option><option value=\"wallet\">محفظة</option><option value=\"other\">أخرى</option></select><input id=\"ao\" type=\"number\" placeholder=\"رصيد افتتاحي\"><button class=\"btn\" onclick=\"act(()=>ins('cash_accounts',{name:v('an'),type:v('at'),opening_balance:n('ao'),balance:n('ao')}))\">إضافة</button></div></div><div class=\"card form-card\"><h3>تحويل بين الحسابات</h3><div class=\"row\"><select id=\"ctf\">${O(C.accts)}</select><select id=\"ctt\">${O(C.accts)}</select><input id=\"ctam\" type=\"number\" placeholder=\"المبلغ\"><button class=\"btn\" onclick=\"act(()=>{if(v('ctf')===v('ctt'))throw Error('اختر حسابين مختلفين');return rpc('transfer_cash',{p_from:v('ctf'),p_to:v('ctt'),p_amount:n('ctam')})})\">تحويل</button></div></div><div class=\"card\">${T(['الحساب','النوع','الرصيد'],C.accts.map(a=>[e(a.name),a.type,money(a.balance)]))}</div><div class="card"><h3>سجل التحويلات بين الحسابات</h3>${CH}</div>`;}
async function R(q){
  localStorage.setItem('erp_v_view',view);
  if(!me){return _loginScreen()}
  if(!me.active){return _inactiveScreen()}
  if(!can(view))view='dash';
  localStorage.setItem('erp_v_view',view);
  if(!C){const c=readCachedC();if(c){C=c;await paintView(q)}}
  await loadAll(q==='soft'||q===1);
  await paintView(q);
}
async function paintView(q){
  let h='';
  try{
    if(view==='dash')h=await dash(); else if(view==='po')h=await poView(); else if(view==='grn')h=await grnView(); else if(view==='dn')h=await dnView();
    else if(view==='asset')h=await assetView(); else if(view==='bank')h=await bankView(); else if(view==='price')h=await priceView();
    else if(view==='hr')h=await hrView(); else if(view==='mfg')h=await mfgView(); else if(view==='pos')h=await posView(); else if(view==='proj')h=await projView(); else if(view==='period')h=await periodView();
    else if(view==='trace')h=await traceView(); else if(view==='data')h=await dataView(); else if(view==='health')h=await healthView(); else if(view==='devset')h=await devSetView(); else if(view==='rep')h=await reportsView(); else if(view==='profit')h=await profitView(); else if(view==='bud')h=await budgetView(); else if(view==='jr')h=await accountsView(); else if(view==='users')h=await usersView();
    else if(view==='shareholders')h=await shareholdersView(); else if(view==='appr')h=await approvalView(); else if(view==='chk')h=await chequeView(); else if(view==='comm')h=await commissionView(); else if(view==='taxdoc')h=await taxdocView(); else if(view==='int')h=await integrationsView(); else if(view==='org')h=await orgView(); else if(view==='whs')h=await warehousesView(); else if(view==='cosettings')h=await coSettingsView(); else if(view==='printcfg')h=await printSettingsView(); else if(view==='fullbak')h=fullBakView(); else h=await legacyHtml();
    if(!h)h='<div class="card">صفحة غير متاحة.</div>';
    if(view==='dash')h=quickBar()+h+'<div class="app-version">الإصدار '+APP_VERSION+'</div>';
    if(view!=='dash'){const back=(window._nav&&window._nav.length)?'<button class="btn s" onclick="goBack()">'+ico('back')+' رجوع</button>':'';h=`<div class="no-print" style="margin-bottom:10px;display:flex;gap:8px;flex-wrap:wrap">${back}<button class="btn s" onclick="go('dash')">${ico('home')} الرئيسية</button></div>`+h}
  }catch(x){h=`<div class="card error-card"><b>تعذر تحميل الصفحة</b><p>${e(x.message||x)}</p></div>`}
  const links=renderNavGroups();
  const shellKey=me.id+'|'+me.role+'|'+(me.isDev?'d':'');
  const viewChanged=window._animView!==view;window._animView=view;
  if(window._shellKey===shellKey&&$('.sidebar')&&$('.page')&&$('.mobile-bottom')){const pg=$('.page');if(window._lastLinks!==links){$('nav').innerHTML=links;window._lastLinks=links}pg.innerHTML=h;if(viewChanged){pg.classList.remove('pg-in');void pg.offsetWidth;pg.classList.add('pg-in')}$('.mobile-bottom').innerHTML=bottomNav()}
  else{window._shellKey=shellKey;$('#app').innerHTML=`<div class="mobile-overlay" onclick="closeMobileNav()"></div><aside class="sidebar"><div class="brandbox"><div class="brandmark"><img src="./brand/fedo-symbol-dark.svg" alt=""></div><div><b>FEDO ERP</b><small>Finance · Inventory · Operations</small></div><small class="powered">${POWERED_BY_TEXT}</small></div><div class="userbox"><div class="avatar">${e((me.name||'U').slice(0,1))}</div><div><b>${e(me.name)}</b><small>${e(me.isDev?'مطور':me.role)}</small></div></div><nav>${links}</nav><div class="side-bottom"><button class="sidebtn danger-link" onclick="closeMobileNav();logout()">تسجيل الخروج</button></div></aside><main class="shell"><header class="topbar"><button class="mobile-menu-btn" onclick="openMobileNav()" aria-label="فتح القائمة">${ico('menu')}</button><div class="top-search" style="position:relative"><span class="ico-s">${ico('search')}</span><input id="gs" autocomplete="off" placeholder="بحث سريع في النظام" oninput="gsSearch(this.value)" onkeydown="gsKey(event)"/><div id="gsRes" hidden style="position:absolute;top:calc(100% + 6px);left:0;right:0;background:var(--card,#fff);color:var(--fg,#101C2C);border:1px solid rgba(16,28,44,.25);border-radius:12px;box-shadow:0 12px 32px rgba(16,28,44,.18);z-index:999;max-height:60vh;overflow:auto;padding:6px;text-align:start"></div></div><div class="top-actions"><div id="netStatus"></div>${langSeg()}${fedoThemeBtn("iconbtn theme-btn")}<span class="ver-pill" title="رقم الإصدار">${APP_VERSION}</span>${me.isDev?'<button class="iconbtn" title="فحص الجاهزية" onclick="go(\'health\')">'+ico('check')+'</button>':''}<button class="role-pill">${e(me.role)}</button></div></header><div class="page${viewChanged?' pg-in':''}">${h}</div><div class="mobile-bottom">${bottomNav()}</div></main>`;}
  if(q){const i=$('#q');if(i){i.focus();i.setSelectionRange(99,99)}}
  updateOnlineStatus();
}
const QA_ALL=[['sales','فاتورة بيع'],['purch','فاتورة شراء'],['cash','الخزينة والتحويلات'],['cust','عميل جديد'],['prod','منتج جديد'],['stk','الجرد'],['hr','الحضور والإجازات'],['rep','التقارير']];
const QA_DEFAULT=['sales','purch','cash','cust','rep'];
const APP_VERSION='FEDO-FACTORY-DEV-1';
async function loadQuick(){try{const{data}=await sb.from('user_quick_actions').select('actions').eq('user_id',me.id).maybeSingle();window._qa=(data&&Array.isArray(data.actions)&&data.actions.length)?data.actions:QA_DEFAULT}catch(_){window._qa=QA_DEFAULT}}
function quickBar(){
  const cur=window._qa||QA_DEFAULT;
  const list=cur.filter(id=>QA_ALL.some(x=>x[0]===id)&&can(id));
  const btns=list.map(id=>`<button class="btn soft" onclick="go('${id}')">${e(QA_ALL.find(x=>x[0]===id)[1])}</button>`).join('');
  const edit=window._qaEdit?`<div class="qa-edit"><div class="card-title"><b>اختر الاختصارات اللي تظهر لك</b></div><div class="perm-grid">${QA_ALL.filter(x=>can(x[0])).map(([id,l])=>`<label class="perm-item"><input type="checkbox" ${((window._qaDraft||cur).includes(id))?'checked':''} onchange="qaToggle('${id}',this.checked)"><span>${l}</span></label>`).join('')}</div><div class="mt10"><button class="btn" onclick="saveQuick()">حفظ</button> <button class="btn soft" onclick="window._qaEdit=false;window._qaDraft=null;R('soft')">إلغاء</button></div></div>`:'';
  return `<div class="card quickbar"><div class="quick-row">${btns||'<span class="muted">لا توجد اختصارات متاحة</span>'}<button class="btn soft" onclick="window._qaEdit=!window._qaEdit;window._qaDraft=null;R('soft')">${ico('gear')} تخصيص</button></div>${edit}</div>`;
}
function qaToggle(id,on){const cur=new Set(window._qaDraft||window._qa||QA_DEFAULT);on?cur.add(id):cur.delete(id);window._qaDraft=[...cur]}
async function saveQuick(){
  const list=window._qaDraft||window._qa||QA_DEFAULT;
  await act(async()=>{const{error}=await sb.from('user_quick_actions').upsert({user_id:me.id,actions:list,updated_at:new Date().toISOString()});if(error)throw error;window._qa=list;window._qaEdit=false;window._qaDraft=null});
  R('soft');
}
function bottomNav(){return NAV.filter(x=>can(x[0])).filter(x=>['dash','sales','purch','pay','trace'].includes(x[0])).map(x=>`<button class="${view===x[0]?'active':''}" onclick="go('${x[0]}')">${x[1]}</button>`).join('')}
let _qTimer=null;
function qSearch(el){window._q=el.value;clearTimeout(_qTimer);_qTimer=setTimeout(()=>{R(1).then(()=>{const q=document.getElementById('q');if(q){q.focus();q.setSelectionRange(q.value.length,q.value.length)}})},250)}
function readCachedC(){const r=k=>{try{return JSON.parse(localStorage.getItem('erp_cache_'+k)||'null')}catch{return null}};const products=r('products'),customers=r('customers'),suppliers=r('suppliers'),warehouses=r('warehouses'),stock=r('stock'),cb=r('cb'),sbal=r('sbal');if(!products||!customers||!suppliers||!warehouses||!stock||!cb||!sbal)return null;return{products,customers,suppliers,warehouses,accts:r('cash_accounts')||[],stock,cb,sbal}}
function lgShell(inner){return `<div class="lg-page"><div class="lg-wrap"><aside class="lg-brand"><div class="lg-bg"></div><div class="lg-brand-top"><div class="lg-wordmark-wrap"><img class="lg-wordmark" src="./brand/fedo-logo-dark.svg" alt="FEDO ERP"></div></div><div class="lg-brand-mid"><h1>كل أعمال شركتك في مكان واحد</h1><p>مبيعات ومشتريات ومخزون ومحاسبة وموارد بشرية، بصلاحيات دقيقة وتحقق ثنائي للإدارة.</p><ul class="lg-feats"><li><span>${ico('receipt')}</span>فواتير مبيعات ومشتريات بترقيم مستقل</li><li><span>${ico('box')}</span>مخزون متعدد المخازن مع تتبع وتنبيهات</li><li><span>${ico('chart')}</span>تقارير مالية وميزان مراجعة لحظي</li><li><span>${ico('shield')}</span>حماية بالتحقق الثنائي والجهاز الموثوق</li></ul></div><div class="lg-brand-foot">الإصدار ${APP_VERSION}</div></aside><section class="lg-card">${fedoThemeBtn("theme-btn lg-theme")}${inner}</section></div></div>`}
function _loginScreen(){$('#app').innerHTML=lgShell(`<div class="lg-head"><span class="lg-eyebrow">مرحبًا بيك</span><h2>تسجيل الدخول</h2><p>ادخل ببريدك الإلكتروني أو اسم المستخدم أو رقم الموبايل.</p></div><div class="lg-field"><label for="lu">الإيميل أو اسم المستخدم أو الموبايل</label><div class="lg-in"><span>@</span><input id="lu" type="text" autocomplete="username" placeholder="name@company.com"></div></div><div class="lg-field"><label for="lp">كلمة المرور</label><div class="lg-in"><span>${ico('lock')}</span><input id="lp" type="password" autocomplete="current-password" placeholder="••••••••"><button type="button" class="lg-eye" onclick="lgTogglePw()" aria-label="إظهار أو إخفاء كلمة المرور">إظهار</button></div></div><button class="lg-submit" onclick="login()">تسجيل الدخول</button><p class="lg-note">${ico('lockkey')} الاتصال مشفّر. الحساب الأول في المشروع الجديد يُنشأ كمدير حسب إعدادات قاعدة البيانات.</p>`)}
function _inactiveScreen(){$('#app').innerHTML=lgShell(`<div class="lg-head"><span class="lg-eyebrow">خطوة واحدة متبقية</span><h2>الحساب بانتظار التفعيل</h2><p>سيتطلب الحساب تفعيل المدير قبل استخدام النظام.</p></div><button class="lg-submit" onclick="logout()">خروج</button>`)}
function lgTogglePw(){const i=document.getElementById('lp');if(!i)return;const show=i.type==='password';i.type=show?'text':'password';const b=document.querySelector('.lg-eye');if(b)b.textContent=show?'إخفاء':'إظهار'}

async function signInWithIdentifier(id,password){const{data,error}=await sb.functions.invoke('login-with-identifier',{body:{identifier:String(id||'').trim(),password:String(password||'')}});if(error||!data?.access_token)throw Error('Invalid login credentials');const{error:se}=await sb.auth.setSession({access_token:data.access_token,refresh_token:data.refresh_token});if(se)throw se}
async function login(){return withLoading(async()=>{await signInWithIdentifier(v('lu'),v('lp'));clearDataCache();location.reload()},'جاري تسجيل الدخول...','جارٍ الاتصال بالنظام بأمان')}
async function logout(){return withLoading(async()=>{try{await sb.auth.signOut({scope:'local'})}catch{}try{await sb.auth.signOut()}catch{}me=null;C=null;clearDataCache();try{localStorage.removeItem('erp_v_view')}catch{}location.reload()},'جاري تسجيل الخروج...','جارٍ إنهاء الجلسة بأمان')}

// ----- قفل الموقع + خروج كل الجلسات (v1.61) -----
const SESS_SEEN_KEY='erp_sess_seen';
function showLockScreen(msg){
  let d=document.getElementById('lockScreen');
  if(!d){d=document.createElement('div');d.id='lockScreen';d.style.cssText='position:fixed;inset:0;z-index:99999;background:#101C2C;color:#fff;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:14px;padding:24px;text-align:center;font-size:17px;';document.body.appendChild(d)}
  d.innerHTML='<div style="font-size:44px">'+ico('lock')+'</div><div style="font-weight:700;font-size:20px">الموقع مقفول مؤقتاً</div><div style="opacity:.85;max-width:420px;line-height:1.7">'+e(msg||'')+'</div><button id="lockOut" style="margin-top:8px;padding:10px 22px;border-radius:10px;border:0;cursor:pointer;font-size:16px">تسجيل خروج</button>';
  document.getElementById('lockOut').onclick=async()=>{try{await sb.auth.signOut()}catch{}location.reload()};
}
function hideLockScreen(){document.getElementById('lockScreen')?.remove()}
async function lockGate(loggedIn){
  let st=null;try{st=await rpc('app_lock_state',{})}catch{}
  if(!st)return false;
  if(st.locked&&loggedIn&&!st.bypass){showLockScreen(st.msg);return true}
  hideLockScreen();return false;
}
async function checkAppLock(){
  try{
    const{data:{user}}=await sb.auth.getUser();
    const st=await rpc('app_lock_state',{});
    let seen=null;try{seen=localStorage.getItem(SESS_SEEN_KEY)}catch{}
    if(seen===null){try{localStorage.setItem(SESS_SEEN_KEY,String(st.epoch))}catch{};}
    else if(String(st.epoch)!==seen){
      try{localStorage.setItem(SESS_SEEN_KEY,String(st.epoch))}catch{}
      try{await sb.auth.signOut()}catch{}
      location.reload();return;
    }
    if(user&&st.locked&&!st.bypass){showLockScreen(st.msg)}
    else if(document.getElementById('lockScreen')){location.reload()}
  }catch{}
}
setTimeout(checkAppLock,6000);
setInterval(checkAppLock,120000);
document.addEventListener('visibilitychange',()=>{if(!document.hidden)checkAppLock()});
async function devToggleLock(){
  try{
    const st=await rpc('app_lock_state',{});
    const rn={admin:'الأدمن',accountant:'المحاسب',sales:'المبيعات',store:'المخزن'};
    const cur=new Set(st.roles||[]);
    formModal('قفل الموقع',
      `<label class="fm-f"><span>رسالة الصيانة اللي هتظهر للمستخدمين</span><textarea id="lk_m" rows="3">${e(st.msg||'الموقع تحت الصيانة، جرّب بعد شوية.')}</textarea></label>`+
      `<div class="fm-f"><span>مسموح دخولهم وقت القفل (المطور دايماً مسموح)</span>${Object.keys(rn).map(r=>`<label style="display:block;margin:4px 0"><input type="checkbox" class="lk_r" value="${r}" ${cur.has(r)?'checked':''}> ${rn[r]}</label>`).join('')}</div>`+
      `<label class="fm-f"><span>ينتهي القفل في (اختياري، اتركه فاضي لو هتفتحه بإيدك)</span><input id="lk_u" type="datetime-local"></label>`,
      async()=>{
        const m=v('lk_m');
        const roles=[...document.querySelectorAll('.lk_r:checked')].map(x=>x.value);
        const u=v('lk_u');
        const until=u?new Date(u).toISOString():null;
        await rpc('dev_set_lock',{p_locked:true,p_msg:m,p_roles:roles,p_until:until});
        await R();
      },'تطبيق القفل');
  }catch(x){alert('تعذر: '+(x.message||x))}
}
async function devUnlock(){
  if(!confirm('نفتح الموقع لكل المستخدمين؟'))return;
  try{await rpc('dev_set_lock',{p_locked:false,p_msg:'',p_roles:[],p_until:null});alert('الموقع اتفتح.');await R()}
  catch(x){alert('تعذر: '+(x.message||x))}
}
async function forgetDevice(){
  if(!confirm('نسيت الجهاز ده؟ الدخول الجاي من الجهاز ده هيطلب كود التحقق.'))return;
  try{
    const{error}=await sb.rpc('revoke_my_trusted_device');
    if(error)throw error;
    try{localStorage.removeItem(TRUST_KEY)}catch(_){}
    toast('اتلغى الجهاز المتذكر');
  }catch(x){alert('تعذر إلغاء الجهاز: '+(x.message||x))}
}
async function devRevokeAll(){
  if(!confirm('نسجّل خروج كل المستخدمين؟ حسابك كمان هيتقفل ولازم تسجل دخول تاني.'))return;
  try{
    await rpc('dev_revoke_all_sessions',{});
    try{localStorage.removeItem(SESS_SEEN_KEY)}catch{}
    try{localStorage.removeItem(TRUST_KEY)}catch{}
    try{await sb.auth.signOut()}catch{}
    location.reload();
  }catch(x){alert('تعذر: '+(x.message||x))}
}

// ----- إعدادات المطور (v1.62) -----
async function devSetView(){
  if(!me||!me.isDev)return `<div class="card"><p class="muted">هذه الصفحة للمطور فقط.</p></div>`;
  const st=await rpc('app_lock_state',{});
  const rn={admin:'الأدمن',accountant:'المحاسب',sales:'المبيعات',store:'المخزن'};
  const who=(st.roles||[]).map(r=>rn[r]||r).join('، ')||'المطور بس';
  const until=st.until?new Date(st.until).toLocaleString(locOf(),{timeZone:'Africa/Cairo'}):'يدوي (بيتفتح بإيدك)';
  return `${sectionHead('إعدادات المطور','أدوات المطور بس. كل تغيير هنا بيتسجل في سجل العمليات.')}
  <div class="card"><div class="card-title"><b>قفل الموقع</b> ${chip(st.locked?'مقفول':'مفتوح',st.locked?'warning':'success')}</div>
    <p class="muted">الرسالة: ${e(st.msg||'—')}</p>
    <p class="muted">مسموح دخولهم وقت القفل: ${e(who)}</p>
    <p class="muted">ينتهي: ${e(until)}</p>
    <div class="row-btns"><button class="s" onclick="devToggleLock()">${st.locked?'تعديل القفل':'قفل الموقع'}</button>${st.locked?'<button class="s" onclick="devUnlock()">فتح الموقع</button>':''}</div></div>
  ${await devMfaCard()}
  <div class="card"><div class="card-title"><b>خروج كل المستخدمين</b></div>
    <p class="muted">يقفل كل الجلسات الحالية، ولازم كل حد يسجل دخول تاني (وحسابك كمان).</p>
    <div class="row-btns"><button class="s" onclick="devRevokeAll()">تسجيل خروج للكل</button></div></div>
  <div class="card"><div class="card-title"><b>تحديث الواجهة</b></div>
    <p class="muted">يخلي كل المستخدمين يحملوا أحدث نسخة أوتوماتيك.</p>
    <div class="row-btns"><button class="s" onclick="pushAppUpdate()">إرسال التحديث</button></div></div>
  <div class="card"><div class="card-title"><b>فحوصات</b></div>
    <div class="row-btns"><button class="s" onclick="go('health')">فحص الجاهزية</button><button class="s" onclick="go('audit')">سجل العمليات</button></div></div>`;
}
Object.assign(AU_ACT,{insert:'إضافة'});
Object.assign(AU_ENT,{app_control:'إعدادات التحكم بالنظام',parties:'طرف (عميل/مورد)',attendance:'حضور',accounts:'حساب (دليل)',approval_requests:'طلب اعتماد',asset_categories:'تصنيف أصول',bank_statement_lines:'سطر كشف بنك',bank_statements:'كشف بنك',bom_items:'مكون تصنيع',boms:'وصفة تصنيع',branches:'فرع',cash_movements:'حركة خزينة',categories:'تصنيف',commission_rules:'قاعدة عمولة',cost_centers:'مركز تكلفة',delivery_note_items:'صنف إذن تسليم',goods_receipt_items:'صنف استلام',integration_connections:'اتصال تكامل',integration_events:'حدث تكامل',inventory_lot_balances:'رصيد دفعة مخزون',inventory_lots:'دفعة مخزون',inventory_serials:'رقم تسلسلي',journal_lines:'سطر قيد',leave_requests:'طلب إجازة',leave_types:'نوع إجازة',notifications:'إشعار',payment_allocations:'توزيع دفعة',pos_session_sales:'مبيعات جلسة كاشير',pos_sessions:'جلسة كاشير',price_list_items:'صنف قائمة أسعار',price_lists:'قائمة أسعار',product_barcodes:'باركود',projects:'مشروع',purchase_invoice_items:'صنف فاتورة شراء',purchase_order_items:'صنف أمر شراء',purchase_return_items:'صنف مرتجع شراء',quotation_items:'صنف عرض سعر',sales_commissions:'عمولة مبيعات',sales_invoice_items:'صنف فاتورة بيع',sales_order_items:'صنف أمر بيع',sales_return_items:'صنف مرتجع بيع',service_tickets:'تذكرة خدمة',shifts:'وردية',stock_movements:'حركة مخزون',stock_transfer_items:'صنف تحويل مخزني',stocktake_items:'صنف جرد',tax_documents:'مستند ضريبي',units:'وحدة قياس',user_quick_actions:'اختصار مستخدم',audit_logs:'سجل العمليات'});
const auDesc=x=>{const d=x.description||'';const m=d.match(/^DB trigger: (\w+) on (\w+)/);if(!m)return d;const pre={INSERT:'إضافة سجل في ',UPDATE:'تعديل سجل في ',DELETE:'حذف سجل من '}[m[1]]||'';return pre+(AU_ENT[m[2]]||m[2])};

// ----- تسجيل خروج تلقائي بعد ساعة خمول (v1.63، الوقت اتغير لساعة) -----
const IDLE_MS=60*60*1000;let _idleT=null;
function resetIdle(){
  clearTimeout(_idleT);
  _idleT=setTimeout(async()=>{
    try{const{data:{session}}=await sb.auth.getSession();if(!session)return;await sb.auth.signOut()}catch{}
    alert('اتسجل خروجك تلقائياً بسبب الخمول. سجّل دخول تاني.');
    location.reload();
  },IDLE_MS);
}
['mousemove','keydown','pointerdown','touchstart','scroll'].forEach(ev=>document.addEventListener(ev,resetIdle,{passive:true}));
setTimeout(resetIdle,0);

// ----- البحث الشامل من الشريط العلوي (v1.64) -----
let _gsT=null, _gsList=[];
const gsBox=()=>document.getElementById('gsRes');
function gsHide(){const b=gsBox();if(b){b.hidden=true;b.innerHTML=''}}
function gsSearch(q){
  clearTimeout(_gsT);
  q=(q||'').trim();
  if(q.length<2){gsHide();return}
  _gsT=setTimeout(()=>gsRun(q),200);
}
async function gsRun(q){
  const ql=q.toLowerCase();
  const hit=x=>[x.name,x.code,x.barcode,x.phone,x.email].filter(Boolean).join(' ').toLowerCase().includes(ql);
  const out=[];
  const add=(title,items,mk)=>{if(items.length)out.push([title,items.map(mk)])};
  if(C&&can('prod'))add('الأصناف',(C.products||[]).filter(hit).slice(0,5),x=>({label:x.name,sub:x.code||x.barcode||'',view:'prod',term:x.name}));
  if(C&&(can('cust')||can('supp'))){
    const seen=new Map();
    const pushP=(x,view)=>{const k=(x.name||'').trim().toLowerCase();if(!k)return;if(seen.has(k)){if(view==='cust')seen.get(k).view='cust';return}seen.set(k,{label:x.name,sub:x.phone||'',view,term:x.name})};
    if(can('cust'))(C.customers||[]).filter(hit).forEach(x=>pushP(x,'cust'));
    if(can('supp'))(C.suppliers||[]).filter(hit).forEach(x=>pushP(x,'supp'));
    add('الأطراف',[...seen.values()].slice(0,8),x=>x);
  }
  try{
    if(can('sales')){const r=await sb.from('sales_invoices').select('id,number').ilike('number','%'+q+'%').limit(5);if(!r.error)add('فواتير البيع',r.data||[],x=>({label:x.number,sub:'',view:'sales',term:x.number}))}
    if(can('purch')){const r=await sb.from('purchase_invoices').select('id,number').ilike('number','%'+q+'%').limit(5);if(!r.error)add('فواتير الشراء',r.data||[],x=>({label:x.number,sub:'',view:'purch',term:x.number}))}
  }catch{}
  _gsList=[];
  const b=gsBox(); if(!b)return;
  if(!out.length){b.hidden=false;b.innerHTML='<div style="padding:10px;opacity:.7">مفيش نتايج</div>';return}
  b.hidden=false;
  b.innerHTML=out.map(([t,rows])=>`<div style="font-size:12px;opacity:.7;padding:6px 8px">${e(t)}</div>`+rows.map(r=>{
    const i=_gsList.push(r)-1;
    return `<button onmousedown="event.preventDefault()" onclick="gsGo(${i})" style="display:flex;width:100%;justify-content:space-between;gap:10px;text-align:start;background:transparent;border:0;padding:8px 10px;border-radius:8px;cursor:pointer;color:inherit"><b>${e(r.label)}</b><small style="opacity:.7">${e(r.sub)}</small></button>`;
  }).join('')).join('');
}
function gsGo(i){
  const r=_gsList[i]; if(!r)return;
  gsHide();
  const inp=document.getElementById('gs'); if(inp)inp.value='';
  window._q=r.term||'';
  go(r.view);
}
function gsKey(ev){
  if(ev.key==='Escape'){gsHide();return}
  if(ev.key==='Enter'&&_gsList.length){ev.preventDefault();gsGo(0)}
}
document.addEventListener('click',ev=>{if(!ev.target.closest('.top-search'))gsHide()});

// ----- MFA للأدمن والمطور (v1.68) -----
function mfaScreen(html){
  document.body.insertAdjacentHTML('beforeend',`<div id="mfaBg" class="mfa-bg"><div class="mfa-box">${html}</div></div>`);
  setTimeout(()=>document.getElementById('mfaCode')?.focus(),60);
}
function mfaClose(){const m=document.getElementById('mfaBg');if(m)m.remove()}
async function mfaSignOut(){mfaClose();try{await logout()}catch(_){location.reload()}}
async function mfaVerifyCode(factorId){
  const code=(document.getElementById('mfaCode')?.value||'').replace(/\s+/g,'');
  if(!/^\d{6}$/.test(code)){toast('اكتب الكود المكون من 6 أرقام');return}
  const{data:ch,error:e1}=await sb.auth.mfa.challenge({factorId});
  if(e1){toast('تعذر بدء التحقق: '+e1.message);return}
  const{error:e2}=await sb.auth.mfa.verify({factorId,challengeId:ch.id,code});
  if(e2){toast('الكود غلط أو منتهي، جرّب تاني');return}
  // الجهاز المتذكر (7 أيام، جهاز واحد لكل مستخدم)
  const tok=newTrustTok();
  const{error:e3}=await sb.rpc('trust_device',{p_token:tok});
  if(e3)toast('تم التحقق، بس الجهاز متفكرش: '+e3.message);
  else{try{localStorage.setItem(TRUST_KEY,tok)}catch(_){}}
  mfaClose();
  await boot();
}
async function mfaGate(){
  if(!me||!['admin','developer'].includes(me.realRole))return false;
  const{data:aal,error}=await sb.auth.mfa.getAuthenticatorAssuranceLevel();
  if(error||!aal||aal.currentLevel==='aal2')return false;
  const{data:f}=await sb.auth.mfa.listFactors();
  const verified=(f?.totp||[]).find(x=>x.status==='verified');
  if(verified){
    try{if(trustTok()&&(await sb.rpc('device_trust_status')).data===true)return false}catch(_){}
    mfaScreen(`<div class="mfa-card"><div class="mfa-ic">${ico('lockkey')}</div><h2 class="mfa-t">التحقق الثنائي</h2><p class="mfa-d">اكتب الكود المكون من 6 أرقام من تطبيق Authenticator</p><input id="mfaCode" class="mfa-code" inputmode="numeric" autocomplete="one-time-code" maxlength="8" placeholder="000000" onkeydown="if(event.key==='Enter')mfaVerifyCode('${verified.id}')"><button class="btn mfa-btn" onclick="mfaVerifyCode('${verified.id}')">تأكيد الدخول</button><button class="btn soft mfa-btn" onclick="mfaSignOut()">تسجيل الخروج</button></div>`);
    return true;
  }
  const{data:en,error:e2}=await sb.auth.mfa.enroll({factorType:'totp',friendlyName:'ERP Authenticator'});
  if(e2){toast('تعذر تفعيل MFA: '+e2.message);return true}
  mfaScreen(`<div class="mfa-card"><div class="mfa-ic">${ico('lockkey')}</div><h2 class="mfa-t">فعّل التحقق الثنائي</h2><p class="mfa-d">مطلوب لحساب الأدمن. افتح تطبيق Authenticator (Google أو Microsoft) وامسح الكود، أو اكتب المفتاح يدوياً.</p><div class="mfa-qr"><img alt="QR" src="${en.totp.qr_code}"></div><p class="mfa-key">${e(en.totp.secret)}</p><input id="mfaCode" class="mfa-code" inputmode="numeric" autocomplete="one-time-code" maxlength="8" placeholder="الكود من التطبيق" onkeydown="if(event.key==='Enter')mfaVerifyCode('${en.id}')"><button class="btn mfa-btn" onclick="mfaVerifyCode('${en.id}')">تأكيد وتفعيل</button><button class="btn soft mfa-btn" onclick="mfaSignOut()">تسجيل الخروج</button></div>`);
  return true;
}
function clearDataCache(){try{Object.keys(localStorage).filter(k=>k.startsWith('erp_cache_')).forEach(k=>localStorage.removeItem(k))}catch{}}
async function boot(){const{data:{user}}=await sb.auth.getUser();
  if(await lockGate(!!user))return;me=null;if(user){const{data,error}=await sb.from('profiles').select('*').eq('id',user.id).single();if(!error)me=data}if(me){me.realRole=me.role;me.isDev=me.role==='developer';if(me.isDev)me.role='admin'}if(me&&await mfaGate())return;if(me)await Promise.all([loadMyPermissions(),loadQuick()]);await R()}
document.addEventListener('keydown',ev=>{if(ev.key==='Escape')closeMobileNav()});
window.addEventListener('pageshow',()=>{ hideLoader(); });
window.addEventListener('unhandledrejection',()=>{ if(_loading) hideLoader(); });
window.addEventListener('error',()=>{ if(_loading) hideLoader(); });

// ERP Business V15 — compact sidebar + settings management + custom user permissions.
// Initial app boot: show the loader only while the first session/profile request is actually running.
cacheAppShell();
withLoading(()=>boot(),'جاري تشغيل النظام...','جارٍ التحقق من جلسة الدخول وتحميل الإعدادات');
document.querySelector('#globalLoader')?.classList.add('show');
sb.auth.getSession().then(boot).catch(err=>{const b=document.querySelector('#globalLoader');b?.classList.remove('show');alert(err?.message||err)});

// --- v1.28: صفحة الفروع ومراكز التكلفة (تعريف لاحق يحل محل القديم) ---
async function orgView(){
  const [B,CC]=await Promise.all([g('branches','name'),g('cost_centers','code')]);
  const activeB=B.filter(x=>x.active).length, activeC=CC.filter(x=>x.active).length;
  const items=(rows,kind)=>rows.length?rows.map(x=>`<div class="org-item"><div class="org-code">${e(x.code||'—')}</div><div class="org-main"><b>${e(x.name)}</b><small class="muted">${kind}</small></div><span class="chip ${x.active?'success':'warning'}">${x.active?'نشط':'موقوف'}</span></div>`).join(''):'<p class="muted">لا توجد بيانات بعد.</p>';
  return `${sectionHead('الفروع ومراكز التكلفة','الأبعاد التنظيمية اللي بتربط الحركات والتقارير.')}
  <div class="org-stats">
    <div class="org-stat"><span>الفروع النشطة</span><b>${activeB}</b><small>من ${B.length}</small></div>
    <div class="org-stat"><span>مراكز التكلفة النشطة</span><b>${activeC}</b><small>من ${CC.length}</small></div>
  </div>
  <div class="org-grid">
    <div class="card org-form">
      <div class="card-title"><b>فرع جديد</b><span class="muted">يظهر في الفواتير والتقارير</span></div>
      <div class="org-fields"><input id="obn" placeholder="اسم الفرع"><input id="obc" placeholder="كود الفرع"></div>
      <button class="btn" onclick="act(()=>ins('branches',{name:v('obn'),code:v('obc')}))">إضافة فرع</button>
    </div>
    <div class="card org-form">
      <div class="card-title"><b>مركز تكلفة جديد</b><span class="muted">لتتبع المصروفات حسب النشاط</span></div>
      <div class="org-fields"><input id="occ" placeholder="كود المركز"><input id="ocn" placeholder="اسم المركز"></div>
      <button class="btn soft" onclick="act(()=>ins('cost_centers',{code:v('occ'),name:v('ocn')}))">إضافة مركز تكلفة</button>
    </div>
  </div>
  <div class="org-grid">
    <div class="card"><div class="card-title"><b>الفروع</b><span class="chip info">${B.length}</span></div><div class="org-list">${items(B,'فرع')}</div></div>
    <div class="card"><div class="card-title"><b>مراكز التكلفة</b><span class="chip info">${CC.length}</span></div><div class="org-list">${items(CC,'مركز تكلفة')}</div></div>
  </div>`;
}

// --- v1.29: فواتير البيع والمشتريات (تعريف لاحق يحل محل القديم) ---
function invStatus(x){
  if(x.status==='Void')return ['ملغاة','danger'];
  if(Number(x.outstanding)<=0)return ['مدفوعة','success'];
  if(Number(x.allocated_paid)>0)return ['مدفوعة جزئياً','warning'];
  return ['آجلة','info'];
}
function invSum(k){
  const tot=(cart[k]||[]).reduce((a,l)=>a+l.qty*l.price-l.discount,0);
  const disc=Number(document.getElementById('ig')?.value||0);
  const net=Math.max(0,tot-disc);
  const paid=Math.min(net,Math.max(0,Number(document.getElementById('ipd')?.value||0)));
  const set=(id,t)=>{const el=document.getElementById(id);if(el)el.textContent=t};
  set('invSub',fmt(tot));
  set('invNet',fmt(net));
  set('invPaid',fmt(paid));
  set('invRem',fmt(net-paid));
  set('docStatus',paid<=0?'آجلة':(paid>=net?'مدفوعة':'مدفوعة جزئياً'));
}
function invFilter(q){
  q=(q||'').trim().toLowerCase();
  document.querySelectorAll('#invBody tr').forEach(r=>{r.style.display=(!q||(r.dataset.s||'').includes(q))?'':'none'});
}
// --- v1.32: شاشة فاتورة بشكل المستند (زي البرنامج المكتبي): هيدر، جدول بنود قابل للتعديل، إجماليات، أزرار ---
// --- v1.33: اختيار العميل/المورد بالبحث (زي خانة الصنف) ---
window.ixParty=window.ixParty||{};
function getWho(k){return k==='s'?C.customers:C.suppliers}
function partySelHtml(k,x){return `<div class="pk-chip"><div><b>${e(x.name)}</b><small>${e(x.phone||'بدون رقم هاتف')}</small></div><button type="button" class="pk-x" title="تغيير" onclick="partyClear('${k}')">×</button></div>`}
function partyHtml(k){
  const sel=getWho(k).find(x=>x.id===window.ixParty[k]);
  return `<div class="df df-party"><span>${k==='s'?'العميل':'المورد'}</span><div class="pk">
    <input type="hidden" id="ip" value="${sel?sel.id:''}">
    <input id="pkQ" type="search" placeholder="ابحث بالاسم أو رقم الهاتف، واضغط Enter" autocomplete="off" style="${sel?'display:none':''}" oninput="partySearch('${k}',this.value)" onkeydown="if(event.key==='Enter'){event.preventDefault();partyPickFirst('${k}')}">
    <div id="pkRes" class="doc-res"></div>
    <div id="pkSel" style="${sel?'':'display:none'}">${sel?partySelHtml(k,sel):''}</div>
  </div></div>`;
}
function partySearch(k,q){
  const box=document.getElementById('pkRes');if(!box)return;
  q=(q||'').trim().toLowerCase();
  if(!q){box.innerHTML='';return}
  const list=getWho(k).filter(x=>[e(x.name),e(x.phone)].join(' ').toLowerCase().includes(q)).slice(0,8);
  box.innerHTML=list.length?list.map(x=>`<button type="button" class="doc-res-item" onclick="partyPick('${k}','${x.id}')"><b>${e(x.name)}</b><small>${e(x.phone||'بدون رقم هاتف')}</small></button>`).join(''):`<div class="doc-res-empty">لا يوجد ${k==='s'?'عميل':'مورد'} بهذا الاسم أو الرقم</div>`;
}
function partyPickFirst(k){const b=document.querySelector('#pkRes .doc-res-item');if(b)b.click()}
function partyPick(k,id){
  const x=getWho(k).find(r=>r.id===id);if(!x)return;
  window.ixParty[k]=id;
  document.getElementById('ip').value=id;
  document.getElementById('pkQ').style.display='none';
  document.getElementById('pkQ').value='';
  document.getElementById('pkRes').innerHTML='';
  const s=document.getElementById('pkSel');s.innerHTML=partySelHtml(k,x);s.style.display='';
}
function stPick(id){const cu=v('sk')==='c',x=(cu?C.customers:C.suppliers).find(r=>r.id===id);if(!x)return;window._stp=id;const sel=document.getElementById('stSel');if(sel)sel.textContent=x.name;const box=document.getElementById('stRes');if(box)box.innerHTML='';const q=document.getElementById('sq2');if(q)q.value=''}
function partyClear(k){
  window.ixParty[k]=null;
  document.getElementById('ip').value='';
  const s=document.getElementById('pkSel');s.innerHTML='';s.style.display='none';
  const q=document.getElementById('pkQ');q.style.display='';q.value='';q.focus();
}
async function invSave(s){
  if(!v('ip'))throw Error(s?'اختار العميل أولاً':'اختار المورد أولاً');
  return saveInvoice(s);
}
function invSearch(k,q){
  const box=document.getElementById('invRes');if(!box)return;
  q=(q||'').trim().toLowerCase();
  if(!q){box.innerHTML='';return}
  const list=C.products.filter(p=>p.active&&[p.name,p.code,p.barcode].join(' ').toLowerCase().includes(q)).slice(0,8);
  box.innerHTML=list.length?list.map(p=>`<button type="button" class="doc-res-item" onclick="invPick('${k}','${p.id}')"><b>${e(p.name)}</b><small>${e(p.code||'بدون كود')} · السعر ${fmt(k==='s'?p.sale_price:p.purchase_price)} · مخزون ${v('iw')?stkQtyWh(p.id,v('iw')):stkQty(p.id)}</small></button>`).join(''):'<div class="doc-res-empty">لا توجد أصناف مطابقة</div>';
}
function invPickFirst(k){const b=document.querySelector('#invRes .doc-res-item');if(b)b.click()}
function invPick(k,id){
  const p=by(C.products,id);if(!p.id)return;
  const same=(cart[k]||[]).find(l=>l.product_id===p.id);
  if(same)same.qty=+same.qty+1;
  else cart[k].push({product_id:p.id,qty:1,price:+(k==='s'?p.sale_price:p.purchase_price)||0,discount:0});
  const q=document.getElementById('invQ');if(q){q.value='';q.focus()}
  document.getElementById('invRes').innerHTML='';
  invRedraw(k);
}
function invRowsHtml(k){
  const cr=cart[k]||[];
  if(!cr.length)return '<tr class="doc-empty"><td colspan="7">ابحث عن صنف فوق وهيتضاف هنا. تقدر تعدّل الكمية والسعر والخصم في نفس السطر.</td></tr>';
  return cr.map((l,i)=>{const p=by(C.products,l.product_id);return `<tr>
    <td class="c-n" data-label="#">${i+1}</td>
    <td data-label="الصنف"><b>${e(p.name||'—')}</b><small>${e(p.code||'')}</small></td>
    <td class="c-q" data-label="الكمية"><input type="number" value="${l.qty}" inputmode="decimal" onchange="invSet('${k}',${i},'qty',this.value)"></td>
    <td class="c-p" data-label="السعر"><input type="number" value="${l.price}" inputmode="decimal" onchange="invSet('${k}',${i},'price',this.value)"></td>
    <td class="c-d" data-label="الخصم"><input type="number" value="${l.discount}" inputmode="decimal" onchange="invSet('${k}',${i},'discount',this.value)"></td>
    <td class="c-t" data-label="الإجمالي" id="lt${i}">${fmt(l.qty*l.price-l.discount)}</td>
    <td class="c-x"><button type="button" class="doc-del" title="حذف" onclick="invDel('${k}',${i})">×</button></td></tr>`}).join('');
}
function invRedraw(k){
  const b=document.getElementById('invRows');if(b)b.innerHTML=invRowsHtml(k);
  const c=document.getElementById('invCnt');if(c)c.textContent=(cart[k]||[]).length+' بند';
  invSum(k);
}
function invSet(k,i,f,val){
  const l=cart[k][i];if(!l)return;
  const x=Number(val);
  if(f==='qty'){if(!(x>0)){invRedraw(k);return}l.qty=x}
  else if(f==='price'){if(!(x>=0)){invRedraw(k);return}l.price=x}
  else{l.discount=x>=0&&!isNaN(x)?x:0}
  const t=document.getElementById('lt'+i);if(t)t.textContent=fmt(l.qty*l.price-l.discount);
  invSum(k);
}
function invDel(k,i){cart[k].splice(i,1);invRedraw(k)}
function invNew(k){cart[k]=[];window._editInv=null;R('soft')}
function showModal(html){closeModal();const d=document.createElement('div');d.id='modalBg';d.className='modal-bg';d.onclick=ev=>{if(ev.target===d)closeModal()};d.innerHTML=`<div class="modal-box" role="dialog">${html}<div class="modal-actions"><button class="btn soft" onclick="trPrint()">طباعة</button><button class="btn s" onclick="closeModal()">إغلاق</button></div></div>`;document.body.appendChild(d)}
function closeModal(){const m=document.getElementById('modalBg');if(m)m.remove();window._trDet=null}
function trPrint(){const box=document.querySelector('#modalBg .tr-detail');if(!box)return;const c=box.cloneNode(true);c.querySelectorAll('button').forEach(b=>b.remove());const w=window.open('','_blank');if(!w)return alert('اسمح بالنوافذ المنبثقة للطباعة');w.document.write('<!doctype html><html dir="rtl" lang="ar"><head><meta charset="utf-8"><title>تفاصيل التحويل</title><style>body{font-family:Tahoma,Arial;padding:24px}table{border-collapse:collapse;width:100%;margin:8px 0}td,th{border:1px solid #8C97A6;padding:6px 8px;text-align:right}th{background:#F3F1E8}h3{margin:14px 0 6px}</style></head><body>'+c.innerHTML+'<script>window.onload=()=>window.print()<\/script></body></html>');w.document.close()}
async function invEdit(id){const{data:inv,error}=await sb.from('sales_invoices').select('*').eq('id',id).single();if(error)return alert(error.message);const{data:its,error:e2}=await sb.from('sales_invoice_items').select('*').eq('invoice_id',id);if(e2)return alert(e2.message);cart.s=(its||[]).map(x=>({product_id:x.product_id,qty:Number(x.qty),price:Number(x.unit_price),discount:Number(x.discount||0)}));window._editInv={id,number:inv.number};window.ixMode=window.ixMode||{};window.ixMode.s='new';await R('soft');const a=document.getElementById('ip'),b=document.getElementById('iw'),d=document.getElementById('ig');if(a)a.value=inv.customer_id;if(b)b.value=inv.warehouse_id;if(d)d.value=Number(inv.discount||0)}

async function invoiceFormView(s){
  const k=s?'s':'p', cr=cart[k]||[];
  const who=s?C.customers:C.suppliers;
  const L=await g(s?'sales_invoice_balances':'purchase_invoice_balances','date');
  const finance=me&&(me.role==='admin'||me.role==='accountant');
  const tot=cr.reduce((a,l)=>a+l.qty*l.price-l.discount,0);
  const today=new Date().toISOString().slice(0,10);
  const payFields=finance
    ?`<label class="df">المدفوع<input id="ipd" type="number" value="0" inputmode="decimal" oninput="invSum('${k}')"></label>
      <label class="df">الحساب المالي<select id="ia"><option value="">—</option>${O(C.accts)}</select></label>
      <label class="df">طريقة الدفع<select id="im"><option value="credit">آجل / جزء آجل</option><option value="cash">نقدي</option><option value="bank">بنك</option><option value="wallet">محفظة</option></select></label>`
    :`<div class="df wide"><span>ملاحظة</span><b class="note">الفاتورة تُحفظ آجلة على الحساب، والدفع المباشر غير متاح لهذا الدور.</b></div><input type="hidden" id="ipd" value="0"><input type="hidden" id="im" value="credit"><input type="hidden" id="ia" value="">`;
  const rows=L.slice().reverse().map(x=>{
    const party=(by(who,s?x.customer_id:x.supplier_id).name)||'—';
    const [st,cls]=invStatus(x);
    return `<tr data-s="${e((x.number+' '+party).toLowerCase())}"><td><b>${e(x.number)}</b></td><td>${e(x.date||'')}</td><td>${e(party)}</td><td>${fmt(x.total)}</td><td>${fmt(x.allocated_paid)}</td><td>${fmt(x.outstanding)}</td><td><span class="chip ${cls}">${st}</span></td><td><button class="btn soft sm" onclick="printInvoice('${x.id}',${s})">طباعة</button><button class="btn soft sm" onclick="shareWhats('${x.id}',${s})">واتساب</button>${s&&isAdminRole()&&x.status!=='Void'?` <button class="btn soft sm" onclick="invEdit('${x.id}')">تعديل</button>`:''}</td></tr>`;
  }).join('');
  return `<div class="doc">
    <div class="doc-toolbar">
      <div class="doc-title"><b>${s?'فاتورة بيع':'فاتورة شراء'}</b><span>رقم يتولد عند الحفظ</span></div>
      <div class="doc-actions">
        <button type="button" class="doc-btn primary" onclick="act(()=>invSave(${s?'true':'false'}))">حفظ</button>
        <button type="button" class="doc-btn" onclick="invNew('${k}')">فاتورة جديدة</button>
        <button type="button" class="doc-btn" onclick="R('soft')">تحديث</button>
        <button type="button" class="doc-btn" onclick="go('dash')">إغلاق</button>
      </div>
    </div>
    <div class="doc-head">
      ${partyHtml(k)}
      <label class="df">المخزن<select id="iw">${O(C.warehouses)}</select></label>
      <div class="df"><span>التاريخ</span><b>${today}</b></div>
      <div class="df"><span>الحالة</span><b id="docStatus">آجلة</b></div>
      ${payFields}
    </div>
    <div class="doc-add">
      <div class="doc-search">
        <div class="doc-search-row"><input id="invQ" type="search" placeholder="ابحث عن صنف بالاسم أو الكود أو الباركود، واضغط Enter" autocomplete="off" oninput="invSearch('${k}',this.value)" onkeydown="if(event.key==='Enter'){event.preventDefault();invPickFirst('${k}')}"><button type="button" class="btn soft" onclick="scanBarcode('invQ','${k}')" title="مسح باركود بالكاميرا">${ico('camera')} مسح</button></div>
        <div id="invRes" class="doc-res"></div>
      </div>
    </div>
    <div class="doc-grid-wrap">
      <table class="doc-tbl">
        <thead><tr><th class="c-n">#</th><th>الصنف</th><th class="c-q">الكمية</th><th class="c-p">السعر</th><th class="c-d">الخصم</th><th class="c-t">الإجمالي</th><th class="c-x"></th></tr></thead>
        <tbody id="invRows">${invRowsHtml(k)}</tbody>
      </table>
    </div>
    <div class="doc-foot">
      <span class="doc-count" id="invCnt">${cr.length} بند</span>
      <div class="doc-totals">
        <div class="tl"><span>المجموع</span><b id="invSub">${fmt(tot)}</b></div>
        <div class="tl"><span>خصم كلي</span><input id="ig" type="number" value="0" inputmode="decimal" oninput="invSum('${k}')"></div>
        <div class="tl"><span>الصافي</span><b id="invNet">${fmt(tot)}</b></div>
        <div class="tl"><span>المدفوع</span><b id="invPaid">${fmt(0)}</b></div>
        <div class="tl big"><span>المتبقي</span><b id="invRem">${fmt(tot)}</b></div>
      </div>
    </div>
  </div>
`;
}

// --- v1.36: قائمة المبيعات/المشتريات: إنشاء فاتورة / الفواتير السابقة / المستحقة ---
window.ixMode=window.ixMode||{};
function ixSetMode(k,m){window.ixMode=window.ixMode||{};window.ixMode[k]=m;R('soft')}
function ixBar(k,label,title){return `<div class="ix-bar"><button type="button" class="ix-back" onclick="ixSetMode('${k}','hub')">→ ${title}</button><span>${label}</span></div>`}
function ixHub(k,s,L){
  const due=L.filter(x=>Number(x.outstanding)>0);
  const dueSum=due.reduce((a,x)=>a+Number(x.outstanding||0),0);
  const tile=(cls,mode,ico,t,sub)=>`<button type="button" class="ix-tile ${cls}" onclick="ixSetMode('${k}','${mode}')"><span class="ix-ico">${ico}</span><b>${t}</b><small>${sub}</small></button>`;
  return `<div class="ix-hub">
    ${tile('new','new','+','إنشاء فاتورة جديدة',s?'فاتورة بيع بأصناف ودفع':'فاتورة شراء بأصناف ودفع')}
    ${tile('','list','≡','الفواتير السابقة',`${L.length} فاتورة · ابحث بالرقم أو الاسم أو التاريخ`)}
    ${tile('','due','!','الفواتير المستحقة',`${due.length} فاتورة · متبقي ${fmt(dueSum)}`)}
  </div>`;
}
function ixListCard(k,s,L,mode){
  const who=getWho(k);
  const list=L.slice().reverse().filter(x=>mode==='list'||Number(x.outstanding)>0);
  const rows=list.map(x=>{
    const party=(by(who,s?x.customer_id:x.supplier_id).name)||'—';
    const [st,cls]=invStatus(x);
    return `<tr data-s="${e((x.number+' '+party+' '+(x.date||'')).toLowerCase())}"><td><b>${e(x.number)}</b></td><td>${e(x.date||'')}</td><td>${e(party)}</td><td>${fmt(x.total)}</td><td>${fmt(x.allocated_paid)}</td><td>${fmt(x.outstanding)}</td><td><span class="chip ${cls}">${st}</span></td><td><button class="btn soft sm" onclick="printInvoice('${x.id}',${s})">طباعة</button><button class="btn soft sm" onclick="shareWhats('${x.id}',${s})">واتساب</button>${s&&isAdminRole()&&x.status!=='Void'?` <button class="btn soft sm" onclick="invEdit('${x.id}')">تعديل</button>`:''}</td></tr>`;
  }).join('');
  return `<div class="card ix-list">
    <div class="ix-list-head"><div><b>${mode==='list'?'كل الفواتير':'الفواتير المستحقة'}</b><small>${list.length} فاتورة</small></div>
      <input class="inv-search" type="search" placeholder="ابحث بالرقم أو الاسم أو التاريخ" oninput="invFilter(this.value)"></div>
    <div class="table-wrap"><table class="inv-table"><thead><tr><th>الرقم</th><th>التاريخ</th><th>${s?'العميل':'المورد'}</th><th>الإجمالي</th><th>المدفوع</th><th>المتبقي</th><th>الحالة</th><th></th></tr></thead><tbody id="invBody">${rows||'<tr><td colspan="8" class="muted">لا توجد نتائج</td></tr>'}</tbody></table></div>
  </div>`;
}
async function invoiceView(s){
  const k=s?'s':'p', mode=(window.ixMode||{})[k]||'hub', title=s?'المبيعات':'المشتريات';
  if(mode==='new') return ixBar(k,window._editInv?'تعديل فاتورة '+window._editInv.number:'إنشاء فاتورة جديدة',title)+(window._editInv?`<div class="card np edit-banner"><span>التعديل هيلغي الفاتورة الأصلية <b>${e(window._editInv.number)}</b> ويعمل فاتورة جديدة بالبيانات المعدّلة.</span><button class="btn s" onclick="window._editInv=null;cart.s=[];R('soft')">إلغاء التعديل</button></div>`:'')+await invoiceFormView(s);
  const L=await g(s?'sales_invoice_balances':'purchase_invoice_balances','date');
  if(mode==='list'||mode==='due') return ixBar(k,mode==='list'?'الفواتير السابقة':'الفواتير المستحقة',title)+ixListCard(k,s,L,mode);
  return sectionHead(title,'اختار: فاتورة جديدة، أو الفواتير السابقة، أو المستحقات.')+ixHub(k,s,L);
}
function waPhone(p){let d=String(p||'').replace(/\D/g,'');if(!d)return '';if(d.startsWith('00'))d=d.slice(2);else if(d.startsWith('0'))d='20'+d.slice(1);return d}
async function shareWhats(id,s){
  const w=window.open('','_blank');
  try{
    const tbl=s?'sales':'purchase';
    const [hdr,bal,co]=await Promise.all([
      sb.from(tbl+'_invoices').select('*').eq('id',id).single().then(r=>{if(r.error)throw r.error;return r.data}),
      sb.from(tbl+'_invoice_balances').select('*').eq('id',id).single().then(r=>{if(r.error)throw r.error;return r.data}),
      g('company_settings').then(x=>x[0]||{})
    ]);
    const who=s?C.customers:C.suppliers;
    const party=by(who,s?hdr.customer_id:hdr.supplier_id)||{};
    const [st]=invStatus(bal);
    const lines=[
      `*${co.company_name||'فاتورة'}*`,
      `${s?'فاتورة بيع':'فاتورة شراء'} رقم: ${hdr.number}`,
      `التاريخ: ${hdr.date||''}`,
      `الإجمالي: ${Number(hdr.total||0).toFixed(2)} ج.م`,
      Number(bal.outstanding||0)>0?`المتبقي: ${Number(bal.outstanding).toFixed(2)} ج.م`:'تم السداد بالكامل',
      `الحالة: ${st}`,
      '',
      'شكراً لتعاملكم معنا'
    ];
    const text=lines.join('\n');
    const phone=waPhone(party.phone);
    const url='https://wa.me/'+(phone||'')+'?text='+encodeURIComponent(text);
    try{await navigator.clipboard.writeText(text)}catch(_){}
    if(w){w.location.href=url}else{window.open(url,'_blank')}
    toast(phone?'فتح واتساب بالفاتورة':'الفاتورة اتنسخت — مفيش رقم موبايل للعميل، اختار الجهة من واتساب');
  }catch(err){if(w)w.close();toast('تعذر تجهيز الرابط: '+(err.message||err))}
}

/* ---- v1.84: barcode scan via camera (BarcodeDetector) ---- */
let _scanStream=null,_scanTimer=null;
function stopScan(){clearInterval(_scanTimer);_scanTimer=null;if(_scanStream){_scanStream.getTracks().forEach(t=>t.stop());_scanStream=null}document.getElementById('scanBg')?.remove()}
async function scanBarcode(inputId,k){
  if(!('BarcodeDetector' in window)||!navigator.mediaDevices?.getUserMedia){toast('المتصفح ده مش بيدعم مسح الباركود بالكاميرا — اكتب الباركود يدوياً أو استخدم Chrome على أندرويد');return}
  let det;try{det=new BarcodeDetector({formats:['ean_13','ean_8','code_128','code_39','upc_a','upc_e','qr_code']})}catch(_){toast('تعذر تشغيل الماسح');return}
  stopScan();
  const bg=document.createElement('div');bg.id='scanBg';bg.className='scan-bg';
  bg.innerHTML=`<div class="scan-box"><div class="scan-head"><b>وجّه الكاميرا على الباركود</b><button class="btn soft sm" id="scanX">إغلاق</button></div><video id="scanVid" playsinline muted></video><div class="muted" id="scanMsg">جاري تشغيل الكاميرا...</div></div>`;
  document.body.appendChild(bg);
  document.getElementById('scanX').onclick=stopScan;
  try{
    _scanStream=await navigator.mediaDevices.getUserMedia({video:{facingMode:{ideal:'environment'}},audio:false});
    const vid=document.getElementById('scanVid');vid.srcObject=_scanStream;await vid.play();
    document.getElementById('scanMsg').textContent='جاري البحث عن الباركود...';
    _scanTimer=setInterval(async()=>{
      try{
        const codes=await det.detect(vid);
        if(codes&&codes.length){
          const val=codes[0].rawValue;
          stopScan();
          const inp=document.getElementById(inputId);
          if(inp){inp.value=val;inp.dispatchEvent(new Event('input',{bubbles:true}));if(k)invPickFirst(k)}
          toast('تم قراءة الباركود: '+val);
        }
      }catch(_){}
    },350);
  }catch(err){stopScan();toast('لم نتمكن من فتح الكاميرا — اسمح بالوصول للكاميرا من إعدادات المتصفح')}
}

/* ---- v1.84: budget vs actual per expense category ---- */
function budMonth(){return window._budM||new Date().toISOString().slice(0,7)}
async function budgetView(){
  const mo=budMonth();
  const from=mo+'-01';const d=new Date(from+'T00:00:00');d.setMonth(d.getMonth()+1);d.setDate(0);const to=d.toISOString().slice(0,10);
  const [ex,bud]=await Promise.all([
    sb.from('expenses').select('category,amount').gte('date',from).lte('date',to).then(r=>{if(r.error)throw r.error;return r.data||[]}),
    sb.from('budgets').select('*').eq('month',from).then(r=>{if(r.error)throw r.error;return r.data||[]})
  ]);
  const act={};ex.forEach(x=>{const c=x.category||'بدون تصنيف';act[c]=(act[c]||0)+Number(x.amount||0)});
  const bm={};bud.forEach(b=>bm[b.category]=b);
  const cats=[...new Set([...Object.keys(act),...Object.keys(bm)])].sort();
  const totB=bud.reduce((a,b)=>a+Number(b.amount||0),0), totA=Object.values(act).reduce((a,x)=>a+x,0);
  const rows=cats.map(c=>{const b=Number(bm[c]?.amount||0),a=act[c]||0,diff=b-a,pct=b?Math.round(a/b*100):null;
    const st=!b?'<span class="chip">بدون موازنة</span>':a>b?'<span class="chip danger">تجاوز</span>':pct>=80?'<span class="chip warning">قرب الحد</span>':'<span class="chip success">ضمن الموازنة</span>';
    return [e(c),money(b),money(a),money(diff),pct===null?'—':pct+'%',st,bm[c]?`<button class="btn soft sm" onclick="budDel('${bm[c].id}')">حذف</button>`:'']});
  const dl=[...new Set(ex.map(x=>x.category).filter(Boolean))].map(c=>`<option value="${e(c)}">`).join('');
  return `${sectionHead('الموازنة والفعلي','قارن الموازنة المعتمدة بالمصروفات الفعلية لكل تصنيف في الشهر.')}
  <div class="card form-card"><div class="row"><label class="fm-f"><span>الشهر</span><input type="month" id="budM" value="${mo}" onchange="window._budM=this.value;R()"></label>
  <label class="fm-f"><span>التصنيف</span><input id="budC" list="budCL" placeholder="مثال: إيجار"><datalist id="budCL">${dl}</datalist></label>
  <label class="fm-f"><span>الموازنة (ج.م)</span><input id="budA" type="number" min="0" step="0.01" placeholder="0"></label>
  <button class="btn primary" onclick="budSave()">حفظ الموازنة</button></div></div>
  <div class="card"><div class="card-title"><b>الإجمالي</b><span class="muted">موازنة ${fmt(totB)} — فعلي ${fmt(totA)}</span></div>${cats.length?T(['التصنيف','الموازنة','الفعلي','المتبقي','نسبة الصرف','الحالة',''],rows):'<div class="empty">لا توجد موازنات ولا مصروفات لهذا الشهر.</div>'}</div>`;
}
async function budSave(){
  const c=v('budC').trim(),a=Number(v('budA'));const mo=budMonth()+'-01';
  if(!c||!(a>=0)){toast('اكتب التصنيف والمبلغ');return}
  return act(async()=>{const{error}=await sb.from('budgets').upsert({month:mo,category:c,amount:a},{onConflict:'month,category'});if(error)throw error})
}
async function budDel(id){return act(async()=>{const{error}=await sb.from('budgets').delete().eq('id',id);if(error)throw error})}

async function printInvoice(id,s){
  const w=window.open('','_blank');
  if(!w){toast('اسمح بالنوافذ المنبثقة عشان تطبع');return}
  w.document.write('<p style="font-family:sans-serif;padding:20px">جاري تجهيز الفاتورة...</p>');
  try{
    const tbl=s?'sales':'purchase';
    const [hdr,bal,items,co]=await Promise.all([
      sb.from(tbl+'_invoices').select('*').eq('id',id).single().then(r=>{if(r.error)throw r.error;return r.data}),
      sb.from(tbl+'_invoice_balances').select('*').eq('id',id).single().then(r=>{if(r.error)throw r.error;return r.data}),
      sb.from(tbl+'_invoice_items').select('qty,unit_price,discount,line_total,products(name)').eq('invoice_id',id).then(r=>{if(r.error)throw r.error;return r.data||[]}),
      g('company_settings').then(x=>x[0]||{})
    ]);
    const who=s?C.customers:C.suppliers;
    const party=(by(who,s?hdr.customer_id:hdr.supplier_id).name)||'—';
    const [st]=invStatus(bal);
    const rowsHtml=items.map((it,i)=>`<tr><td>${i+1}</td><td>${e(it.products?.name||'')}</td><td>${it.qty}</td><td>${fmt(it.unit_price)}</td><td>${fmt(it.discount)}</td><td>${fmt(it.line_total)}</td></tr>`).join('');
    const pc=printCfg();
    const logo=pc.showLogo&&co.logo_url?`<img src="${e(co.logo_url)}" alt="" class="logo" style="max-height:${pc.logoMaxH}px">`:'';
    const html=`<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><title>${e(hdr.number)}</title><style>
      @page{size:${pc.paperSize};margin:${pc.marginMm}mm}
      body{font-family:'Segoe UI',Tahoma,Arial,sans-serif;color:#101C2C;margin:0;font-size:${pc.fontPx}px}
      .head{display:flex;justify-content:${pcJustify(pc)};align-items:flex-start;border-bottom:3px solid ${pc.accent};padding-bottom:14px}
      .logo{max-height:56px;margin-bottom:6px}
      .co b{font-size:18px}.co small{display:block;color:#3A4657;line-height:1.7}
      .meta{text-align:left}.meta h1{margin:0;font-size:22px;color:${pc.accent}}.meta div{color:#3A4657;margin-top:4px}
      .parties{display:flex;justify-content:space-between;margin:18px 0;gap:16px}
      .box{flex:1;background:#F3F1E8;border:1px solid #E3E0D4;border-radius:10px;padding:12px}
      .box h4{margin:0 0 6px;color:#5B6878;font-size:12px}
      table{width:100%;border-collapse:collapse;margin-top:6px}
      th{background:#E6F5F0;color:${pc.accent};padding:9px;text-align:right;font-size:12px}
      td{padding:9px;border-bottom:1px solid #E3E0D4}
      .totals{margin-top:14px;margin-right:auto;width:280px}
      .totals div{display:flex;justify-content:space-between;padding:6px 0;border-bottom:1px dashed #D6D2C4}
      .totals .grand{font-size:16px;font-weight:800;border-bottom:2px solid ${pc.accent};color:${pc.accent}}
      .notes{margin-top:18px;color:#3A4657;white-space:pre-line}
      .sign{display:flex;justify-content:space-between;margin-top:46px;color:#5B6878}
      .sign div{border-top:1px solid #8C97A6;width:200px;text-align:center;padding-top:6px}
    .inv-stats{margin-bottom:14px}
.inv-layout{display:grid;grid-template-columns:minmax(0,1fr) 280px;gap:14px;align-items:start;margin-bottom:14px}
@media (max-width:900px){.inv-layout{grid-template-columns:1fr}}
.inv-fields,.inv-add{display:grid;gap:10px;margin:10px 0}
.inv-fields{grid-template-columns:repeat(auto-fit,minmax(200px,1fr))}
.inv-add{grid-template-columns:minmax(180px,2fr) repeat(3,minmax(90px,1fr)) auto;align-items:end}
.inv-add .grow{min-width:0}
@media (max-width:900px){.inv-add{grid-template-columns:1fr 1fr}}
.inv-add label,.inv-fields label,.inv-pay label{display:flex;flex-direction:column;gap:6px;font-size:12px;color:#5B6878;font-weight:700}
.inv-pay{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:10px;margin:12px 0}
.inv-actions{display:flex;justify-content:flex-start;margin-top:12px}
.inv-empty{padding:12px 0}
.inv-summary{position:sticky;top:80px}
.inv-line{display:flex;justify-content:space-between;padding:12px 0;border-bottom:1px solid #F3F1E8}
.inv-line span{color:#5B6878}
.inv-note{font-size:12px;margin-top:12px}
.inv-search{max-width:260px}
.table-wrap{overflow-x:auto}
.inv-table{width:100%;border-collapse:collapse}
.inv-table th{background:#F3F1E8;color:#5B6878;font-size:12px;text-align:right;padding:10px}
</style></head><body>
      <div class="head">
        <div class="co">${logo}${pc.showName?`<b>${e(co.company_name||'')}</b>`:''}<small>${e(co.address||'')}${co.phone?'<br>هاتف: '+e(co.phone):''}${co.tax_number?'<br>الرقم الضريبي: '+e(co.tax_number):''}</small></div>
        <div class="meta"><h1>${s?'فاتورة بيع':'فاتورة شراء'}</h1><div>رقم: <b>${e(hdr.number)}</b></div><div>التاريخ: ${e(hdr.date||'')}</div>${hdr.due_date?'<div>الاستحقاق: '+e(hdr.due_date)+'</div>':''}<div>الحالة: ${st}</div></div>
      </div>
      <div class="parties"><div class="box"><h4>${s?'العميل':'المورد'}</h4><b>${e(party)}</b></div></div>
      <table><thead><tr><th>#</th><th>الصنف</th><th>الكمية</th><th>السعر</th><th>الخصم</th><th>الإجمالي</th></tr></thead><tbody>${rowsHtml}</tbody></table>
      <div class="totals">
        <div><span>المجموع الفرعي</span><b>${fmt(bal.subtotal)}</b></div>
        <div><span>الخصم</span><b>${fmt(bal.discount)}</b></div>
        <div><span>الضريبة</span><b>${fmt(bal.tax)}</b></div>
        <div class="grand"><span>الإجمالي</span><b>${fmt(bal.total)}</b></div>
        <div><span>المدفوع</span><b>${fmt(bal.allocated_paid)}</b></div>
        <div><span>المتبقي</span><b>${fmt(bal.outstanding)}</b></div>
      </div>
      ${pc.showNotes&&hdr.notes?'<div class="notes"><b>ملاحظات:</b>\n'+e(hdr.notes)+'</div>':''}
      ${pc.showSignatures?'<div class="sign"><div>توقيع المستلم</div><div>توقيع المسؤول</div></div>':''}
      ${vendorCreditHtml()}
    <script>window.onload=function(){setTimeout(function(){window.print()},200)}<\/script></body></html>`;
    w.document.open(); w.document.write(html); w.document.close();
  }catch(x){
    w.document.open(); w.document.write('<p style="font-family:sans-serif;padding:20px">تعذر تحميل الفاتورة: '+e(x.message||x)+'</p>'); w.document.close();
  }
}

/* =====================================================================
   v1.45 — تعريفات لاحقة تحل محل القديم (نفس الاسم: الأخيرة هي اللي تسري)
   ===================================================================== */

// ---------- أدوات مشتركة: أقسام داخل الصفحة ----------
window._sec=window._sec||{};
function secCur(key,def){return (window._sec&&window._sec[key])||def}
function secSet(key,id,el){window._sec=window._sec||{};window._sec[key]=id;if(el){el.parentElement?.querySelectorAll('.sec-btn').forEach(b=>b.classList.toggle('on',b===el))}R('soft')}
function secBar(key,tabs,def){const cur=secCur(key,def);return `<div class="sec-bar">${tabs.map(([id,l])=>`<button type="button" class="sec-btn${cur===id?' on':''}" onclick="secSet('${key}','${id}',this)">${l}</button>`).join('')}</div>`}

// ---------- أدوات مشتركة: اختيار يوم (اليوم مفتوح، والأيام السابقة مقفولة) ----------
window._dy=window._dy||{};
function dyGet(key){return (window._dy&&window._dy[key])||cday(new Date())}
function dySet(key,d){window._dy=window._dy||{};const t=cday(new Date());window._dy[key]=(!d||d===t)?null:d;R('soft')}
function dayStrip(key,day,meta){
  const today=cday(new Date());
  const btns=[...Array(14)].map((_,i)=>cday(new Date(Date.now()-i*86400000))).map(d=>{
    const lbl=new Date(d+'T12:00:00Z').toLocaleDateString(locOf(),{weekday:'long',day:'numeric',month:'long',timeZone:'Africa/Cairo'});
    const m=meta?meta(d):'';
    return `<button type="button" class="day-btn${d===day?' on':''}" onclick="dySet('${key}','${d}')"><b>${lbl}</b><small>${d===today?'اليوم · مفتوح':'مقفول'}${m?' · '+m:''}</small></button>`;
  }).join('');
  return `<div class="card"><div class="card-title"><b>اختر يوم</b><div class="row"><input type="date" value="${day}" onchange="dySet('${key}',this.value)">${day!==today?`<button class="s" onclick="dySet('${key}','')">اليوم</button>`:''}</div></div><div class="day-strip">${btns}</div><p class="muted">اليوم الحالي مفتوح ويتسجل فيه. أي يوم قبله مقفول: للعرض والطباعة فقط.</p></div>`;
}

// ---------- أدوات مشتركة: الطباعة ----------
function printHtml(title,body){
  const w=window.open('','_blank');
  if(!w){toast('اسمح بالنوافذ المنبثقة عشان تطبع');return null}
  w.document.open();
  w.document.write(`<!doctype html><html dir="rtl" lang="ar"><head><meta charset="utf-8"><title>${e(title)}</title><style>@page{size:A4;margin:12mm}body{font-family:'Segoe UI',Tahoma,Arial,sans-serif;color:#101C2C;margin:0;font-size:13px}h2{margin:0 0 8px;color:#095F4A}h3{margin:14px 0 6px}.muted{color:#5B6878}table{width:100%;border-collapse:collapse;margin:8px 0}th{background:#E6F5F0;color:#095F4A;padding:7px;text-align:right;font-size:12px}td{padding:7px;border-bottom:1px solid #E3E0D4;text-align:right}.tot{font-weight:800;border-top:2px solid #095F4A;padding-top:6px}.bad{color:#B93A2F}.good{color:#16834B}.chip{display:inline-block;padding:2px 8px;border-radius:99px;border:1px solid #8C97A6}</style></head><body>${body}<script>window.onload=function(){setTimeout(function(){window.print()},200)}<\/script></body></html>`);
  w.document.close();
  return w;
}
function modalPrint(title){
  const box=document.querySelector('#modalBg .modal-box');if(!box)return;
  const c=box.cloneNode(true);
  c.querySelectorAll('.modal-actions,button,input,select,textarea').forEach(x=>x.remove());
  printHtml(title||'طباعة',c.innerHTML);
}
// جداول قابلة للطباعة: تُخزَّن أولًا ثم تُطبع بزر واحد
window._PT=window._PT||{};
function ptStore(key,title,sub,headers,rows,foot){window._PT[key]={title,sub:sub||'',headers,rows,foot:foot||''}}
function ptPrint(key){
  const d=window._PT&&window._PT[key];if(!d)return toast('لا توجد بيانات للطباعة');
  const body=`<h2>${e(d.title)}</h2>${d.sub?`<p class="muted">${d.sub}</p>`:''}<table><thead><tr>${d.headers.map(h=>`<th>${e(h)}</th>`).join('')}</tr></thead><tbody>${d.rows.map(r=>`<tr>${r.map(c=>`<td>${c}</td>`).join('')}</tr>`).join('')||'<tr><td colspan="99">لا توجد حركات في هذا اليوم</td></tr>'}</tbody></table>${d.foot}`;
  printHtml(d.title,body);
}
// طباعة جدول قائمة (lsCard) بالكامل بمفتاحه
function ptPrintLS(key,title,sub){
  const d=window._LS&&window._LS[key];if(!d)return toast('لا توجد بيانات للطباعة');
  ptStore('__ls_'+key,title,sub,d.headers,d.rows);
  ptPrint('__ls_'+key);
}

// ---------- أدوات مشتركة: نوافذ منبثقة ----------
function showModal(html,footer,wide){
  closeModal();
  const d=document.createElement('div');d.id='modalBg';d.className='modal-bg';
  d.onclick=ev=>{if(ev.target===d)closeModal()};
  d.innerHTML=`<div class="modal-box${wide?' wide':''}" role="dialog">${html}<div class="modal-actions">${footer||''}<button class="btn s" onclick="closeModal()">إغلاق</button></div></div>`;
  document.body.appendChild(d);
}
function closeModal(){const m=document.getElementById('modalBg');if(m)m.remove();window._trDet=null;window._fmSave=null}
// نافذة نموذج: تعديل/إضافة. الحفظ يمر بـ act (يعرض الخطأ ويعيد الرسم) ثم يقفل النافذة عند النجاح
function formModal(title,fields,save,label){
  showModal(`<div class="card-title"><b>${title}</b></div><div class="fm-grid">${fields}</div>`,`<button class="btn" onclick="fmSave()">${e(label)||'حفظ'}</button>`);
  window._fmSave=save;
}
function fmSave(){const f=window._fmSave;if(!f)return;act(async()=>{await f();closeModal()})}
async function fnCall(body){
  const{data,error}=await sb.functions.invoke('admin-create-user',{body});
  if(error){let msg=error.message;try{const j=await error.context.json();if(j&&j.error)msg=j.error}catch(_){}throw Error(msg)}
  if(data&&data.error)throw Error(data.error);
  return data;
}
function trPrint(){modalPrint('تفاصيل التحويل')}
async function trOpen(kind,id){
  const t=kind==='stk'?'stock_transfers':'cash_transfers';
  const{data,error}=await sb.from(t).select('*').eq('id',id).single();if(error)return alert(error.message);
  let items=[];if(kind==='stk'){const r=await sb.from('stock_transfer_items').select('*').eq('transfer_id',id);if(r.error)return alert(r.error.message);items=r.data||[]}
  const PN=await profNames();
  window._trDet={kind,row:data,items,by:PN[data.created_by]||'—'};
  showModal(trDetHtml(kind),`<button class="btn soft" onclick="trPrint()">طباعة</button>`);
}

// ---------- المنتجات: التعديل في نافذة ----------
function prodEdit(id){
  const p=by(C.products,id);if(!p.id)return;
  formModal('تعديل الصنف: '+e(p.name),
    `<label class="fm-f"><span>الاسم</span><input id="ep_n" value="${e(p.name)}"></label><label class="fm-f"><span>الكود</span><input id="ep_c" value="${e(p.code||'')}"></label><label class="fm-f"><span>الباركود</span><input id="ep_b" value="${e(p.barcode||'')}"></label><label class="fm-f"><span>سعر الشراء</span><input id="ep_p" type="number" value="${p.purchase_price||0}"></label><label class="fm-f"><span>سعر البيع</span><input id="ep_s" type="number" value="${p.sale_price||0}"></label><label class="fm-f"><span>سعر الجملة</span><input id="ep_w" type="number" value="${p.wholesale_price||0}"></label><label class="fm-f"><span>حد إعادة الطلب</span><input id="ep_m" type="number" value="${p.min_stock||0}"></label>`,
    async()=>{const nm=v('ep_n').trim();if(!nm)throw Error('اكتب اسم الصنف');if(dupProdName(nm,id))throw Error('يوجد صنف آخر بنفس الاسم');await upd('products',id,{name:nm,code:v('ep_c')||null,barcode:v('ep_b')||null,purchase_price:n('ep_p'),sale_price:n('ep_s'),wholesale_price:n('ep_w'),min_stock:n('ep_m')})},
    'حفظ التعديل');
}
function productsView(){
  const canM=canMaster();
  const addCard=canM?`<div class="card np"><div class="row"><input id="pn" placeholder="الاسم"><input id="pc" placeholder="الكود"><input id="pbc" placeholder="باركود"><input id="pp" type="number" placeholder="شراء"><input id="ps" type="number" placeholder="بيع"><input id="pw" type="number" placeholder="جملة"><input id="pm" type="number" placeholder="حد إعادة الطلب"><input id="prq" type="number" placeholder="كمية إعادة الطلب"><input id="pq" type="number" placeholder="الرصيد الافتتاحي (اختياري)"><select id="pwh">${O(C.warehouses)}</select><button onclick="act(async()=>{if(dupProdName(v('pn')))throw Error('يوجد صنف بنفس الاسم بالفعل — عدّل الصنف الموجود بدل إضافة نسخة جديدة');const p=await ins('products',{name:v('pn'),code:v('pc')||null,barcode:v('pbc')||null,purchase_price:n('pp'),sale_price:n('ps'),wholesale_price:n('pw'),min_stock:n('pm'),reorder_qty:n('prq'),avg_cost:n('pp')});if(n('pq')>0)await rpc('set_opening_stock',{p_prod:p.id,p_wh:v('pwh'),p_qty:n('pq')})})">إضافة</button></div><p class="muted">الرصيد الافتتاحي = الكمية الموجودة فعلًا في المخزن المختار وقت بدء استخدام النظام لهذا الصنف. يُسجَّل مرة واحدة فقط.</p></div>`:`<div class="card np muted">عرض فقط — إضافة الأصناف وتعديلها متاحة للإدارة والمحاسب والمخزن.</div>`;
  const rows=C.products.filter(p=>!window._q||[p.name,p.code,p.barcode].join(' ').includes(window._q)).map(p=>[e(p.code),e(p.name),e(p.barcode),fmt(p.avg_cost),fmt(p.sale_price),`<span class="${stkQty(p.id)<=p.min_stock?'bad':''}">${stkQty(p.id)}</span>`,p.active?'مفعّل':'معطل',canM?`<div class="row-btns"><button class="s" onclick="prodEdit('${p.id}')">تعديل</button><button class="s" onclick="act(()=>upd('products','${p.id}',{active:${!p.active}}))">${p.active?'تعطيل':'تفعيل'}</button></div>`:'']);
  return `${addCard}<div class="card"><input id="q" placeholder="بحث" value="${e(window._q||'')}" oninput="qSearch(this)">${T(['الكود','الاسم','الباركود','التكلفة','بيع','المخزون','الحالة',''],rows)}</div>`;
}

// ---------- العملاء والموردون: التعديل في نافذة ----------
function mEdit(kind,id){
  const c=kind==='cust',tbl=c?'customers':'suppliers',x=by(c?C.customers:C.suppliers,id);if(!x.id)return;
  formModal('تعديل: '+e(x.name),
    `<label class="fm-f"><span>الاسم</span><input id="me_n" value="${e(x.name)}"></label><label class="fm-f"><span>الهاتف</span><input id="me_h" value="${e(x.phone||'')}"></label><label class="fm-f"><span>البريد</span><input id="me_e" type="email" value="${e(x.email||'')}"></label><label class="fm-f"><span>العنوان</span><input id="me_a" value="${e(x.address||'')}"></label><label class="fm-f"><span>مدة السداد (يوم)</span><input id="me_t" type="number" value="${x.payment_terms_days||0}"></label>${c?`<label class="fm-f"><span>حد الائتمان</span><input id="me_l" type="number" value="${x.credit_limit||0}"></label>`:''}`,
    async()=>{const nm=v('me_n').trim();if(!nm)throw Error('اكتب الاسم');const o={name:nm,phone:v('me_h')||null,email:v('me_e')||null,address:v('me_a')||null,payment_terms_days:n('me_t')};if(c)o.credit_limit=n('me_l');await upd(tbl,id,o)},
    'حفظ التعديل');
}
function masterForm(kind){
  const c=kind==='cust',tbl=c?'customers':'suppliers',L0=c?C.customers:C.suppliers,q=(window._mq||'').trim(),L=q?L0.filter(x=>[e(x.name),e(x.phone),e(x.email)].join(' ').includes(q)):L0;
  const canEd=isAdminRole()||(!c&&me.role==='accountant');
  const acts=x=>{let h='';if(canEd)h+=`<button class="s" onclick="mEdit('${kind}','${x.id}')">تعديل</button> <button class="s" onclick="act(()=>upd('${tbl}','${x.id}',{active:${!x.active}}))">${x.active?'تعطيل':'تفعيل'}</button>`;if(c&&isAdminRole())h+=` <button class="danger" onclick="delParty('customers','${x.id}')">حذف</button>`;return h};
  const add=`<div class="row"><input id="mn" placeholder="الاسم"><input id="mh" placeholder="الهاتف"><input id="me2" type="email" placeholder="البريد"><input id="ma" placeholder="العنوان"><input id="mt" type="number" placeholder="مدة السداد بالأيام"><input id="mo" type="number" placeholder="رصيد افتتاحي">${c?'<input id="ml" type="number" placeholder="حد الائتمان">':''}<button onclick="act(async()=>ins('${tbl}',{name:v('mn'),phone:v('mh'),email:v('me2'),address:v('ma'),payment_terms_days:n('mt'),opening_balance:n('mo')${c?",credit_limit:n('ml')":''}}))">إضافة</button></div>`;
  return `<h2>${c?'العملاء':'الموردون'}</h2>${canEd?`<div class="card np">${add}</div>`:''}<div class="card np"><input id="mq" placeholder="بحث بالاسم أو الهاتف أو البريد" value="${e(q)}" oninput="mSearch(this)"></div><div class="card">${T(['الاسم','الهاتف','البريد','مدة السداد','الرصيد','الحالة',''],L.map(x=>[e(x.name),e(x.phone),e(x.email),x.payment_terms_days||0,fmt(by(c?C.cb:C.sbal,x.id).balance),x.active?'مفعّل':'معطل',acts(x)]))}</div>`;
}

// ---------- المخازن: التعديل في نافذة ----------
async function warehousesView(){
  const L=await g('warehouses','name');
  return `${sectionHead('المخازن','إضافة مخزن جديد وتعديل اسمه، أو تعطيله.')}
  <div class="card np"><div class="row"><input id="wn" placeholder="اسم المخزن"><button onclick="act(async()=>{if(!v('wn').trim())throw Error('أدخل اسم المخزن');await ins('warehouses',{name:v('wn').trim()})})">إضافة مخزن</button></div></div>
  <div class="card">${T(['المخزن','الحالة',''],L.map(x=>[e(x.name),x.active?'مفعّل':'معطل',`<div class="row-btns"><button class="s" onclick="whEdit('${x.id}')">تعديل</button><button class="s" onclick="act(()=>upd('warehouses','${x.id}',{active:${!x.active}}))">${x.active?'تعطيل':'تفعيل'}</button></div>`]))}</div>`;
}
function whEdit(id){
  const x=by(C.warehouses,id);if(!x.id)return;
  formModal('تعديل المخزن',`<label class="fm-f"><span>اسم المخزن</span><input id="we_n" value="${e(x.name)}"></label>`,async()=>{const nm=v('we_n').trim();if(!nm)throw Error('أدخل اسم المخزن');await upd('warehouses',id,{name:nm})},'حفظ التعديل');
}

// ---------- الفواتير: بانر التعديل ----------
async function invoiceView(s){
  const k=s?'s':'p', mode=(window.ixMode||{})[k]||'hub', title=s?'المبيعات':'المشتريات';
  if(mode==='new') return ixBar(k,window._editInv?'تعديل فاتورة '+window._editInv.number:'إنشاء فاتورة جديدة',title)+(window._editInv?`<div class="card np edit-banner"><span>التعديل بيلغي الفاتورة الأصلية <b>${e(window._editInv.number)}</b> ويعمل فاتورة جديدة بالبيانات المعدّلة <b>بنفس تاريخ الفاتورة الأصلية</b>.</span><button class="btn s" onclick="window._editInv=null;cart.s=[];R('soft')">إلغاء التعديل</button></div>`:'')+await invoiceFormView(s);
  const L=await g(s?'sales_invoice_balances':'purchase_invoice_balances','date');
  if(mode==='list'||mode==='due') return ixBar(k,mode==='list'?'الفواتير السابقة':'الفواتير المستحقة',title)+ixListCard(k,s,L,mode);
  return sectionHead(title,'اختار: فاتورة جديدة، أو الفواتير السابقة، أو المستحقات.')+ixHub(k,s,L);
}

// ---------- التحويل المخزني: بحث عن الصنف بدل القائمة ----------
function tiSearch(q){
  const box=document.getElementById('tiRes');if(!box)return;
  q=(q||'').trim().toLowerCase();
  if(!q){box.innerHTML='';return}
  const list=C.products.filter(p=>p.active&&[p.name,p.code,p.barcode].join(' ').toLowerCase().includes(q)).slice(0,8);
  box.innerHTML=list.length?list.map(p=>`<button type="button" class="doc-res-item" onclick="tiPick('${p.id}')"><b>${e(p.name)}</b><small>${e(p.code||'بدون كود')} · مخزون المصدر ${v('tf')?stkQtyWh(p.id,v('tf')):stkQty(p.id)}</small></button>`).join(''):'<div class="doc-res-empty">لا توجد أصناف مطابقة</div>';
}
function tiPick(id){
  const p=by(C.products,id);if(!p.id)return;
  window._tiP=id;
  const s=document.getElementById('tiSel');if(s)s.innerHTML=`<div class="pk-chip"><div><b>${e(p.name)}</b><small>${e(p.code||'')}</small></div><button type="button" class="pk-x" title="تغيير" onclick="tiClear()">×</button></div>`;
  const q=document.getElementById('tiQ');if(q){q.value='';q.style.display='none'}
  const r=document.getElementById('tiRes');if(r)r.innerHTML='';
  const qt=document.getElementById('tiq');if(qt)qt.focus();
}
function tiClear(){
  window._tiP=null;
  const s=document.getElementById('tiSel');if(s)s.innerHTML='';
  const q=document.getElementById('tiQ');if(q){q.style.display='';q.value='';q.focus()}
}
function tiAdd(){
  const p=window._tiP,q=n('tiq');
  if(!p)return alert('ابحث واختر الصنف أولاً');
  if(!(q>0))return alert('الكمية لازم تكون أكبر من صفر');
  const s=cart.t.find(x=>x.product_id===p);if(s)s.qty+=q;else cart.t.push({product_id:p,qty:q});
  window._tiP=null;R('soft');
}
async function transferView(){
  const cr=cart.t||[];const sp=window._tiP?by(C.products,window._tiP):null;
  const rowsHtml=cr.map((x,i)=>`<tr><td class="c-n">${i+1}</td><td><b>${e(by(C.products,x.product_id).name)}</b></td><td class="c-q">${x.qty}</td><td class="c-x"><button class="danger" onclick="cart.t.splice(${i},1);R('soft')">حذف</button></td></tr>`).join('');
  return `<h2>تحويل مخزني</h2>
  <div class="card tr-card">
    <div class="tr-route">
      <label class="tr-f"><span>من مخزن</span><select id="tf">${O(C.warehouses)}</select></label>
      <div class="tr-arrow" aria-hidden="true">←</div>
      <label class="tr-f"><span>إلى مخزن</span><select id="tt">${O(C.warehouses)}</select></label>
    </div>
    <div class="tr-add">
      <div class="tr-f grow"><span>ابحث عن الصنف</span><div class="pk"><input id="tiQ" type="search" placeholder="اسم الصنف أو الكود أو الباركود، واضغط Enter" autocomplete="off" style="${sp&&sp.id?'display:none':''}" oninput="tiSearch(this.value)" onkeydown="if(event.key==='Enter'){event.preventDefault();const b=document.querySelector('#tiRes .doc-res-item');if(b)b.click()}"><div id="tiRes" class="doc-res"></div><div id="tiSel">${sp&&sp.id?`<div class="pk-chip"><div><b>${e(sp.name)}</b><small>${e(sp.code||'')}</small></div><button type="button" class="pk-x" title="تغيير" onclick="tiClear()">×</button></div>`:''}</div></div></div>
      <label class="tr-f"><span>الكمية</span><input id="tiq" type="number" value="1" inputmode="decimal"></label>
      <button onclick="tiAdd()">إضافة للتحويل</button>
    </div>
    <div class="tr-table">${cr.length?`<table class="doc-tbl"><thead><tr><th class="c-n">#</th><th>الصنف</th><th class="c-q">الكمية</th><th class="c-x"></th></tr></thead><tbody>${rowsHtml}</tbody></table>`:'<div class="tr-empty">لم تُضف أصناف للتحويل بعد.</div>'}</div>
    <label class="tr-f"><span>ملاحظات</span><textarea id="tn" rows="2" placeholder="اختياري"></textarea></label>
    <div class="tr-actions"><button onclick="act(async()=>{if(v('tf')===v('tt'))throw Error('اختر مخزنين مختلفين');if(!cart.t.length)throw Error('أضف بندًا');await rpc('create_stock_transfer',{p_from:v('tf'),p_to:v('tt'),p_items:cart.t,p_notes:v('tn')});cart.t=[];window._tiP=null})">حفظ التحويل</button></div>
  </div>
  <div class="card">${await stkTransfersHtml()}</div>`;
}

// ---------- الجرد: جرد جديد / الجرد السابق + تفاصيل ----------
async function stkDetail(id){
  const{data,error}=await sb.from('stocktake_items').select('*,products(name)').eq('stocktake_id',id).order('id');
  if(error)return alert(error.message);
  const L=data||[];
  const diffs=L.reduce((a,x)=>a+Math.abs((+x.actual_qty||0)-(+x.expected_qty||0)),0);
  showModal(`<div class="card-title"><b>تفاصيل الجرد</b><span class="muted">${L.length} صنف · إجمالي الفروقات ${fmt(diffs)}</span></div>${T(['الصنف','المتوقع','الفعلي','الفرق'],L.map(x=>{const d=(+x.actual_qty||0)-(+x.expected_qty||0);return [e((x.products||{}).name||'—'),fmt(x.expected_qty),fmt(x.actual_qty),`<span class="${d<0?'bad':d>0?'good':''}">${d>0?'+':''}${fmt(d)}</span>`]}))}`,`<button class="btn soft" onclick="modalPrint('تفاصيل الجرد')">طباعة</button>`);
}
async function stocktakeView(){
  const sec=secCur('stk','new');
  const bar=secBar('stk',[['new','جرد جديد'],['hist','الجرد السابق']],'new');
  const H=await g('stocktakes','date');
  if(sec==='hist') return sectionHead('الجرد','الجرود السابقة — اضغط تفاصيل لعرض الأصناف والفروقات.')+bar+`<div class="card">${T(['رقم','التاريخ','المخزن','الحالة',''],H.slice().reverse().map(x=>[e(x.number),x.date,e(by(C.warehouses,x.warehouse_id).name),chip(x.status,x.status==='Approved'?'success':x.status==='Cancelled'?'danger':'warning'),`<button class="s" onclick="stkDetail('${x.id}')">تفاصيل</button>`]))}</div>`;
  let L=[];
  if(stk){const{data,error}=await sb.from('stocktake_items').select('*,products(name)').eq('stocktake_id',stk.id).order('id');if(error)throw error;L=data||[]}
  window._stkL=L;
  return sectionHead('الجرد','ابدأ جردًا لمخزن، أدخل الكميات الفعلية، ثم اعتمد.')+bar+
    `<div class="card np"><div class="row"><select id="sw">${O(C.warehouses)}</select><button onclick="act(async()=>{stk={id:await rpc('create_stocktake',{p_warehouse:v('sw')})}})">بدء جرد جديد</button></div></div>`+
    (stk?`<div class="card"><div class="card-title"><b>الجرد الحالي</b><span class="pill">جرد #${e(stk.id.slice(-6).toUpperCase())}</span></div>${T(['الصنف','المتوقع','الفعلي'],L.map((x,i)=>[e((x.products||{}).name),x.expected_qty,`<input id="sq${i}" type="number" step="0.001" value="${x.actual_qty??x.expected_qty}" style="width:100px">`]))}<button onclick="stkApprove('${stk.id}')">اعتماد الجرد</button></div>`:'<div class="card empty">لا يوجد جرد مفتوح الآن.</div>');
}

// ---------- المرتجعات: مستند قابل للطباعة + زر الحفظ يعمل ----------
window._rk=window._rk||'s';
async function loadRet(){
  const s=v('rk')==='s',id=v('ri');if(!id)return;
  const{data,error}=await sb.from(s?'sales_invoice_items':'purchase_invoice_items').select('product_id,qty,unit_price').eq('invoice_id',id);
  if(error)throw error;
  const inv=await sb.from(s?'sales_invoices':'purchase_invoices').select('number').eq('id',id).single();
  RT={s,id,number:(inv.data&&inv.data.number)||'',items:data||[]};
  R('soft');
}
async function retSave(){
  const cur=RT;if(!cur)return;
  const items=cur.items.map((x,i)=>({product_id:x.product_id,qty:n('rq'+i)})).filter(x=>x.qty>0);
  if(!items.length)return alert('اكتب كمية مرتجع لصنف واحد على الأقل');
  const tbl=cur.s?'sales_returns':'purchase_returns';
  const beforeRes=await sb.from(tbl).select('id').eq('invoice_id',cur.id);
  const before=new Set((beforeRes.data||[]).map(x=>x.id));
  await act(async()=>{await rpc(cur.s?'create_sales_return':'create_purchase_return',{p_invoice:cur.id,p_items:items});RT=null});
  const afterRes=await sb.from(tbl).select('id').eq('invoice_id',cur.id);
  const fresh=(afterRes.data||[]).find(x=>!before.has(x.id));
  if(fresh&&confirm('تم حفظ المرتجع. تطبعه الآن؟'))retPrint(fresh.id,cur.s);
}
async function retPrint(id,s){
  const t=s?'sales':'purchase';
  const h=await sb.from(t+'_returns').select('*').eq('id',id).single().then(r=>{if(r.error)throw r.error;return r.data});
  const its=await sb.from(t+'_return_items').select('*,products(name)').eq('return_id',id).then(r=>{if(r.error)throw r.error;return r.data||[]});
  const co=await g('company_settings').then(x=>x[0]||{});
  const inv=h.invoice_id?await sb.from(t+'_invoices').select('number,date').eq('id',h.invoice_id).single().then(r=>r.data||{}):{};
  const party=by(s?C.customers:C.suppliers,s?h.customer_id:h.supplier_id).name||'—';
  let tot=0;
  const rowsHtml=its.map((x,i)=>{const pr=Number(x.unit_price??x.price??0),q=Number(x.qty||0),lt=Number(x.line_total??q*pr);tot+=lt;return `<tr><td>${i+1}</td><td>${e(x.products?.name||'')}</td><td>${fmt(q)}</td><td>${fmt(pr)}</td><td>${fmt(lt)}</td></tr>`}).join('');
  const title=s?'مرتجع مبيعات':'مرتجع مشتريات';
  printHtml(title+' '+(h.number||''),`<div style="display:flex;justify-content:space-between;align-items:flex-start;border-bottom:3px solid #095F4A;padding-bottom:12px"><div><b style="font-size:17px">${e(co.company_name||'')}</b><div class="muted">${e(co.address||'')}${co.tax_number?'<br>الرقم الضريبي: '+e(co.tax_number):''}</div></div><div style="text-align:left"><h2>${title}</h2><div>رقم: <b>${e(h.number||'')}</b></div><div>التاريخ: ${e(h.date||'')}</div>${inv.number?`<div>من الفاتورة: ${e(inv.number)}</div>`:''}</div></div>
  <p><b>${s?'العميل':'المورد'}:</b> ${e(party)}</p>
  <table><thead><tr><th>#</th><th>الصنف</th><th>الكمية</th><th>السعر</th><th>الإجمالي</th></tr></thead><tbody>${rowsHtml}</tbody></table>
  <p class="tot" style="text-align:left">الإجمالي: ${fmt(h.total??tot)}</p>
  <div style="display:flex;justify-content:space-between;margin-top:40px"><div style="border-top:1px solid #8C97A6;width:200px;text-align:center;padding-top:6px">توقيع المستلم</div><div style="border-top:1px solid #8C97A6;width:200px;text-align:center;padding-top:6px">توقيع المسؤول</div></div>`);
}
async function retView(){
  const sel=window._rk!=='p';
  const[SI,PI,RS]=await Promise.all([g('sales_invoices','date'),g('purchase_invoices','date'),g(sel?'sales_returns':'purchase_returns','date')]);
  const L=sel?SI:PI;
  const cur=(RT&&RT.s===sel)?RT:null;
  const itemsHtml=cur?`<div class="card np"><div class="card-title"><b>بنود الفاتورة ${e(cur.number)}</b><span class="muted">اكتب الكمية المرتجعة لكل صنف ثم احفظ</span></div>${T(['الصنف','الكمية في الفاتورة','سعر الوحدة','كمية المرتجع'],cur.items.map((x,i)=>[e((by(C.products,x.product_id).name)||'—'),fmt(x.qty),fmt(x.unit_price),`<input id="rq${i}" type="number" step="0.001" min="0" value="0" style="width:110px">`]))}<div class="row"><button onclick="retSave()">حفظ المرتجع</button><button class="s" onclick="RT=null;R('soft')">إلغاء</button></div></div>`:'';
  const rows=RS.slice().reverse().map(x=>[e(x.number),x.date,e((by(L,x.invoice_id).number)||'—'),e((by(sel?C.customers:C.suppliers,sel?x.customer_id:x.supplier_id).name)||'—'),fmt(x.total),`<button class="s" onclick="retPrint('${x.id}',${sel})">طباعة</button>`]);
  return sectionHead('المرتجعات','مرتجع مرتبط بفاتورة، يُحفظ ويُطبع كمستند.')+
    `<div class="card np"><div class="row"><select id="rk" onchange="window._rk=v('rk');window._rp=null;RT=null;R('soft')"><option value="s" ${sel?'selected':''}>مرتجع مبيعات</option><option value="p" ${sel?'':'selected'}>مرتجع مشتريات</option></select><select id="ri">${L.slice().reverse().map(x=>`<option value="${x.id}">${e(x.number)} — ${fmt(x.total)}</option>`).join('')}</select><button class="s" onclick="loadRet()">عرض البنود</button></div></div>${itemsHtml}<div class="card"><b>المرتجعات المسجلة</b>${T(['الرقم','التاريخ','الفاتورة','الطرف','الإجمالي',''],rows)}</div>`;
}

// ---------- قوائم الأسعار: عبر الدوال الصريحة + أقسام ----------
async function priceView(){
  const sec=secCur('price','lists');
  const[PL,IT]=await Promise.all([g('price_lists','name'),g('price_list_items',null)]);
  const bar=secBar('price',[['lists','القوائم'],['items','أسعار الأصناف'],['new','إضافة سعر']],'lists');
  let body='';
  if(sec==='lists') body=`<div class="card form-card"><div class="card-title"><b>قائمة أسعار جديدة</b></div><div class="row"><input id="pln" placeholder="اسم قائمة الأسعار"><input id="plcur" value="EGP" placeholder="العملة"><button class="btn" onclick="act(()=>rpc('create_price_list',{p_name:v('pln'),p_currency:v('plcur')}))">إنشاء القائمة</button></div></div><div class="card">${T(['القائمة','العملة','عدد الأصناف'],PL.map(x=>[e(x.name),e(x.currency||'EGP'),IT.filter(i=>i.price_list_id===x.id).length]))}</div>`;
  else if(sec==='items'){
    const rows=IT.map(x=>[e(by(PL,x.price_list_id).name),e(by(C.products,x.product_id).name),fmt(x.min_qty),fmt(x.price)]);
    const texts=IT.map(x=>[by(PL,x.price_list_id).name,by(C.products,x.product_id).name].join(' '));
    body=`<div class="card">${lsCard('pli',['القائمة','الصنف','الحد الأدنى','السعر'],rows,texts,'ابحث باسم الصنف أو القائمة...')}</div>`;
  }
  else body=`<div class="card form-card"><div class="card-title"><b>إضافة سعر صنف</b></div><div class="row"><select id="pli">${O(PL)}</select><select id="plp">${O(C.products)}</select><input id="plprice" type="number" step="0.0001" placeholder="السعر"><input id="plmin" type="number" value="1" min="0.001" placeholder="الحد الأدنى للكمية"><button class="btn" onclick="act(()=>rpc('add_price_list_item',{p_list:v('pli'),p_product:v('plp'),p_price:n('plprice'),p_min_qty:n('plmin')}))">إضافة السعر</button></div></div>`;
  return sectionHead('قوائم الأسعار','أسعار البيع حسب القائمة والكمية.')+bar+body;
}

// ---------- العمولات: قواعد / حساب / سجل ----------
async function commissionView(){
  const sec=secCur('comm','rules');
  const[RL,I,Cm]=await Promise.all([g('commission_rules','name'),g('sales_invoices','date'),g('sales_commissions','created_at')]);
  const bar=secBar('comm',[['rules','قواعد العمولة'],['calc','حساب عمولة'],['list','العمولات المسجلة']],'rules');
  let body='';
  if(sec==='rules') body=`<div class="card form-card"><div class="card-title"><b>قاعدة عمولة جديدة</b></div><div class="row"><input id="crn" placeholder="اسم القاعدة"><input id="crr" type="number" step="0.0001" placeholder="النسبة %"><select id="crb"><option value="net_sales">صافي المبيعات</option><option value="gross_profit">مجمل الربح</option></select><button class="btn" onclick="act(()=>rpc('create_commission_rule',{p_name:v('crn'),p_rate:n('crr'),p_basis:v('crb')}))">إضافة القاعدة</button></div></div><div class="card">${T(['القاعدة','النسبة %','الأساس'],RL.map(x=>[e(x.name),x.rate,x.basis==='gross_profit'?'مجمل الربح':'صافي المبيعات']))}</div>`;
  else if(sec==='calc') body=`<div class="card form-card"><div class="card-title"><b>حساب عمولة فاتورة</b></div><div class="row"><select id="cri">${I.filter(x=>x.status==='Posted').map(x=>`<option value="${x.id}">${e(x.number)} — ${fmt(x.total)}</option>`).join('')}</select><select id="crr2">${O(RL)}</select><button class="btn" onclick="act(()=>rpc('calculate_sales_commission',{p_invoice:v('cri'),p_rule:v('crr2')}))">حساب وتسجيل العمولة</button></div></div>`;
  else body=`<div class="card">${T(['الفاتورة','البائع','الأساس','العمولة','الحالة'],Cm.map(x=>[e(by(I,x.invoice_id).number||x.invoice_id),e(x.salesperson_id),money(x.basis_amount),money(x.amount),chip(x.status,x.status==='Paid'?'success':'warning')]))}</div>`;
  return sectionHead('العمولات','حساب عمولات البائعين بناءً على صافي المبيعات أو مجمل الربح.')+bar+body;
}

// ---------- الفترات المالية: إنشاء عبر الدالة الصريحة + أقسام ----------
async function periodView(){
  const sec=secCur('per','list');
  const L=await g('fiscal_periods','start_date');
  const bar=secBar('per',[['list','الفترات'],['new','فترة جديدة']],'list');
  const body=sec==='new'?`<div class="card form-card"><div class="card-title"><b>فترة مالية جديدة</b></div><div class="row"><input id="fpn" placeholder="اسم الفترة (اختياري)"><label>من <input id="fps" type="date"></label><label>إلى <input id="fpe" type="date"></label><button class="btn" onclick="act(()=>rpc('create_fiscal_period',{p_name:v('fpn'),p_start:v('fps'),p_end:v('fpe')}))">إنشاء الفترة</button></div></div>`
    :`<div class="card">${T(['الفترة','من','إلى','الحالة',''],L.map(x=>[e(x.name),x.start_date,x.end_date,chip(x.status,x.status==='Closed'?'danger':'success'),x.status==='Closed'?`<button class="btn soft" onclick="act(()=>rpc('reopen_fiscal_period',{p_period:'${x.id}'}))">فتح</button>`:`<button class="btn danger" onclick="act(()=>rpc('close_fiscal_period',{p_period:'${x.id}'}))">إقفال</button>`]))}</div>`;
  return sectionHead('الفترات والإقفال','لا يُسمح بتعديل فترة مقفولة إلا بعد فتحها.')+bar+body;
}

// ---------- الأصول الثابتة: مبسطة + طباعة + التصنيفات في قسم ----------
function assetNew(){
  formModal('أصل ثابت جديد',
    `<label class="fm-f"><span>اسم الأصل</span><input id="afn"></label><label class="fm-f"><span>التصنيف</span><select id="afc">${O(window._assetCats||[])}</select></label><label class="fm-f"><span>التكلفة</span><input id="afcost" type="number"></label><label class="fm-f"><span>القيمة المتبقية</span><input id="afres" type="number" value="0"></label><label class="fm-f"><span>العمر بالشهور</span><input id="aflife" type="number" value="60"></label><label class="fm-f"><span>حساب الدفع</span><select id="afacct">${O(C.accts)}</select></label>`,
    async()=>{const id=await rpc('create_fixed_asset',{p_name:v('afn'),p_category:v('afc'),p_cost:n('afcost'),p_residual:n('afres'),p_life_months:n('aflife'),p_purchase_date:new Date().toISOString().slice(0,10),p_branch:null});await rpc('capitalize_fixed_asset',{p_asset:id,p_credit_account:v('afacct')})},'إضافة وتسجيل');
}
async function assetView(){
  const sec=secCur('asset','list');
  const[A,CAT]=await Promise.all([g('fixed_assets','created_at'),g('asset_categories','name')]);
  window._assetCats=CAT;
  const bar=secBar('asset',[['list','الأصول'],['cat','التصنيفات']],'list');
  const today=new Date().toISOString().slice(0,10);
  let body='';
  if(sec==='cat') body=`<div class="card form-card"><div class="card-title"><b>تصنيف جديد</b></div><div class="row"><input id="acn" placeholder="اسم التصنيف"><input id="acl" type="number" value="60" placeholder="العمر الإنتاجي بالشهور"><button class="btn" onclick="act(()=>rpc('create_asset_category',{p_name:v('acn'),p_life_months:n('acl')}))">إضافة التصنيف</button></div></div><div class="card">${T(['التصنيف','العمر (شهور)'],CAT.map(x=>[e(x.name),x.default_life_months]))}</div>`;
  else{
    const rows=A.map(x=>[e(x.code),e(x.name),fmt(x.cost),fmt(x.accumulated_depreciation),fmt(x.cost-x.accumulated_depreciation),chip(x.status,x.status==='Disposed'?'danger':'success'),x.status==='Active'?`<div class="row-btns"><button class="s" onclick="act(()=>rpc('depreciate_asset',{p_asset:'${x.id}',p_period:'${today}'}))">إهلاك</button><button class="danger" onclick="act(()=>rpc('dispose_fixed_asset',{p_asset:'${x.id}',p_date:'${today}',p_proceeds:0,p_account:null}))">استبعاد</button></div>`:'—']);
    ptStore('asset','الأصول الثابتة','',['الكود','الأصل','التكلفة','المجمع','الصافي','الحالة'],A.map(x=>[e(x.code),e(x.name),fmt(x.cost),fmt(x.accumulated_depreciation),fmt(x.cost-x.accumulated_depreciation),e(x.status)]));
    body=`<div class="card np"><div class="row"><button onclick="assetNew()">+ أصل ثابت جديد</button><button class="s" onclick="ptPrint('asset')">طباعة القائمة</button></div></div><div class="card">${T(['الكود','الأصل','التكلفة','المجمع','الصافي','الحالة',''],rows)}</div>`;
  }
  return sectionHead('الأصول الثابتة','أضف الأصل من الزر، والإهلاك والاستبعاد من نفس الصف.')+bar+body;
}

// ---------- البنوك: كل وظيفة في قسمها ----------
async function bankView(){
  const sec=secCur('bank','st');
  const banks=(C.accts||[]).filter(a=>a.type==='bank');
  const[stm,lines,payments]=await Promise.all([g('bank_statements','created_at'),g('bank_statement_lines','created_at'),g('payments','date')]);
  const today=new Date().toISOString().slice(0,10);
  const bar=secBar('bank',[['st','كشوف البنك'],['ln','حركات الكشف'],['rc','المطابقة']],'st');
  let body='';
  if(sec==='st') body=`<div class="card form-card"><div class="card-title"><b>كشف بنك جديد</b></div><div class="row"><select id="bka">${O(banks)}</select><input id="bkn" placeholder="رقم كشف البنك"><input id="bkopen" type="number" placeholder="رصيد أول المدة"><input id="bkclose" type="number" placeholder="رصيد آخر المدة"><button class="btn" onclick="act(()=>ins('bank_statements',{account_id:v('bka'),statement_no:v('bkn'),opening_balance:n('bkopen'),closing_balance:n('bkclose')}))">إنشاء الكشف</button></div></div><div class="card">${T(['الحساب','الكشف','من','إلى','أول المدة','آخر المدة','الحالة'],stm.map(x=>[e(by(C.accts,x.account_id).name),e(x.statement_no),x.from_date||'',x.to_date||'',money(x.opening_balance),money(x.closing_balance),chip(x.status,x.status==='Reconciled'?'success':'warning')]))}</div>`;
  else if(sec==='ln') body=`<div class="card form-card"><div class="card-title"><b>إضافة حركة كشف</b></div><div class="row"><select id="bks">${stm.map(x=>`<option value="${x.id}">${e(x.statement_no)}</option>`).join('')}</select><input id="bkdate" type="date" value="${today}"><input id="bkdesc" placeholder="البيان"><input id="bkamt" type="number" placeholder="المبلغ"><select id="bkdir"><option value="credit">داخل</option><option value="debit">خارج</option></select><button class="btn soft" onclick="act(()=>ins('bank_statement_lines',{statement_id:v('bks'),txn_date:v('bkdate'),description:v('bkdesc'),amount:n('bkamt'),direction:v('bkdir')}))">إضافة</button></div></div><div class="card">${T(['التاريخ','البيان','المبلغ','الاتجاه','مطابق'],lines.map(x=>[x.txn_date,e(x.description||''),money(x.amount),x.direction==='credit'?'داخل':'خارج',x.reconciled?ico('check'):'—']))}</div>`;
  else body=`<div class="card form-card"><div class="card-title"><b>مطابقة حركة كشف مع مدفوعة</b></div><div class="row"><select id="bkl">${lines.filter(x=>!x.reconciled).map(x=>`<option value="${x.id}">${x.txn_date} — ${e(x.description||'')} — ${fmt(x.amount)}</option>`).join('')}</select><select id="bkp">${payments.map(x=>`<option value="${x.id}">${x.date} — ${fmt(x.amount)} — ${e(x.doc_ref||'')}</option>`).join('')}</select><button class="btn" onclick="act(()=>rpc('reconcile_bank_line',{p_line:v('bkl'),p_payment:v('bkp')}))">مطابقة</button></div></div>`;
  return sectionHead('البنوك والتسويات البنكية','كشوف البنك، حركاتها، ومطابقتها مع المقبوضات والمدفوعات.')+bar+body;
}

// ---------- الخزينة: الحسابات / التحويلات / حركة الخزينة ----------
const LEDGER_SRC={create_sale:'فاتورة بيع',create_purchase:'فاتورة شراء',record_payment:'تحصيل / دفع',create_expense:'مصروف',transfer_cash:'تحويل بين الحسابات',pay_payroll:'دفع مرتب',cancel_sales_invoice:'إلغاء فاتورة',edit_sales_invoice:'تعديل فاتورة',create_sales_return:'مرتجع بيع',create_purchase_return:'مرتجع شراء',record_cheque:'شيك',update_cheque_status:'تحصيل شيك',reconcile_bank_line:'مطابقة بنك',capitalize_fixed_asset:'رسملة أصل',dispose_fixed_asset:'استبعاد أصل'};
async function cashLedgerHtml(){
  const day=dyGet('led');const[a,b]=dayRange(day);
  const[res,PN]=await Promise.all([sb.from('cash_movements').select('*').gte('created_at',a).lt('created_at',b).order('created_at',{ascending:false}).limit(3000),profNames()]);
  if(res.error)throw res.error;
  const L=(res.data||[]).filter(x=>cday(x.created_at)===day);
  const an=id=>(by(C.accts,id).name)||'—';
  let tin=0,tout=0;L.forEach(x=>{if(x.direction==='in')tin+=+x.amount;else tout+=+x.amount});
  const tm=x=>new Date(x.created_at).toLocaleTimeString(locOf(),{hour:'2-digit',minute:'2-digit',timeZone:'Africa/Cairo'});
  const rows=L.map(x=>[tm(x),e(an(x.account_id)),x.direction==='in'?'<span class="good">داخل ＋</span>':'<span class="bad">خارج −</span>',fmt(x.amount),e(LEDGER_SRC[x.source]||x.source||'—'),e(PN[x.user_id]||'—')]);
  const texts=L.map(x=>[an(x.account_id),LEDGER_SRC[x.source]||x.source||'',PN[x.user_id]||'',x.direction==='in'?'داخل':'خارج'].join(' '));
  const dl=new Date(day+'T12:00:00Z').toLocaleDateString(locOf(),{weekday:'long',day:'numeric',month:'long',year:'numeric',timeZone:'Africa/Cairo'});
  ptStore('led','حركة الخزينة — '+dl,'',['الوقت','الحساب','الاتجاه','المبلغ','المصدر','المستخدم'],L.map(x=>[tm(x),e(an(x.account_id)),x.direction==='in'?'داخل':'خارج',fmt(x.amount),e(LEDGER_SRC[x.source]||x.source||'—'),e(PN[x.user_id]||'—')]),`<p class="tot">داخل: ${fmt(tin)} · خارج: ${fmt(tout)} · الصافي: ${fmt(tin-tout)}</p>`);
  return `${dayStrip('led',day)}<div class="card"><div class="card-title"><b>حركة ${e(dl)}</b><div class="row"><span class="chip success">داخل ${fmt(tin)}</span><span class="chip danger">خارج ${fmt(tout)}</span><span class="chip info">الصافي ${fmt(tin-tout)}</span><button class="s" onclick="ptPrint('led')">طباعة هذا اليوم</button></div></div>${lsCard('led',['الوقت','الحساب','الاتجاه','المبلغ','المصدر','المستخدم'],rows,texts,'ابحث بالحساب أو المصدر أو المستخدم...')}</div>`;
}
async function cashView(){
  const sec=secCur('cash','acc');
  const bar=secBar('cash',[['acc','الحسابات'],['trf','التحويلات'],['led','حركة الخزينة']],'acc');
  let body='';
  if(sec==='acc') body=`<div class="card form-card"><div class="card-title"><b>حساب جديد</b></div><div class="row"><input id="an" placeholder="اسم الحساب"><select id="at"><option value="cash">خزينة</option><option value="bank">بنك</option><option value="wallet">محفظة</option><option value="other">أخرى</option></select><input id="ao" type="number" placeholder="رصيد افتتاحي"><button class="btn" onclick="act(()=>ins('cash_accounts',{name:v('an'),type:v('at'),opening_balance:n('ao'),balance:n('ao')}))">إضافة</button></div></div><div class="card">${T(['الحساب','النوع','الرصيد'],C.accts.map(a=>[e(a.name),a.type,money(a.balance)]))}</div>`;
  else if(sec==='trf') body=`<div class="card form-card"><div class="card-title"><b>تحويل بين الحسابات</b></div><div class="row"><select id="ctf">${O(C.accts)}</select><select id="ctt">${O(C.accts)}</select><input id="ctam" type="number" placeholder="المبلغ"><button class="btn" onclick="act(()=>{if(v('ctf')===v('ctt'))throw Error('اختر حسابين مختلفين');return rpc('transfer_cash',{p_from:v('ctf'),p_to:v('ctt'),p_amount:n('ctam')})})">تحويل</button></div></div><div class="card"><b>سجل التحويلات</b>${await cashTransfersHtml()}</div>`;
  else body=await cashLedgerHtml();
  return sectionHead('الخزينة','الحسابات النقدية، التحويلات بينها، وحركة الخزينة اليومية.')+bar+body;
}

// ---------- المصروفات: مقسّمة بالأيام ----------
async function expensesView(){
  const L=await g('expenses','date');
  const day=dyGet('exp');
  const sumOf=d=>L.filter(x=>x.date===d).reduce((a,x)=>a+Number(x.amount||0),0);
  const rowsDay=L.filter(x=>x.date===day).reverse();
  const tot=rowsDay.reduce((a,x)=>a+Number(x.amount||0),0);
  const cells=rowsDay.map(x=>[e(x.category||''),e(x.description||''),money(x.amount),e((by(C.accts,x.account_id).name)||'—')]);
  ptStore('exp','المصروفات — '+day,'',['التصنيف','الوصف','المبلغ','الحساب'],rowsDay.map(x=>[e(x.category||''),e(x.description||''),fmt(x.amount),e((by(C.accts,x.account_id).name)||'—')]),`<p class="tot">الإجمالي: ${fmt(tot)}</p>`);
  return sectionHead('المصروفات','تسجيل المصروف يتم بتاريخ اليوم. الأيام السابقة للعرض والطباعة.')+
  `<div class="card form-card"><div class="card-title"><b>تسجيل مصروف (اليوم)</b></div><div class="row"><select id="ec"><option>إيجار</option><option>كهرباء</option><option>مياه</option><option>إنترنت</option><option>رواتب</option><option>نقل</option><option>صيانة</option><option>تسويق</option><option>أخرى</option></select><input id="ed" placeholder="الوصف"><input id="ea" type="number" placeholder="المبلغ"><select id="ex">${O(C.accts)}</select><button class="btn" onclick="act(()=>rpc('create_expense',{p_category:v('ec'),p_desc:v('ed'),p_amount:n('ea'),p_account:v('ex')}))">حفظ</button></div></div>`+
  dayStrip('exp',day,d=>fmt(sumOf(d)))+
  `<div class="card"><div class="card-title"><b>مصروفات ${e(day)}</b><div class="row"><span class="chip info">الإجمالي ${fmt(tot)}</span><button class="s" onclick="ptPrint('exp')">طباعة هذا اليوم</button></div></div>${T(['التصنيف','الوصف','المبلغ','الحساب'],cells)}</div>`;
}

// ---------- الموظفون: بحث + تعديل + ربط بحساب النظام ----------
async function employeesView(){
  const[L,U]=await Promise.all([g('employees','name'),g('profiles','name').catch(()=>[])]);
  window._empL=L;window._empU=U;
  const canE=isAdminRole()||me.role==='accountant';
  const uname=id=>{const u=U.find(x=>x.id===id);return u?(u.name||u.username||''):''};
  const rows=L.map(x=>[e(x.name),e(x.job||''),e(x.phone||''),fmt(x.salary),e(uname(x.user_id)||'—'),x.active?'نشط':'موقوف',canE?`<button class="s" onclick="empForm('${x.id}')">تعديل</button>`:'']);
  const texts=L.map(x=>[e(x.name),e(x.job),e(x.phone),uname(x.user_id)].join(' '));
  return `${sectionHead('الموظفون','بيانات الموظف، ومن يملك حساب دخول للنظام.')}${canE?`<div class="card np"><div class="row"><button onclick="empForm()">+ موظف جديد</button></div></div>`:''}<div class="card">${lsCard('emp',['الاسم','الوظيفة','الهاتف','المرتب','حساب النظام','الحالة',''],rows,texts,'ابحث بالاسم أو الوظيفة أو الهاتف...')}</div>`;
}
function empForm(id){
  const x=id?by(window._empL||[],id):{};const U=window._empU||[];
  const opts=`<option value="">— بدون حساب —</option>`+U.map(u=>`<option value="${u.id}" ${x.user_id===u.id?'selected':''}>${e(u.name||u.username||'')}</option>`).join('');
  formModal(id?'تعديل موظف':'موظف جديد',
    `<label class="fm-f"><span>الاسم</span><input id="em_n" value="${e(x.name||'')}"></label><label class="fm-f"><span>الوظيفة</span><input id="em_j" value="${e(x.job||'')}"></label><label class="fm-f"><span>الهاتف</span><input id="em_h" value="${e(x.phone||'')}"></label><label class="fm-f"><span>المرتب</span><input id="em_s" type="number" value="${x.salary||0}"></label><label class="fm-f"><span>تاريخ التعيين</span><input id="em_d" type="date" value="${x.joining_date||''}"></label><label class="fm-f"><span>حساب الدخول للنظام</span><select id="em_u">${opts}</select></label>${id?`<label class="fm-f"><span>الحالة</span><select id="em_a"><option value="1" ${x.active?'selected':''}>نشط</option><option value="0" ${x.active?'':'selected'}>موقوف</option></select></label>`:''}`,
    async()=>{
      const body={name:v('em_n').trim(),job:v('em_j')||null,phone:v('em_h')||null,salary:n('em_s'),joining_date:v('em_d')||null,user_id:v('em_u')||null};
      if(!body.name)throw Error('اكتب اسم الموظف');
      if(id){body.active=v('em_a')==='1';await upd('employees',id,body)}
      else{await ins('employees',{...body,active:true})}
    },'حفظ');
}

// ---------- الموارد البشرية: كل قسم في تبويبه (حضور / إجازات / مكافآت وجزاءات / عطلات) ----------
function dCount(f,t){const d=Math.round((new Date(t)-new Date(f))/86400000)+1;return d>0?d:1}
async function hrView(){
  const sec=secCur('hr','att');
  const[E,L,Adj,Holi,types]=await Promise.all([g('employees','name'),g('leave_requests',null),g('employee_adjustments','effective_date'),g('holidays','holiday_date'),g('leave_types','name')]);
  const today=new Date().toISOString().slice(0,10);
  const bar=secBar('hr',[['att','الحضور'],['leave','الإجازات'],['adj','مكافآت وجزاءات'],['hol','العطلات']],'att');
  let body='';
  if(sec==='att'){
    const isAdm=me.role==='admin';
    const A=await g('attendance','work_date');
    const form=isAdm?`<div class="card form-card"><div class="card-title"><b>تسجيل حضور يدوي</b><span class="muted">الأدمن بس. اختار الموظف والتاريخ، وبعدين الوقت لو معاك.</span></div>
      <div class="fm-grid"><label class="fm-f"><span>الموظف</span><select id="he">${O(E)}</select></label><label class="fm-f"><span>التاريخ</span><input id="hd" type="date" value="${today}"></label><label class="fm-f"><span>الحالة</span><select id="hs"><option value="Present">حاضر</option><option value="Late">متأخر</option><option value="Absent">غايب</option><option value="Leave">إجازة</option><option value="Holiday">عطلة</option></select></label><label class="fm-f"><span>وقت الحضور</span><input id="hi" type="time"></label><label class="fm-f"><span>وقت الانصراف</span><input id="ho" type="time"></label></div>
      <div class="row" style="margin-top:12px"><button class="btn" onclick="attSave()">حفظ الحضور</button></div></div>`:`<div class="card"><span class="muted">تسجيل الحضور والانصراف للأدمن بس. دي قراءة للسجل.</span></div>`;
    const attT=t=>t?new Date(t).toLocaleTimeString(locOf(),{timeZone:'Africa/Cairo',hour:'2-digit',minute:'2-digit'}):'—';
    const rows=A.slice(-200).reverse().map(x=>[x.work_date,e(by(E,x.employee_id).name||'—'),attT(x.check_in),attT(x.check_out),e(x.status)]);
    body=form+`<div class="card">${T(['التاريخ','الموظف','الحضور','الانصراف','الحالة'],rows)}</div>`;
  }
  else if(sec==='leave') body=`<div class="card form-card"><div class="card-title"><b>طلب إجازة</b></div><div class="row"><select id="hle">${O(E)}</select><select id="hlt">${O(types)}</select><input id="hf" type="date"><input id="ht" type="date"><input id="hlr" placeholder="السبب"><button class="btn soft" onclick="act(()=>ins('leave_requests',{employee_id:v('hle'),leave_type_id:v('hlt'),from_date:v('hf'),to_date:v('ht'),days:dCount(v('hf'),v('ht')),reason:v('hlr')}))">تقديم الطلب</button></div></div><div class="card">${T(['الموظف','من','إلى','الأيام','الحالة','السبب'],L.map(x=>[e(by(E,x.employee_id).name),x.from_date,x.to_date,x.days,chip(x.status,x.status==='Approved'?'success':x.status==='Rejected'?'danger':'warning'),e(x.reason)]))}</div>`;
  else if(sec==='adj') body=`<div class="card form-card"><div class="card-title"><b>مكافأة / جزاء</b><span class="muted">يُربط بشهر المرتب ويدخل في حسابه.</span></div><div class="row"><select id="ae">${O(E)}</select><select id="ak"><option value="reward">مكافأة</option><option value="penalty">جزاء</option></select><input id="aa" type="number" placeholder="المبلغ"><input id="ad" type="date" value="${today}"><input id="am" type="month"><input id="ar" placeholder="السبب"><button class="btn" onclick="act(()=>ins('employee_adjustments',{employee_id:v('ae'),kind:v('ak'),amount:n('aa'),effective_date:v('ad'),payroll_month:v('am')?v('am')+'-01':null,reason:v('ar')}))">إضافة</button></div></div><div class="card">${T(['الموظف','النوع','المبلغ','التاريخ','الشهر','الاعتماد'],Adj.map(x=>[e(by(E,x.employee_id).name),x.kind==='reward'?'مكافأة':'جزاء',money(x.amount),x.effective_date,x.payroll_month?x.payroll_month.slice(0,7):'—',chip(x.approved?'معتمد':'معلّق',x.approved?'success':'warning')]))}</div>`;
  else body=`<div class="card form-card"><div class="card-title"><b>العطلات الرسمية</b><span class="muted">تُستخدم لتحديد حالة Holiday في الحضور.</span></div><div class="row"><input id="hn" placeholder="اسم العطلة"><input id="hdx" type="date"><label><input type="checkbox" id="hp" checked> مدفوعة</label><button class="btn soft" onclick="act(()=>ins('holidays',{name:v('hn'),holiday_date:v('hdx'),paid:$('#hp').checked}))">إضافة عطلة</button></div></div><div class="card">${T(['العطلة','التاريخ','مدفوعة'],Holi.map(x=>[e(x.name),x.holiday_date,x.paid?'نعم':'لا']))}</div>`;
  return sectionHead('الموارد البشرية','الحضور والإجازات والمكافآت والجزاءات والعطلات — كل قسم في تبويبه.')+bar+body;
}

// ---------- المرتبات: التفاصيل في نافذة ----------
async function payShow(id){
  const[E,L]=await Promise.all([g('employees','name'),g('payroll','month')]);
  const x=L.find(r=>r.id===id);if(!x)return toast('لم يتم العثور على الكشف');
  showModal(`<div class="card-title"><b>تفاصيل كشف المرتب</b><span class="muted">${e(String(x.month||'').slice(0,7))}</span></div>${T(['البند','القيمة'],payslipRows(x,E))}`,`<button class="btn soft" onclick="modalPrint('كشف مرتب')">طباعة</button>`);
}

// ---------- المدفوعات: تسجيل / سجل / أرصدة ----------
async function payView(){
  const sec=secCur('pay','new');
  const cu=window._yk!=='supp';const L=cu?C.customers:C.suppliers;const P_=cu?C.cb:C.sbal;
  const bar=secBar('pay',[['new','تسجيل دفعة'],['hist','سجل الدفعات'],['bal','الأرصدة']],'new');
  let body='';
  if(sec==='new') body=`<div class="card np pay-card"><div class="pay-form">`+
    `<label class="pf-f"><span>نوع الحركة</span><select id="yk" onchange="window._yk=v('yk')==='receipt'?'cust':'supp';R()"><option value="receipt" ${cu?'selected':''}>مقبوضات</option><option value="payment" ${cu?'':'selected'}>مدفوعات</option></select></label>`+
    `<div class="pf-f pf-wide"><span>الطرف</span><input id="ypQ" type="search" placeholder="ابحث بالاسم أو رقم الهاتف" oninput="ypSearch(this.value)" autocomplete="off"><input type="hidden" id="yp" value=""><div id="ypSel"></div><div id="ypRes" class="doc-res"></div></div>`+
    `<label class="pf-f"><span>الفاتورة (اختياري)</span><select id="yinv"><option value="">دفعة على الحساب (بدون تخصيص)</option></select></label>`+
    `<label class="pf-f"><span>المبلغ</span><input id="ya" type="number" placeholder="0.00"></label>`+
    `<label class="pf-f"><span>الحساب</span><select id="yc">${O(C.accts)}</select></label>`+
    `<div class="pf-f pf-act"><span>&nbsp;</span><button onclick="savePayment()">تسجيل الدفعة</button></div>`+
    `</div><p class="muted pay-note">يمكن ترك الفاتورة فارغة ليصبح المبلغ رصيدًا غير مخصص، ثم تخصيصه لاحقًا.</p></div>`;
  else if(sec==='hist'){
    const day=dyGet('pay');
    const P=await g('payments','date');
    const dayOf=p=>String(p.date||'').slice(0,10);
    const cnt={};P.forEach(p=>{const d=dayOf(p);cnt[d]=(cnt[d]||0)+1});
    const nm=p=>p.kind==='receipt'?(by(C.customers,p.customer_id).name||''):(by(C.suppliers,p.supplier_id).name||'');
    const rowsDay=P.filter(p=>dayOf(p)===day).sort((x,y)=>String(y.created_at||'').localeCompare(String(x.created_at||'')));
    const tot=rowsDay.reduce((t,p)=>t+Number(p.amount||0),0);
    const rin=rowsDay.filter(p=>p.kind==='receipt').reduce((t,p)=>t+Number(p.amount||0),0);
    const rout=tot-rin;
    const cells=rowsDay.map(p=>[e(nm(p)||'—'),p.kind==='receipt'?'مقبوض':'مدفوع',fmt(p.amount),e((by(C.accts,p.account_id).name)||''),e(p.doc_ref||'')]);
    ptStore('pay','المدفوعات والتحصيل — '+day,'',['الطرف','النوع','المبلغ','الحساب','المستند'],cells,`<p class="tot">مقبوضات: ${fmt(rin)} · مدفوعات: ${fmt(rout)} · الصافي: ${fmt(rin-rout)}</p>`);
    body=dayStrip('pay',day,d=>(cnt[d]||0)+' حركة')+
      `<div class="card"><div class="card-title"><b>حركات ${e(day)}</b><div class="row"><span class="chip success">مقبوض ${fmt(rin)}</span><span class="chip danger">مدفوع ${fmt(rout)}</span><span class="chip info">الإجمالي ${fmt(tot)}</span><button class="s" onclick="ptPrint('pay')">طباعة هذا اليوم</button></div></div>`+
      (rowsDay.length?T(['الطرف','النوع','المبلغ','الحساب','المستند'],cells):'<div class="empty">لا توجد حركات في هذا اليوم</div>')+'</div>';
  }
  else body=`<div class="card"><b>الأرصدة</b>${T(['الاسم','الرصيد'],L.map(x=>[e(x.name),fmt(by(P_,x.id).balance)]))}</div>`;
  return sectionHead('المدفوعات والتحصيل','تسجيل المقبوضات والمدفوعات وتخصيصها على الفواتير.')+bar+body;
}
function ypSearch(q){
  const box=document.getElementById('ypRes');if(!box)return;
  q=(q||'').trim().toLowerCase();if(!q){box.innerHTML='';return}
  const L=v('yk')==='receipt'?C.customers:C.suppliers;
  const list=L.filter(x=>[x.name,x.phone].join(' ').toLowerCase().includes(q)).slice(0,8);
  box.innerHTML=list.length?list.map(x=>`<button type="button" class="doc-res-item" onclick="ypPick('${x.id}')"><b>${e(x.name)}</b><small>${e(x.phone||'بدون رقم هاتف')}</small></button>`).join(''):'<div class="doc-res-empty">لا يوجد طرف بهذا الاسم أو الرقم</div>';
}
function ypPick(id){
  const L=v('yk')==='receipt'?C.customers:C.suppliers;const x=L.find(r=>r.id===id);if(!x)return;
  document.getElementById('yp').value=id;
  document.getElementById('ypQ').style.display='none';document.getElementById('ypQ').value='';
  document.getElementById('ypRes').innerHTML='';
  document.getElementById('ypSel').innerHTML=`<div class="yp-chosen"><b>${e(x.name)}</b><button type="button" class="linkbtn" onclick="ypClear()">تغيير</button></div>`;
  loadPayInvoices();
}
function ypClear(){
  document.getElementById('yp').value='';document.getElementById('ypSel').innerHTML='';
  const q=document.getElementById('ypQ');q.style.display='';q.value='';q.focus();
}

// ---------- كشف الحساب: البحث عن الطرف (بدون تغيير سلوك) ----------

// ---------- المستخدمون: تعديل وتغيير كلمة السر والصلاحيات في نوافذ ----------
async function usersView(){
  const L=(await g('profiles','created_at')).filter(u=>me.isDev||u.role!=='developer');
  window._usersL=L;
  const isA=isAdminRole();
  const rows=L.map(u=>{
    const top=(u.role==='admin'||u.role==='developer');
    return [`${e(u.name)}${u.role==='developer'?' '+chip('مطور','warning'):''}`,e(u.username),u.role==='developer'?'<b>مطور</b>':(top?'<b>admin</b>':e(u.role)),chip(top?'كامل':(u.permissions_mode==='custom'?'مخصص':'حسب الدور'),top?'success':(u.permissions_mode==='custom'?'warning':'info')),
      `<input type="checkbox" ${u.active?'checked':''} ${u.id===me.id?'disabled':''} onchange="act(()=>upd('profiles','${u.id}',{active:this.checked}))">`,
      `<div class="row-btns">${isA?`<button class="s" onclick="userEdit('${u.id}')">تعديل</button><button class="s" onclick="userResetPw('${u.id}')">تغيير كلمة السر</button>`:''}${top?'':`<button class="s" onclick="openPermissionEditor('${u.id}')">الصلاحيات</button>`}</div>`];
  });
  return `${sectionHead('المستخدمون والصلاحيات','الدور الأساسي يحدد الحد الأعلى، والتخصيص يختار ما يظهر لكل مستخدم.')}${isA?addUserCard():''}<div class="card">${T(['الاسم','البريد','الدور الأساسي','الوضع','مفعّل',''],rows)}</div>`;
}
function userEdit(id){
  const u=by(window._usersL||[],id);if(!u.id)return;
  const roles=['accountant','sales','store','admin',...(me.isDev?['developer']:[])];
  formModal('تعديل المستخدم',
    `<label class="fm-f"><span>الاسم</span><input id="ue_n" value="${e(u.name||'')}"></label><label class="fm-f"><span>البريد (اسم الدخول)</span><input id="ue_e" type="email" value="${e(u.username||'')}"></label><label class="fm-f"><span>الدور</span><select id="ue_r" ${u.id===me.id?'disabled':''}>${roles.map(r=>`<option value="${r}" ${u.role===r?'selected':''}>${r}</option>`).join('')}</select></label>`,
    async()=>{
      const name=v('ue_n').trim(),email=v('ue_e').trim().toLowerCase(),role=v('ue_r')||u.role;
      if(!name)throw Error('اكتب الاسم');
      if(email!==(u.username||'')){await fnCall({action:'update_user',user_id:id,name,email,role})}
      else{await upd('profiles',id,{name,role})}
    },'حفظ التعديل');
}
function userResetPw(id){
  const u=by(window._usersL||[],id);
  formModal('تغيير كلمة السر: '+e(u.name||''),
    `<label class="fm-f"><span>كلمة السر الجديدة (8 حروف على الأقل)</span><input id="rp_1" type="password" autocomplete="new-password"></label><label class="fm-f"><span>تأكيد كلمة السر</span><input id="rp_2" type="password" autocomplete="new-password"></label>`,
    async()=>{const a=v('rp_1'),b=v('rp_2');if(a.length<8)throw Error('كلمة السر لازم تكون 8 حروف على الأقل');if(a!==b)throw Error('كلمتا السر غير متطابقتين');await fnCall({action:'reset_password',user_id:id,password:a});toast('تم تغيير كلمة السر')},
    'تغيير كلمة السر');
}
async function openPermissionEditor(id){
  const r=await rpc('admin_get_user_permissions',{p_user:id});
  if(!r)throw Error('تعذر تحميل الصلاحيات');
  permEditorUser=id;permEditorMode=r.mode||'role';permEditorSet=new Set(Array.isArray(r.permissions)?r.permissions:[]);
  const t=by(window._usersL||[],id);
  showModal(`<div class="card-title"><div><b>صلاحيات: ${e(t.name||'')}</b><div class="muted">الدور الأساسي: ${e(t.role||'')} · التخصيص يضيّق صلاحيات الدور ولا يوسعها.</div></div><span class="chip ${permEditorMode==='custom'?'warning':'success'}">${permEditorMode==='custom'?'مخصص':'حسب الدور'}</span></div>${PERMISSION_GROUPS.map(([title,items])=>`<div class="perm-group"><h4>${title}</h4><div class="perm-grid">${items.map(([pid,label])=>{const allowed=canBaseForRole(t.role,pid);const checked=permEditorSet.has(pid);return `<label class="perm-item ${allowed?'':'disabled'}"><input type="checkbox" ${checked?'checked':''} ${allowed?'':'disabled'} onchange="togglePerm('${pid}',this.checked)"><span>${label}</span>${allowed?'':'<small>خارج الدور</small>'}</label>`}).join('')}</div></div>`).join('')}`,
    `<button class="btn" onclick="savePermissionEditor()">حفظ التخصيص</button><button class="btn soft" onclick="resetPermissionEditor()">إرجاع لصلاحيات الدور</button>`);
}
async function savePermissionEditor(){
  if(!permEditorUser)return;
  await act(async()=>{await rpc('save_user_permissions',{p_user:permEditorUser,p_permissions:[...permEditorSet]});closeModal()});
  toast('تم حفظ الصلاحيات المخصصة');
}
async function resetPermissionEditor(){
  if(!permEditorUser)return;
  await act(async()=>{await rpc('reset_user_permissions',{p_user:permEditorUser});closeModal()});
  toast('تم إرجاع المستخدم لصلاحيات الدور الأساسي');
}

// ---------- سجل العمليات: أقسام (السجل / حركات المخزون) + طباعة لأي يوم ----------
async function auditView(){
  const sec=secCur('aud','log');
  const day=dyGet('aud');const today=cday(new Date());const[a,b]=dayRange(day);
  const from14=new Date(Date.now()-14*86400000).toISOString();
  const[ov,q1,PN]=await Promise.all([sb.from('audit_logs').select('created_at').gte('created_at',from14).limit(5000),sb.from('audit_logs').select('*').gte('created_at',a).lt('created_at',b).order('created_at',{ascending:false}).limit(3000),profNames()]);
  if(ov.error)throw ov.error;if(q1.error)throw q1.error;
  const cnt={};(ov.data||[]).forEach(x=>{const d=cday(x.created_at);cnt[d]=(cnt[d]||0)+1});
  const L=(q1.data||[]).filter(x=>cday(x.created_at)===day);
  const tm=x=>new Date(x.created_at).toLocaleTimeString(locOf(),{hour:'2-digit',minute:'2-digit',timeZone:'Africa/Cairo'});
  const rows=L.map(x=>[tm(x),e(x.user_name||PN[x.user_id]||'—'),e(auAct(x.action)),e(auEnt(x.entity)),e(auDesc(x))]);
  const texts=L.map(x=>[x.user_name||'',auAct(x.action),auEnt(x.entity),auDesc(x)].join(' '));
  const dl=new Date(day+'T12:00:00Z').toLocaleDateString(locOf(),{weekday:'long',day:'numeric',month:'long',year:'numeric',timeZone:'Africa/Cairo'});
  const bar=secBar('aud',[['log','سجل العمليات'],['mv','حركات المخزون']],'log');
  let body;
  if(sec==='mv'){
    const mv=await mvHtml(day,PN);
    body=`<div class="card"><div class="card-title"><b>حركات المخزون — ${e(dl)}</b><button class="s" onclick="ptPrintLS('mv','حركات المخزون — ${e(dl)}')">طباعة هذا اليوم</button></div>${mv}</div>`;
  } else {
    body=`<div class="card"><div class="card-title"><b>عمليات ${e(dl)}</b><div class="row"><span class="chip ${day===today?'info':'success'}">${day===today?'اليوم (مفتوح)':'يوم مقفول'} · ${L.length} عملية</span><button class="s" onclick="ptPrintLS('audit','سجل العمليات — ${e(dl)}')">طباعة هذا اليوم</button></div></div>${lsCard('audit',['الوقت','المستخدم','نوع العملية','الجزء المتأثر','التفاصيل'],rows,texts,'ابحث باسم المستخدم أو نوع العملية أو التفاصيل...')}</div>`;
  }
  return sectionHead('سجل العمليات','كل عملية مسجلة باسم المستخدم والوقت. الأيام السابقة مقفولة للمراجعة.')+
    dayStrip('aud',day,d=>(cnt[d]||0)+' عملية')+bar+body;
}

// ---------- الصفحات الأخرى (المرجع) ----------
async function legacyHtml(){
  if(view==='prod')return productsView(); if(view==='cust')return masterForm('cust'); if(view==='supp')return masterForm('supp');
  if(view==='sales')return (await invoiceView(true)); if(view==='purch')return (await invoiceView(false));
  if(view==='pay')return await payView(); if(view==='trf')return await transferView(); if(view==='stk')return await stocktakeView();
  if(view==='ret')return await retView(); if(view==='quo')return await quotationsView(); if(view==='ord')return await ordersView(); if(view==='stmt')return await stmtView();
  if(view==='exp')return await expensesView();
  if(view==='cash')return await cashView();
  if(view==='emp')return await employeesView(); if(view==='prl')return await payrollView(); if(view==='users')return await usersView(); if(view==='audit')return await auditView(); if(view==='set')return await settingsView();
  return '';
}


/* =====================================================================
   v1.46 — تعريفات لاحقة (الأخيرة تسري)
   ===================================================================== */

// ---------- الأصناف: القائمة لوحدها + إضافة وتعديل في نافذة ----------
function prodNew(){
  formModal('إضافة صنف جديد',
    `<label class="fm-f"><span>الاسم *</span><input id="pn" placeholder="اسم الصنف"></label><label class="fm-f"><span>الكود</span><input id="pc"></label><label class="fm-f"><span>الباركود</span><input id="pbc"></label><label class="fm-f"><span>سعر الشراء</span><input id="pp" type="number"></label><label class="fm-f"><span>سعر البيع</span><input id="ps" type="number"></label><label class="fm-f"><span>سعر الجملة</span><input id="pw" type="number"></label><label class="fm-f"><span>حد إعادة الطلب</span><input id="pm" type="number"></label><label class="fm-f"><span>كمية إعادة الطلب</span><input id="prq" type="number"></label><label class="fm-f"><span>الرصيد الافتتاحي (اختياري)</span><input id="pq" type="number"></label><label class="fm-f"><span>المخزن (للرصيد الافتتاحي)</span><select id="pwh">${O(C.warehouses)}</select></label>`,
    async()=>{
      const nm=v('pn').trim();
      if(!nm)throw Error('اكتب اسم الصنف');
      if(dupProdName(nm))throw Error('يوجد صنف بنفس الاسم بالفعل — عدّل الصنف الموجود بدل إضافة نسخة جديدة');
      const p=await ins('products',{name:nm,code:v('pc')||null,barcode:v('pbc')||null,purchase_price:n('pp'),sale_price:n('ps'),wholesale_price:n('pw'),min_stock:n('pm'),reorder_qty:n('prq'),avg_cost:n('pp')});
      if(n('pq')>0)await rpc('set_opening_stock',{p_prod:p.id,p_wh:v('pwh'),p_qty:n('pq')});
    },'إضافة الصنف');
}
function productsView(){
  const canM=canMaster();
  const rows=C.products.filter(p=>!window._q||[p.name,p.code,p.barcode].join(' ').includes(window._q)).map(p=>[e(p.code),e(p.name),e(p.barcode),fmt(p.avg_cost),fmt(p.sale_price),`<span class="${stkQty(p.id)<=p.min_stock?'bad':''}">${stkQty(p.id)}</span>`,p.active?'مفعّل':'معطل',canM?`<div class="row-btns"><button class="s" onclick="prodEdit('${p.id}')">تعديل</button><button class="s" onclick="act(()=>upd('products','${p.id}',{active:${!p.active}}))">${p.active?'تعطيل':'تفعيل'}</button></div>`:'']);
  return sectionHead('الأصناف','القائمة لوحدها. الإضافة والتعديل من النافذة.')+
    (canM?`<div class="card np"><div class="row"><button onclick="prodNew()">+ إضافة صنف</button></div></div>`:`<div class="card np muted">عرض فقط — إضافة الأصناف وتعديلها متاحة للإدارة والمحاسب والمخزن.</div>`)+
    `<div class="card"><input id="q" placeholder="بحث بالاسم أو الكود أو الباركود" value="${e(window._q||'')}" oninput="qSearch(this)">${T(['الكود','الاسم','الباركود','التكلفة','بيع','المخزون','الحالة',''],rows)}</div>`;
}

// ---------- المرتجعات: نفس شكل المبيعات (إنشاء / السابقة) + طباعة ----------
window.ixMode=window.ixMode||{};
function retRecalc(){
  if(!RT)return;
  let t=0;
  RT.items.forEach((x,i)=>{
    const q=Math.min(Math.max(n('rq'+i),0),Number(x.qty)||0);
    const l=q*Number(x.unit_price||0);t+=l;
    const c=document.getElementById('rt'+i);if(c)c.textContent=fmt(l);
  });
  const el=document.getElementById('retTot');if(el)el.textContent=fmt(t);
}
async function retSave(){
  const cur=RT;if(!cur)return;
  const items=cur.items.map((x,i)=>({product_id:x.product_id,qty:n('rq'+i)})).filter(x=>x.qty>0);
  if(!items.length)return alert('اكتب كمية مرتجع لصنف واحد على الأقل');
  const tbl=cur.s?'sales_returns':'purchase_returns';
  const beforeRes=await sb.from(tbl).select('id').eq('invoice_id',cur.id);
  const before=new Set((beforeRes.data||[]).map(x=>x.id));
  await act(async()=>{await rpc(cur.s?'create_sales_return':'create_purchase_return',{p_invoice:cur.id,p_items:items});RT=null});
  window.ixMode.r='list';
  const afterRes=await sb.from(tbl).select('id').eq('invoice_id',cur.id);
  const fresh=(afterRes.data||[]).find(x=>!before.has(x.id));
  if(fresh&&confirm('تم حفظ المرتجع. تطبعه الآن؟'))retPrint(fresh.id,cur.s);
  R('soft');
}
async function retView(){
  const mode=window.ixMode.r||'hub';
  const sel=window._rk!=='p', title=sel?'مرتجع مبيعات':'مرتجع مشتريات';
  const[SI,PI,RS]=await Promise.all([g('sales_invoices','date'),g('purchase_invoices','date'),g(sel?'sales_returns':'purchase_returns','date')]);
  const L=sel?SI:PI, who=sel?C.customers:C.suppliers;
  const kindSel=`<select id="rk" onchange="window._rk=v('rk');window._rp=null;RT=null;R('soft')"><option value="s" ${sel?'selected':''}>مرتجع مبيعات</option><option value="p" ${sel?'':'selected'}>مرتجع مشتريات</option></select>`;
  if(mode==='list'){
    const rows=RS.slice().reverse().map(x=>{const pn=(by(who,sel?x.customer_id:x.supplier_id).name)||'—';const inv=(by(L,x.invoice_id).number)||'—';return `<tr data-s="${e((x.number+' '+inv+' '+pn+' '+(x.date||'')).toLowerCase())}"><td><b>${e(x.number)}</b></td><td>${e(x.date||'')}</td><td>${e(inv)}</td><td>${e(pn)}</td><td>${fmt(x.total)}</td><td><button class="btn soft sm" onclick="retPrint('${x.id}',${sel})">طباعة</button></td></tr>`}).join('');
    return ixBar('r','المرتجعات السابقة',title)+`<div class="card ix-list"><div class="ix-list-head"><div><b>كل المرتجعات</b><small>${RS.length} مرتجع</small></div><input class="inv-search" type="search" placeholder="ابحث بالرقم أو الاسم أو التاريخ" oninput="invFilter(this.value)"></div><div class="table-wrap"><table class="inv-table"><thead><tr><th>الرقم</th><th>التاريخ</th><th>الفاتورة</th><th>${sel?'العميل':'المورد'}</th><th>الإجمالي</th><th></th></tr></thead><tbody id="invBody">${rows||'<tr><td colspan="6" class="muted">لا توجد مرتجعات بعد</td></tr>'}</tbody></table></div></div>`;
  }
  if(mode==='new'){
    const cur=(RT&&RT.s===sel)?RT:null;
    const pid=window._rp||'',pk=sel?'customer_id':'supplier_id';
    const pOpts=`<option value="">${sel?'اختر العميل':'اختر المورد'}</option>`+who.map(x=>`<option value="${x.id}" ${pid===x.id?'selected':''}>${e(x.name)}</option>`).join('');
    const invList=pid?L.filter(x=>x[pk]===pid):[];
    const invOpts=`<option value="">${pid?(invList.length?'اختر الفاتورة':'لا توجد فواتير لهذا الطرف'):(sel?'اختر العميل الأول':'اختر المورد الأول')}</option>`+invList.slice().reverse().map(x=>`<option value="${x.id}" ${cur&&cur.id===x.id?'selected':''}>${e(x.number)} — ${fmt(x.total)}</option>`).join('');
    const rowsHtml=cur?cur.items.map((x,i)=>`<tr><td class="c-n">${i+1}</td><td><b>${e((by(C.products,x.product_id).name)||'—')}</b></td><td class="c-q">${fmt(x.qty)}</td><td class="c-p">${fmt(x.unit_price)}</td><td class="c-q"><input id="rq${i}" type="number" step="0.001" min="0" value="0" oninput="retRecalc()" style="width:110px"></td><td class="c-t" id="rt${i}">0</td></tr>`).join(''):'<tr><td colspan="6" class="muted">اختار الفاتورة واضغط "عرض البنود".</td></tr>';
    return ixBar('r','إنشاء مرتجع جديد',title)+`<div class="doc">
      <div class="doc-toolbar"><div class="doc-title"><b>${title}</b><span>اكتب الكمية المرتجعة لكل صنف، ثم احفظ</span></div>
        <div class="doc-actions"><button type="button" class="doc-btn primary" onclick="retSave()" ${cur?'':'disabled'}>حفظ المرتجع</button><button type="button" class="doc-btn" onclick="RT=null;R('soft')">تفريغ</button></div></div>
      <div class="doc-head"><div class="df"><span>النوع</span>${kindSel}</div><label class="df">${sel?'العميل':'المورد'}<select id="rp" onchange="window._rp=v('rp');RT=null;R('soft')">${pOpts}</select></label><label class="df wide">الفاتورة<select id="ri">${invOpts}</select></label><div class="df"><span>&nbsp;</span><button type="button" class="doc-btn" onclick="loadRet()">عرض البنود</button></div></div>
      <div class="doc-grid-wrap"><table class="doc-tbl"><thead><tr><th class="c-n">#</th><th>الصنف</th><th class="c-q">الكمية بالفاتورة</th><th class="c-p">السعر</th><th class="c-q">كمية المرتجع</th><th class="c-t">التقدير</th></tr></thead><tbody id="retRows">${rowsHtml}</tbody></table></div>
      <div class="doc-foot"><span class="doc-count">${cur?cur.items.length+' بند':''}</span><div class="doc-totals"><div class="tl big"><span>تقدير قيمة المرتجع</span><b id="retTot">0</b></div></div></div>
      <p class="muted">التقدير بيحسب بالسعر قبل الضريبة والخصم. القيمة النهائية بتتحسب على السيرفر عند الحفظ.</p></div>`;
  }
  // الرئيسية للمرتجعات
  const tile=(cls,m,ico,t,sub)=>`<button type="button" class="ix-tile ${cls}" onclick="ixSetMode('r','${m}')"><span class="ix-ico">${ico}</span><b>${t}</b><small>${sub}</small></button>`;
  return sectionHead('المرتجعات','إنشاء مرتجع لفاتورة مبيعات أو مشتريات، ومتابعة المرتجعات السابقة وطباعتها.')+
    `<div class="card np">${kindSel}</div><div class="ix-hub">${tile('new','new','+','إنشاء مرتجع جديد',sel?'مرتجع من فاتورة بيع':'مرتجع من فاتورة شراء')}${tile('','list','≡','المرتجعات السابقة',`${RS.length} مرتجع · اطبع أي مرتجع`)}</div>`;
}

// ---------- العمولات: اسم البائع وقاعدة العمولة واضحين ----------
async function commissionView(){
  const sec=secCur('comm','rules');
  const[RL,I,Cm,PN]=await Promise.all([g('commission_rules','name'),g('sales_invoices','date'),g('sales_commissions','created_at'),profNames()]);
  const bar=secBar('comm',[['rules','قواعد العمولة'],['calc','حساب عمولة'],['list','العمولات المسجلة']],'rules');
  let body='';
  if(sec==='rules') body=`<div class="card form-card"><div class="card-title"><b>قاعدة عمولة جديدة</b></div><div class="row"><input id="crn" placeholder="اسم القاعدة"><input id="crr" type="number" step="0.0001" placeholder="النسبة %"><select id="crb"><option value="net_sales">صافي المبيعات</option><option value="gross_profit">مجمل الربح</option></select><button class="btn" onclick="act(()=>rpc('create_commission_rule',{p_name:v('crn'),p_rate:n('crr'),p_basis:v('crb')}))">إضافة القاعدة</button></div></div><div class="card">${T(['القاعدة','النسبة %','الأساس'],RL.map(x=>[e(x.name),x.rate,x.basis==='gross_profit'?'مجمل الربح':'صافي المبيعات']))}</div>`;
  else if(sec==='calc') body=`<div class="card form-card"><div class="card-title"><b>حساب عمولة فاتورة</b><span class="muted">العمولة بتتسجل باسم بائع الفاتورة (المستخدم اللي أنشأها).</span></div><div class="row"><select id="cri">${I.filter(x=>x.status==='Posted').map(x=>`<option value="${x.id}">${e(x.number)} — البائع: ${e(PN[x.salesperson]||'غير محدد')} — ${fmt(x.total)}</option>`).join('')}</select><select id="crr2">${O(RL)}</select><button class="btn" onclick="act(()=>rpc('calculate_sales_commission',{p_invoice:v('cri'),p_rule:v('crr2')}))">حساب وتسجيل العمولة</button></div></div>`;
  else body=`<div class="card"><p class="muted">كل سطر: الفاتورة، وبائعها اللي العمولة ليه، والقاعدة المستخدمة، والمبلغ. لو ظهر "غير محدد" يبقى الفاتورة من غير بائع.</p>${T(['الفاتورة','البائع (صاحب العمولة)','القاعدة','الأساس','العمولة','الحالة'],Cm.map(x=>{const inv=by(I,x.invoice_id);return [e(inv.number||'—'),e(PN[x.salesperson_id]||'غير محدد'),e((by(RL,x.rule_id).name)||'—'),fmt(x.basis_amount),fmt(x.amount),chip(x.status||'مسجلة',x.status==='Paid'?'success':'warning')]}))}</div>`;
  return sectionHead('العمولات','عمولات البائعين: القواعد، الحساب، والسجل.')+bar+body;
}

// ---------- الأصول: حساب الدفع يتحول لكود الحساب المحاسبي ----------
function glOf(id){return (by(C.accts,id).type==='bank')?'1100':'1000'}
function assetNew(){
  formModal('أصل ثابت جديد',
    `<label class="fm-f"><span>اسم الأصل</span><input id="afn"></label><label class="fm-f"><span>التصنيف</span><select id="afc">${O(window._assetCats||[])}</select></label><label class="fm-f"><span>التكلفة</span><input id="afcost" type="number"></label><label class="fm-f"><span>القيمة المتبقية</span><input id="afres" type="number" value="0"></label><label class="fm-f"><span>العمر بالشهور</span><input id="aflife" type="number" value="60"></label><label class="fm-f"><span>دفعنا منين (الخزينة أو البنك)</span><select id="afacct">${O(C.accts)}</select></label>`,
    async()=>{
      if(!v('afc'))throw Error('أضف تصنيف أصل الأول من تبويب التصنيفات');
      const id=await rpc('create_fixed_asset',{p_name:v('afn'),p_category:v('afc'),p_cost:n('afcost'),p_residual:n('afres'),p_life_months:n('aflife'),p_purchase_date:new Date().toISOString().slice(0,10),p_branch:null});
      await rpc('capitalize_fixed_asset',{p_asset:id,p_credit_account:glOf(v('afacct'))});
    },'إضافة وتسجيل');
}

// ---------- المصروفات: خانة تفاصيل + طباعة اليوم ----------
async function expensesView(){
  const L=await g('expenses','date');
  const day=dyGet('exp');
  const sumOf=d=>L.filter(x=>x.date===d).reduce((a,x)=>a+Number(x.amount||0),0);
  const rowsDay=L.filter(x=>x.date===day).reverse();
  const tot=rowsDay.reduce((a,x)=>a+Number(x.amount||0),0);
  const acctName=id=>(by(C.accts,id).name)||'—';
  const cells=rowsDay.map(x=>[e(x.category||''),e(x.description||'—'),e(x.notes||'—'),money(x.amount),e(acctName(x.account_id))]);
  const dl=new Date(day+'T12:00:00Z').toLocaleDateString(locOf(),{weekday:'long',day:'numeric',month:'long',year:'numeric',timeZone:'Africa/Cairo'});
  ptStore('exp','مصروفات '+dl,'',['التصنيف','الوصف','التفاصيل','المبلغ','الحساب'],rowsDay.map(x=>[e(x.category||''),e(x.description||'—'),e(x.notes||'—'),fmt(x.amount),e(acctName(x.account_id))]),`<p class="tot">الإجمالي: ${fmt(tot)}</p>`);
  return sectionHead('المصروفات','المصروف بيتسجل بتاريخ اليوم. الأيام السابقة للعرض والطباعة.')+
    `<div class="card form-card"><div class="card-title"><b>تسجيل مصروف (اليوم)</b></div>
      <div class="row"><select id="ec"><option>إيجار</option><option>كهرباء</option><option>مياه</option><option>إنترنت</option><option>رواتب</option><option>نقل</option><option>صيانة</option><option>تسويق</option><option>أخرى</option></select><input id="ed" placeholder="الوصف (مثال: فاتورة كهرباء)"><input id="ea" type="number" placeholder="المبلغ"><select id="ex">${O(C.accts)}</select></div>
      <textarea id="en" rows="2" placeholder="تفاصيل إضافية (اختياري): مين اتدفعله، رقم الفاتورة، ملاحظات" style="width:100%;margin-top:10px"></textarea>
      <div class="row" style="margin-top:10px"><button class="btn" onclick="act(()=>rpc('create_expense',{p_category:v('ec'),p_desc:v('ed')||null,p_amount:n('ea'),p_account:v('ex'),p_notes:v('en')||null}))">حفظ المصروف</button></div></div>`+
    dayStrip('exp',day,d=>fmt(sumOf(d)))+
    `<div class="card"><div class="card-title"><b>مصروفات ${e(dl)}</b><div class="row"><span class="chip info">الإجمالي ${fmt(tot)}</span><button class="btn" onclick="ptPrint('exp')">${ico('printer')} طباعة مصروفات هذا اليوم</button></div></div>${T(['التصنيف','الوصف','التفاصيل','المبلغ','الحساب'],cells)}</div>`;
}

// ---------- الخزينة: أسماء المصادر (بما فيها الحركات القديمة المرحّلة) ----------
Object.assign(LEDGER_SRC,{record_initial_payment:'دفعة مع فاتورة',backfill_payment:'دفعة (قبل التحديث)',backfill_expense:'مصروف (قبل التحديث)',backfill_transfer:'تحويل (قبل التحديث)',backfill_payroll:'مرتب (قبل التحديث)'});


// ---------- v1.47: تسجيل الدخول، القائمة الجانبية، أرصدة الخزينة، المرتجع بالعميل ----------
// 1) الدخول: رسالة واضحة لو البيانات غلط أو في مشكلة اتصال
function loginMsg(t){let el=document.getElementById('lerr');if(!el){el=document.createElement('div');el.id='lerr';el.setAttribute('role','alert');el.style.cssText='color:var(--red);background:var(--danger-bg);border:1px solid #B93A2F;border-radius:12px;padding:10px 12px;margin-top:12px;font-size:13px;font-weight:700';document.querySelector('.lg-card')?.appendChild(el)}el.textContent=t||'';el.hidden=!t}
async function login(){
  const email=(v('lu')||'').trim(),pass=v('lp')||'';
  loginMsg('');
  if(!email||!pass)return loginMsg('اكتب البريد الإلكتروني وكلمة المرور');
  try{
    await withLoading(async()=>{await signInWithIdentifier(email,pass);clearDataCache();location.reload()},'جاري تسجيل الدخول...','جارٍ الاتصال بالنظام بأمان');
  }catch(x){
    const m=String(x?.message||x?.error_description||x||'');
    if(/invalid login|invalid_credentials|invalid.*(credential|password)/i.test(m))return loginMsg('البريد الإلكتروني أو كلمة المرور غلط');
    if(/email not confirmed/i.test(m))return loginMsg('الحساب لسه متفعلش. كلم الأدمن');
    if(/fetch|network|failed to/i.test(m))return loginMsg('مفيش اتصال بالسيرفر. اتأكد من الإنترنت وحاول تاني');
    loginMsg('تعذر تسجيل الدخول: '+m);
  }
}
document.addEventListener('keydown',ev=>{if(ev.key==='Enter'&&(ev.target?.id==='lu'||ev.target?.id==='lp')&&document.getElementById('lp'))login()});

// 2) القائمة الجانبية: تتحدّث فوراً بدون إعادة تحميل كل البيانات
function navPaintNow(){const l=renderNavGroups();const nv=$('nav');if(nv){nv.innerHTML=l;window._lastLinks=l}const mb=$('.mobile-bottom');if(mb)mb.innerHTML=bottomNav()}
function navGo(){if(C&&me&&me.active&&can(view)){const stale=Date.now()-(window._lastLoad||0)>=60000;const p=paintView('soft');if(stale)loadAll(true).then(()=>paintView('soft')).catch(()=>{});return p}return R('soft')}
function go(vw){window.ixMode={};if(vw!==view){window._nav=window._nav||[];window._nav.push(view);if(window._nav.length>20)window._nav.shift()}view=vw;localStorage.setItem('erp_v_view',vw);closeMobileNav?.();navPaintNow();showPlaceholder();return navGo()}
function goBack(){const p=(window._nav||[]).pop();if(!p)return;view=p;localStorage.setItem('erp_v_view',p);closeMobileNav?.();navPaintNow();showPlaceholder();return navGo()}
function toggleNavGroup(gid,ev){ev.preventDefault();ev.stopPropagation();let state={};try{state=JSON.parse(localStorage.getItem('erp_v_nav_groups')||'{}')}catch{};const open=state[gid]===false?true:state[gid]===undefined?true:false;Object.keys(state).forEach(k=>{state[k]=false});state[gid]=open;localStorage.setItem('erp_v_nav_groups',JSON.stringify(state));navPaintNow()}

// 3) الخزينة: الرصيد الافتتاحي والختامي لكل حساب ولكل يوم
// بداية اليوم بتوقيت القاهرة (بتحسب الصيف والشتا)
function cairoDayStart(day){const base=Date.parse(day+'T00:00:00Z');for(const off of [-2,-3,-1]){const t=base+off*3600e3;if(cday(t)===day&&cday(t-1)!==day)return new Date(t).toISOString()}return new Date(base-2*3600e3).toISOString()}
function nextDayKey(day){return new Date(Date.parse(day+'T12:00:00Z')+86400e3).toISOString().slice(0,10)}
async function cashLedgerHtml(){
  const day=dyGet('led');
  const a=cairoDayStart(day),b=cairoDayStart(nextDayKey(day));
  const[res,PN,obRows,cbRows]=await Promise.all([
    sb.from('cash_movements').select('*').gte('created_at',a).lt('created_at',b).order('created_at',{ascending:false}).limit(3000),
    profNames(),rpc('cash_balances_at',{p_ts:a}),rpc('cash_balances_at',{p_ts:b})]);
  if(res.error)throw res.error;
  const L=res.data||[];
  const OB=Object.fromEntries((obRows||[]).map(x=>[x.account_id,+x.balance]));
  const CB=Object.fromEntries((cbRows||[]).map(x=>[x.account_id,+x.balance]));
  const an=id=>(by(C.accts,id).name)||'—';
  let tin=0,tout=0;L.forEach(x=>{if(x.direction==='in')tin+=+x.amount;else tout+=+x.amount});
  const tm=x=>new Date(x.created_at).toLocaleTimeString(locOf(),{hour:'2-digit',minute:'2-digit',timeZone:'Africa/Cairo'});
  const dl=new Date(day+'T12:00:00Z').toLocaleDateString(locOf(),{weekday:'long',day:'numeric',month:'long',year:'numeric',timeZone:'Africa/Cairo'});
  // جدول الأرصدة لكل حساب
  const per=C.accts.map(acc=>{
    const mv=L.filter(x=>x.account_id===acc.id);
    const inn=mv.filter(x=>x.direction==='in').reduce((s,x)=>s+ +x.amount,0);
    const out=mv.filter(x=>x.direction!=='in').reduce((s,x)=>s+ +x.amount,0);
    const open=OB[acc.id]??0, close=CB[acc.id]??+acc.balance;
    return {acc,open,inn,out,close,diff:Math.round((close-(open+inn-out))*100)/100};
  });
  const sum=k=>per.reduce((s,r)=>s+r[k],0);
  const balRows=per.map(r=>[e(r.acc.name),fmt(r.open),`<span class="good">${fmt(r.inn)}</span>`,`<span class="bad">${fmt(r.out)}</span>`,`<b>${fmt(r.close)}</b>`,Math.abs(r.diff)>0.005?`<span class="bad" title="حركات قبل تسجيل الحركات في النظام">${fmt(r.diff)}</span>`:'<span class="muted">—</span>']);
  const balHead=['الحساب','الرصيد الافتتاحي','داخل','خارج','الرصيد الختامي (المقفول)','فرق غير مسجل'];
  balRows.push([`<b>الإجمالي</b>`,`<b>${fmt(sum('open'))}</b>`,`<b>${fmt(sum('inn'))}</b>`,`<b>${fmt(sum('out'))}</b>`,`<b>${fmt(sum('close'))}</b>`,'']);
  const balHtml=T(balHead,balRows);
  const rows=L.map(x=>[tm(x),e(an(x.account_id)),x.direction==='in'?'<span class="good">داخل ＋</span>':'<span class="bad">خارج −</span>',fmt(x.amount),e(LEDGER_SRC[x.source]||x.source||'—'),e(PN[x.user_id]||'—')]);
  const texts=L.map(x=>[an(x.account_id),LEDGER_SRC[x.source]||x.source||'',PN[x.user_id]||'',x.direction==='in'?'داخل':'خارج'].join(' '));
  ptStore('led','حركة الخزينة — '+dl,'',['الوقت','الحساب','الاتجاه','المبلغ','المصدر','المستخدم'],L.map(x=>[tm(x),e(an(x.account_id)),x.direction==='in'?'داخل':'خارج',fmt(x.amount),e(LEDGER_SRC[x.source]||x.source||'—'),e(PN[x.user_id]||'—')]),`<h3>أرصدة الحسابات</h3>${balHtml}<p class="tot">داخل: ${fmt(tin)} · خارج: ${fmt(tout)} · الصافي: ${fmt(tin-tout)}</p>`);
  return `${dayStrip('led',day)}<div class="card"><div class="card-title"><b>أرصدة ${e(dl)}</b><span class="muted">الافتتاحي = الرصيد أول اليوم، والختامي = الرصيد اللي اتقفل بيه اليوم</span></div>${balHtml}</div>`+
    `<div class="card"><div class="card-title"><b>حركة ${e(dl)}</b><div class="row"><span class="chip success">داخل ${fmt(tin)}</span><span class="chip danger">خارج ${fmt(tout)}</span><span class="chip info">الصافي ${fmt(tin-tout)}</span><button class="s" onclick="ptPrint('led')">طباعة هذا اليوم</button></div></div>${lsCard('led',['الوقت','الحساب','الاتجاه','المبلغ','المصدر','المستخدم'],rows,texts,'ابحث بالحساب أو المصدر أو المستخدم...')}</div>`;
}

// 4) المرتجع بيتعمل من اختيار العميل (أو المورد) الأول، وبعدين الفاتورة بتاعته


// ---------- v1.49: لوجو الشركة في الإعدادات والطباعة ----------
async function uploadCoLogo(input){
  const f=input.files&&input.files[0];
  input.value='';
  if(!f)return;
  if(!['image/png','image/jpeg','image/webp'].includes(f.type))return alert('الصورة لازم تكون PNG أو JPG أو WebP');
  if(f.size>512*1024)return alert('حجم اللوجو لازم يكون أقل من 512 كيلو');
  await act(async()=>{
    const ext=f.type==='image/png'?'png':f.type==='image/webp'?'webp':'jpg';
    const path='logo-'+Date.now()+'.'+ext;
    const up=await sb.storage.from('company-assets').upload(path,f,{contentType:f.type,upsert:false});
    if(up.error)throw up.error;
    const url=sb.storage.from('company-assets').getPublicUrl(path).data.publicUrl;
    await upd('company_settings',1,{logo_url:url});
    window._coLogo=url;if(window._co)window._co.logo_url=url;
  });
}
async function refreshCo(){
  try{const r=await g('company_settings');window._co=r[0]||{};window._coLogo=window._co.logo_url||'';window._coName=window._co.company_name||''}catch(_){}
}
// إعدادات الطباعة (التخصيص الجاي هيكون من الإعدادات): إظهار اللوجو والاسم والعنوان، حجم اللوجو، لون الخط الفاصل
const PRINT_CFG={showLogo:true,showName:true,showAddress:true,logoMaxH:60,accent:'#095F4A'};
// هيدر الطباعة الموحد: اللوجو + اسم الشركة + العنوان والرقم الضريبي
function brandHtml(){
  const c=window._co||{},cfg=printCfg();
  const logo=cfg.showLogo&&c.logo_url?`<img src="${e(c.logo_url)}" alt="" style="max-height:${cfg.logoMaxH}px;max-width:220px;display:block">`:'';
  const name=cfg.showName&&c.company_name?`<b style="font-size:17px;color:#101C2C">${e(c.company_name)}</b>`:'';
  const addr=cfg.showAddress?[c.address?e(c.address):'',c.tax_number?'الرقم الضريبي: '+e(c.tax_number):''].filter(Boolean).join(' · '):'';
  if(!logo&&!name)return '';
  return `<div class="print-brand" style="display:flex;justify-content:${pcJustify(cfg)};align-items:center;gap:12px;border-bottom:2px solid ${cfg.accent};padding-bottom:10px;margin-bottom:14px">${logo}<div>${name}${addr?`<div style="color:#5B6878;font-size:12px;margin-top:2px">${addr}</div>`:''}</div></div>`;
}
// كل الطباعة بتاخد الهيدر تلقائياً (opts.brand=false لو التصميم فيه هيدره الخاص)
const _printHtml0=printHtml;
printHtml=function(title,body,opts){
  const head=(opts&&opts.brand===false)?'':brandHtml();
  const foot=(opts&&opts.brand===false)?'':((printCfg().footer?`<div style="margin-top:18px;padding-top:8px;border-top:1px solid #E3E0D4;color:#5B6878;font-size:11px;text-align:center">${e(printCfg().footer)}</div>`:'')+vendorCreditHtml());
  return _printHtml0(title,head+body+foot);
};
const _boot0=boot;
boot=async function(){await _boot0();refreshCo()};


// ---------- v1.50: الأطراف الموحدة (عميل ومورد في سجل واحد) ----------
const PT_TABS=[['all','الكل'],['owe','مستحق لنا'],['owed','مستحق علينا']];
function ptNet(x){const n0=+x.net||0;if(Math.abs(n0)<0.005)return '<span class="muted">متصفّر</span>';return n0>0?`<span class="good">مستحق لنا ${fmt(n0)}</span>`:`<span class="bad">مستحق علينا ${fmt(-n0)}</span>`}
// كل طرف عميل ومورد في نفس الوقت: مفيش اختيار دور، ورصيده واحد صافي
async function partiesView(){
  const tab=secCur('pt','all');
  const bar=secBar('pt',PT_TABS,'all');
  const B=await g('party_balances','name');
  const L=B.filter(x=>{const n0=+x.net||0;return tab==='owe'?n0>0.005:tab==='owed'?n0<-0.005:true});
  const sumR=B.reduce((t,x)=>t+(+x.receivable||0),0), sumP=B.reduce((t,x)=>t+(+x.payable||0),0);
  const rows=L.map(x=>{
    const acts=[`<button class="s" onclick="partyEdit('${x.party_id}')">تعديل</button>`];
    if(x.customer_id)acts.push(`<button class="s" onclick="partyStmt('${x.party_id}')">كشف الحساب</button>`);
    acts.push(`<button class="s" onclick="act(()=>rpc('set_party_active',{p_party:'${x.party_id}',p_on:${x.active?'false':'true'}}))">${x.active?'تعطيل':'تفعيل'}</button>`);
    return `<tr data-s="${e((x.name+' '+(x.phone||'')+' '+(x.email||'')).toLowerCase())}"><td><span class="tk-l">الطرف</span><span class="tk-v"><b>${e(x.name)}</b>${x.phone?`<br><small class="muted">${e(x.phone)}</small>`:''}</span></td><td><span class="tk-l">مستحق لنا</span><span class="tk-v">${fmt(x.receivable)}</span></td><td><span class="tk-l">مستحق علينا</span><span class="tk-v">${fmt(x.payable)}</span></td><td><span class="tk-l">الصافي</span><span class="tk-v">${ptNet(x)}</span></td><td><span class="tk-l">الحالة</span><span class="tk-v">${x.active?chip('مفعّل','success'):chip('موقوف','warning')}</span></td><td class="pt-acts"><div class="row-btns">${acts.join(' ')}</div></td></tr>`;
  }).join('');
  const canNew=me&&['admin','accountant','sales','store'].includes(me.role);
  const form=canNew?`<div class="card form-card"><div class="card-title"><b>طرف جديد</b><span class="muted">الطرف بيتسجل مقبوضات ومدفوعات مع بعض، برصيد واحد صافي.</span></div>
    <div class="row"><input id="pn" placeholder="الاسم"><input id="pp" placeholder="الهاتف"><input id="pe" type="email" placeholder="البريد"><input id="pa" placeholder="العنوان"><input id="ptx" placeholder="الرقم الضريبي"></div>
    <div class="row"><input id="pcl" type="number" placeholder="حد الائتمان"><input id="pct" type="number" placeholder="مدة السداد بالأيام"><input id="pco" type="number" placeholder="رصيد افتتاحي (+ مستحق لنا / - مستحق علينا)"><button onclick="partyNew()">إضافة الطرف</button></div></div>`:'';
  return sectionHead('الأطراف','كل طرف عميل ومورد في نفس الوقت، برصيد صافي واحد.')+form+
    `<div class="party-stats"><div><small>إجمالي مستحق لنا</small><b class="good">${fmt(sumR)}</b></div><div><small>إجمالي مستحق علينا</small><b class="bad">${fmt(sumP)}</b></div><div><small>الصافي</small><b>${fmt(sumR-sumP)}</b></div></div>
    <div class="card np">${bar}<input class="inv-search" type="search" placeholder="بحث بالاسم أو الهاتف أو البريد" oninput="invFilter(this.value)" style="margin-top:8px"></div>
    <div class="card"><div class="table-wrap tw-stack"><table class="inv-table"><thead><tr><th>الطرف</th><th>مستحق لنا</th><th>مستحق علينا</th><th>الصافي</th><th>الحالة</th><th></th></tr></thead><tbody id="invBody">${rows||'<tr><td colspan="6" class="muted">لا توجد أطراف في هذا التبويب</td></tr>'}</tbody></table></div></div>`;
}
async function partyNew(){
  if(!v('pn').trim())return alert('اكتب اسم الطرف');
  const terms=parseInt(v('pct'))||0;
  await act(()=>rpc('create_party',{p_name:v('pn').trim(),p_phone:v('pp'),p_email:v('pe'),p_address:v('pa'),p_tax:v('ptx'),p_notes:null,p_roles:null,p_credit_limit:n('pcl'),p_customer_terms:terms,p_customer_opening:n('pco'),p_supplier_terms:terms,p_supplier_opening:0}));
}
async function partyEdit(id){
  const[P,cu,su]=await Promise.all([
    sb.from('parties').select('*').eq('id',id).single().then(r=>{if(r.error)throw r.error;return r.data}),
    sb.from('customers').select('credit_limit,payment_terms_days').eq('party_id',id).maybeSingle().then(r=>r.data),
    sb.from('suppliers').select('payment_terms_days').eq('party_id',id).maybeSingle().then(r=>r.data)]);
  const f=(lbl,id2,val,type='text')=>`<label class="fm-f"><span>${lbl}</span><input id="${id2}" type="${type}" value="${e(val??'')}"></label>`;
  const fields=f('الاسم','ep_n',P.name)+f('الهاتف','ep_p',P.phone)+f('البريد','ep_e',P.email,'email')+f('العنوان','ep_a',P.address)+f('الرقم الضريبي','ep_t',P.tax_number)+f('ملاحظات','ep_no',P.notes)+
    (cu?f('حد الائتمان (عميل)','ep_cl',cu.credit_limit,'number')+f('مدة السداد (عميل) بالأيام','ep_ct',cu.payment_terms_days,'number'):'')+
    (su?f('مدة السداد (مورد) بالأيام','ep_st',su.payment_terms_days,'number'):'');
  formModal('تعديل الطرف: '+e(P.name),fields,async()=>{
    await rpc('update_party',{p_party:id,p_name:v('ep_n'),p_phone:v('ep_p'),p_email:v('ep_e'),p_address:v('ep_a'),p_tax:v('ep_t'),p_notes:v('ep_no'),
      p_credit_limit:cu?n('ep_cl'):null,p_customer_terms:cu?(parseInt(v('ep_ct'))||0):null,p_supplier_terms:su?(parseInt(v('ep_st'))||0):null});
  },'حفظ');
}
// مدخل الأطراف من القائمة (العملاء والموردين) — الموردين بيفتحوا تبويب الموردين
const _legacy1=legacyHtml;
legacyHtml=async function(){
  if(view==='cust'||view==='supp'){if(view==='supp'){window._sec=window._sec||{};window._sec.pt='all'}return partiesView()}
  return _legacy1()
};

// ===== v1.51 =====
// بطاقة إعدادات الشركة (تصميم منظم: هوية، بيانات، ضريبة ومخزون، خصم)
function coCardHtml(s){
  const adm=me.role==='admin';const dis=adm?'':' disabled';
  const swt=(id,on,lbl,hint)=>`<label class="co-switch"><input type="checkbox" id="${id}" ${on?'checked':''}${dis}><span><b>${lbl}</b>${hint?`<small>${hint}</small>`:''}</span></label>`;
  return `<div class="card co-card">
    <div class="co-head">
      <div class="co-logo">${s.logo_url?'':'<span class="co-logo-empty">'+e((s.company_name||'ش').slice(0,1))+'</span>'}<img id="coLogoPv" src="${e(s.logo_url||'')}" alt="لوجو الشركة" style="${s.logo_url?'':'display:none'}"></div>
      <div class="co-title"><b>${e(s.company_name||'الشركة')}</b><small class="muted">بيانات الفواتير والضريبة والمخزون</small></div>
      ${adm?`<label class="btn soft sm">رفع لوجو<input type="file" accept="image/png,image/jpeg,image/webp" style="display:none" onchange="uploadCoLogo(this)"></label>`:''}
    </div>
    <div class="co-sec"><h4>البيانات الأساسية</h4>
      <div class="fm-grid">
        <label class="fm-f"><span>اسم الشركة</span><input id="sc" value="${e(s.company_name)}"${dis}></label>
        <label class="fm-f"><span>بادئة فاتورة البيع</span><input id="sp_s" value="${e(s.prefix_sales)}"${dis}></label>
        <label class="fm-f"><span>بادئة فاتورة الشراء</span><input id="sp_p" value="${e(s.prefix_purchase)}"${dis}></label>
        <label class="fm-f"><span>بادئة مرتجع البيع</span><input id="sp_sr" value="${e(s.prefix_sales_return)}"${dis}></label>
        <label class="fm-f"><span>بادئة مرتجع الشراء</span><input id="sp_pr" value="${e(s.prefix_purchase_return)}"${dis}></label>
        <label class="fm-f"><span>الرقم الضريبي</span><input id="stn" value="${e(s.tax_number)}"${dis}></label>
      </div></div>
    <div class="co-sec"><h4>الضريبة والمخزون</h4>
      <div class="co-switches">${swt('ste',s.tax_enabled,'تفعيل الضريبة')}${swt('sn',s.negative_stock,'السماح بالمخزون السالب')}</div>
      <div class="fm-grid"><label class="fm-f"><span>نسبة الضريبة %</span><input id="sx" type="number" value="${s.tax_pct}"${dis}></label></div></div>
    <div class="co-sec"><h4>حد الخصم</h4>
      <div class="fm-grid"><label class="fm-f"><span>أقصى خصم على الفاتورة %</span><input id="sdm" type="number" step="0.01" min="0" max="100" value="${s.sales_discount_max_pct??5}"${dis}></label></div>
      <small class="muted">بيتطبق على دور المبيعات كنسبة من إجمالي الأصناف. الأدمن والمحاسب مالهمش حد.</small></div>
    <div class="co-foot"><small class="muted">اللوجو بيظهر في الفواتير والمرتجعات والطباعة. PNG أو JPG أو WebP أقل من 512 كيلو.</small>
      ${adm?`<button onclick="saveCoSettings()">حفظ الإعدادات</button>`:''}</div>
  </div>`;
}
function saveCoSettings(){return act(async()=>{await upd('company_settings',1,{company_name:v('sc'),prefix_sales:v('sp_s'),prefix_purchase:v('sp_p'),prefix_sales_return:v('sp_sr'),prefix_purchase_return:v('sp_pr'),tax_number:v('stn'),negative_stock:$('#sn').checked,tax_enabled:$('#ste').checked,tax_pct:n('sx'),sales_discount_max_pct:n('sdm')});await refreshCo()})}

// ----- تحديث التطبيق لكل المستخدمين -----
const APP_SEEN_KEY='erp_refresh_seen';
async function pushAppUpdate(){
  if(!confirm('نبعت تحديث لكل المستخدمين؟ أي حد فاتح النظام هيتحدث أوتوماتيك.'))return;
  try{
    const t=await rpc('dev_push_refresh',{});
    try{localStorage.setItem(APP_SEEN_KEY,String(t))}catch{}
    alert('تم إرسال التحديث. المستخدمين هيتحدثوا خلال دقيقة تقريباً (أول ما يفتحوا أو يرجعوا للصفحة).');
  }catch(x){alert('تعذر إرسال التحديث: '+(x.message||x))}
}
async function forceAppReload(t){
  try{localStorage.setItem(APP_SEEN_KEY,String(t))}catch{}
  try{
    if('serviceWorker' in navigator){const rs=await navigator.serviceWorker.getRegistrations();await Promise.all(rs.map(r=>r.unregister()))}
    if(window.caches){const ks=await caches.keys();await Promise.all(ks.map(k=>caches.delete(k)))}
  }catch{}
  location.reload();
}
async function checkAppRefresh(){
  try{
    const t=String(await rpc('app_version',{})||'');
    if(!t)return;
    let seen=null;try{seen=localStorage.getItem(APP_SEEN_KEY)}catch{}
    if(seen===null){try{localStorage.setItem(APP_SEEN_KEY,t)}catch{}return}
    if(seen!==t){
      if(document.getElementById('modalBg'))return; // ما نقفلش نافذة مفتوحة، نحاول تاني بعدين
      await forceAppReload(t);
    }
  }catch{}
}
setTimeout(checkAppRefresh,4000);
setInterval(checkAppRefresh,120000);
document.addEventListener('visibilitychange',()=>{if(!document.hidden)checkAppRefresh()});

// ----- الحضور الذاتي: الموظف يسجل حضوره وانصرافه بنفسه -----
async function attSelfHtml(){
  return ''; // الحضور للأدمن بس: الكارت الذاتي اتقفل
  if(!me)return '';
  const{data:emp}=await sb.from('employees').select('id,name').eq('user_id',me.id).maybeSingle();
  if(!emp)return '';
  const today=cday(new Date());
  const{data:rec}=await sb.from('attendance').select('*').eq('employee_id',emp.id).eq('work_date',today).maybeSingle();
  const tm=t=>t?new Date(t).toLocaleTimeString(locOf(),{timeZone:'Africa/Cairo',hour:'2-digit',minute:'2-digit'}):'—';
  const canIn=!rec||!rec.check_in, canOut=!!(rec&&rec.check_in&&!rec.check_out);
  return `<div class="card att-self"><div class="card-title"><b>حضوري النهارده: ${e(emp.name)}</b><span class="muted">${today}</span></div>
    <div class="att-self-row"><div><small class="muted">الحضور</small><b>${tm(rec?.check_in)}</b></div><div><small class="muted">الانصراف</small><b>${tm(rec?.check_out)}</b></div>
    <button ${canIn?'':'disabled'} onclick="attSelf('in')">تسجيل حضور</button><button class="soft" ${canOut?'':'disabled'} onclick="attSelf('out')">تسجيل انصراف</button></div></div>`;
}
function attSelf(a){return act(()=>rpc('attendance_check',{p_action:a}))}
const _hrBaseV151=hrView;
hrView=async function(){const h=await _hrBaseV151();let s='';try{s=await attSelfHtml()}catch{}return s+h};

// كشف حساب الطرف الواحد: عميل ومورد في كشف واحد، برصيد صافي
// كشف الحساب: بحث عن الطرف (عميل ومورد في كشف واحد)
async function stmtView(){
  const P=await g('party_balances','name');
  window._PL=P;
  const cur=P.find(x=>x.party_id===window._stp)||null;
  return `<h2>كشف الحساب</h2><div class="card np stmt-bar">
    <div class="fm-f stmt-search"><span>ابحث عن الطرف</span><input id="sq3" type="search" placeholder="اكتب الاسم أو رقم الهاتف" autocomplete="off" value="${cur?e(cur.name):''}" oninput="ptStSearch(this.value)"><div id="stRes3" class="stmt-res"></div></div>
    <label class="fm-f"><span>من تاريخ</span><input type="date" id="sa" value="${e(window._sa||'')}"></label>
    <label class="fm-f"><span>إلى تاريخ</span><input type="date" id="sb2" value="${e(window._sb||'')}"></label>
    <div class="stmt-btns"><button onclick="showPartyStmt()">عرض الكشف</button><button class="s" onclick="printStmt()">طباعة / PDF</button></div>
  </div><div class="card stmt-out">${st||'ابحث واختار الطرف، وحدد الفترة (اختياري)، واضغط عرض الكشف'}</div>`;
}
function ptStSearch(q){
  const box=document.getElementById('stRes3');if(!box)return;
  q=(q||'').trim().toLowerCase();
  if(!q){box.innerHTML='';return}
  const L=(window._PL||[]).filter(x=>(x.name+' '+(x.phone||'')).toLowerCase().includes(q)).slice(0,8);
  box.innerHTML=L.map(x=>`<button type="button" class="stmt-opt" onclick="pickParty('${x.party_id}')"><b>${e(x.name)}</b>${x.phone?` <small class="muted">${e(x.phone)}</small>`:''}</button>`).join('')||'<div class="muted">مفيش نتيجة</div>';
}
function pickParty(id){window._stp=id;st='';R()}
function printStmt(){
  if(!window._stp||!st)return toast('اعرض الكشف الأول');
  printHtml('كشف الحساب',st);
}
async function showPartyStmt(){
  const id=window._stp;
  if(!id)return alert('ابحث واختار الطرف أولاً');
  window._stp=id; window._sa=v('sa'); window._sb=v('sb2');
  const a=v('sa')||'0000-01-01', b=v('sb2')||'9999-12-31';
  const B=(await g('party_balances','name')).find(x=>x.party_id===id)||{};
  const[cu,su,cr,sr]=await Promise.all([
    B.customer_id?sb.from('customers').select('opening_balance').eq('id',B.customer_id).single().then(r=>r.data||{}):{},
    B.supplier_id?sb.from('suppliers').select('opening_balance').eq('id',B.supplier_id).single().then(r=>r.data||{}):{},
    B.customer_id?rpc('customer_statement',{p_party:B.customer_id,p_to:b}):[],
    B.supplier_id?rpc('supplier_statement',{p_party:B.supplier_id,p_to:b}):[]]);
  // أثر كل حركة على الصافي: عميل (مدين = مستحق لنا)، مورد (دائن = مستحق علينا)
  const rowsAll=[
    ...cr.map(r=>({d:r.d,doc:r.doc,descr:r.descr,kind:'عميل',eff:(+r.debit||0)-(+r.credit||0)})),
    ...sr.map(r=>({d:r.d,doc:r.doc,descr:r.descr,kind:'مورد',eff:(+r.debit||0)-(+r.credit||0)}))
  ].sort((x,y)=>String(x.d).localeCompare(String(y.d)));
  const open=(+cu.opening_balance||0)-(+su.opening_balance||0);
  const before=rowsAll.filter(r=>r.d<a).reduce((t,r)=>t+r.eff,0);
  let bal=open+before;
  const startBal=bal;
  const balTxt=x=>Math.abs(x)<0.005?'<span class="muted">متصفّر</span>':x>0?`<span class="good">مستحق لنا ${fmt(x)}</span>`:`<span class="bad">مستحق علينا ${fmt(-x)}</span>`;
  const body=rowsAll.filter(r=>r.d>=a).map(r=>{
    bal+=r.eff;
    const owe=r.eff>0?fmt(r.eff):'', owed=r.eff<0?fmt(-r.eff):'';
    return [r.d,e(r.doc||''),e(r.descr||''),e(r.kind),owe,owed,balTxt(bal)];
  });
  st=`<div class="stmt-head"><div><h3>${e(B.name||'')}</h3>${B.phone?`<small class="muted">${e(B.phone)}</small>`:''}</div>
      <div class="stmt-open">رصيد أول المدة: ${balTxt(startBal)}</div></div>`
    +T(['التاريخ','المستند','البيان','النوع','مستحق لنا','مستحق علينا','الرصيد'],body)
    +`<p class="stmt-close">الرصيد الختامي: ${balTxt(bal)}</p>`;
  R();
}
function partyStmt(id){window._stp=id;st='';go('stmt')}
// ===== v1.56: تبديل الأسلوب (عامية مصرية / فصحى) على الموقع كله =====
// كل زوج: [العامية المصرية، الفصحى]. الاختيار بيتطبق على الشاشات وعلى الرسايل (alert/toast).
// الأسماء اللي متشابهة في اللهجتين مش محتاجة تبديل، والتبديل بيغطي الأفعال والأدوات والجمل الشائعة.
const DX_PAIRS=[
  ['اختار ','اختر '],['اختار','اختر'],['النهارده','اليوم'],['مفيش نتيجة','لا توجد نتائج'],['مفيش ','لا يوجد '],['مفيش','لا يوجد'],
  ['اتعمل','أُنشئ'],['اتحدّث','حُدّث'],['اتحدث','حُدّث'],['اتشال','أُزيل'],['اتصلح','أُصلح'],['اتفعل','فُعّل'],['اتضاف','أُضيف'],
  ['متصفّر','متوازن'],['مستحق لنا','مدين لنا'],['مستحق علينا','دائن لنا'],
  ['الحساب لسه متفعلش','الحساب لم يُفعّل بعد'],['كلم الأدمن','تواصل مع المسؤول'],
  ['عايز ','أريد '],['عايزين ','نريد '],['عايزه','أريده'],['عايز','أريد'],['عشان ','لكي '],['علشان ','لكي '],
  ['كده','هكذا'],['دلوقتي','الآن'],['بعدين','لاحقاً'],['طب ','حسناً، '],['ازاي','كيف'],['إزاي','كيف'],['فين','أين'],
  ['ليه','لماذا'],['ماينفعش','لا يجوز'],['مينفعش','لا يجوز'],['تمام','حسناً'],['تقدر ','تستطيع '],['تقدر','تستطيع'],
  ['بيتضاف','يُضاف'],['بيتحفظ','يُحفظ'],['بيبان','يظهر'],['بيظهر لي','يظهر لي'],['لسه ','بعد '],['حاجة ','شيء '],['حاجه ','شيء '],
  ['كمان','أيضاً'],['برضو','أيضاً'],['أوي','جداً'],['قوي','جداً'],['خليها','اجعلها'],['خليه','اجعله'],['خلي ','اجعل '],
  ['مش ','ليس '],['هنعمل','سنعمل'],['هنضيف','سنضيف'],['هنشيل','سنزيل'],['هنعدل','سنعدّل'],['هنعمل','سنعمل'],
  ['ادوس','اضغط'],['دوس ','اضغط '],['بتاع ','الخاص بـ '],['بتاعت ','الخاصة بـ '],['بتاعة ','الخاصة بـ '],
  ['اتقفل','أُغلق'],['اتقفلت','أُغلقت'],['اتحذف','حُذف'],['اتسجل','سُجّل'],['اتسجلت','سُجّلت'],['اتعطل','تعطّل'],
];
DX_PAIRS.sort((a,b)=>b[0].length-a[0].length);
// ----- ترجمة الإنجليزي (المرحلة الأولى: القوايم والأزرار والعناوين) -----
let EN_PAIRS=[
['الرئيسية','Home'],['المنتجات','Products'],['الأطراف','Parties'],['الموردون','Suppliers'],['المبيعات','Sales'],['أذونات التسليم','Delivery Notes'],['المشتريات','Purchases'],['أوامر الشراء','Purchase Orders'],['استلامات المشتريات','Goods Receipts'],['المرتجعات','Returns'],['عروض الأسعار','Quotations'],['أوامر البيع','Sales Orders'],['كشف الحساب','Statement'],['المدفوعات','Payments'],['المصروفات','Expenses'],['الخزينة','Cash'],['البنوك والتسويات','Banks & Reconciliation'],['المخازن','Warehouses'],['تحويل مخزني','Stock Transfer'],['الجرد','Stocktake'],['قوائم الأسعار','Price Lists'],['العمولات','Commissions'],['الأصول الثابتة','Fixed Assets'],['الموظفون','Employees'],['الحضور والإجازات','Attendance & Leave'],['المرتبات','Payroll'],['التصنيع','Manufacturing'],['نقطة البيع','Point of Sale'],['المشروعات والخدمات','Projects & Services'],['الفروع ومراكز التكلفة','Branches & Cost Centers'],['الفترات المالية','Fiscal Periods'],['الاعتمادات','Approvals'],['الشيكات','Cheques'],['المستندات الضريبية','Tax Documents'],['التكاملات','Integrations'],['التقارير','Reports'],['الحسابات','Accounts'],['فحص الجاهزية','Health Check'],['المستخدمون','Users'],['سجل العمليات','Audit Log'],['الإعدادات','Settings'],['إعدادات المطور','Developer Settings'],['بحث سريع في النظام','Quick search'],
['تسجيل الدخول','Sign in'],['تسجيل خروج','Sign out'],['إضافة','Add'],['تعديل','Edit'],['حذف','Delete'],['حفظ','Save'],['إلغاء','Cancel'],['طباعة','Print'],['تحديث','Update'],['تأكيد','Confirm'],['بحث','Search'],['فتح','Open'],['إغلاق','Close'],['تطبيق','Apply'],['رجوع','Back'],['تصدير','Export'],['استيراد','Import'],['نسخة احتياطية','Backup'],
['فاتورة بيع','Sales invoice'],['فاتورة شراء','Purchase invoice'],['مرتجع بيع','Sales return'],['مرتجع شراء','Purchase return'],
['الإجمالي','Total'],['الرصيد','Balance'],['التاريخ','Date'],['الاسم','Name'],['الكود','Code'],['الباركود','Barcode'],['المخزون','Stock'],['التكلفة','Cost'],['السعر','Price'],['الكمية','Quantity'],['رقم الفاتورة','Invoice No.'],['المبلغ','Amount'],['العميل','Customer'],['المورد','Supplier'],['الصنف','Item'],['الفرع','Branch'],['المخزن','Warehouse'],['الحساب','Account'],['الخصم','Discount'],['الضريبة','Tax'],['الحالة','Status'],['ملاحظات','Notes'],['الوصف','Description'],['الهاتف','Phone'],['البريد','Email'],['الدور','Role'],['مفعّل','Active'],['الصلاحيات','Permissions'],
['لوحة التحكم','Dashboard'],['الربح الإجمالي','Gross profit'],['الربح المبدئي','Gross profit'],['المبيعات اليوم','Today sales'],['هذا الشهر','This month'],['اليوم','Today'],['آخر 7 أيام','Last 7 days'],['هذا العام','This year'],
['مرحباً','Welcome'],['مرحبًا','Welcome'],['مركز موحّد لإدارة المبيعات والمشتريات والمخزون والمحاسبة.','Unified center for sales, purchases, inventory and accounting.'],
['فاتورة مبيعات سريعة','Quick sale invoice'],['تحويل المخزن','Warehouse transfer'],

["سلف","Advances"],
["إلى","To"],
["صرف","Disburse"],
["عجز","Shortage"],
["نشط","Active"],
["بنك","Bank"],
["رفض","Rejected"],
["بند","Item"],
["دفع","Pay"],
["قبض","Receive"],
["فيه","Available"],
["قبل","Before"],
["نقل","Transfer"],
["عرض","Display"],
["سبب","Reason"],
["أخرى","Other"],
["مياه","Water"],
["نقدي","Cash"],
["داخل","In"],
["جزاء","Penalty"],
["حالي","Current"],
["جملة","Sentence"],
["آجلة","Credit"],
["فصحى","Formal Arabic"],
["خارج","Out"],
["حاضر","Present"],
["وارد","Incoming"],
["متاح","Available"],
["اكتب","Type"],
["الكل","All"],
["فعلي","Actual"],
["غايب","Absent"],
["رقم:","No.:"],
["صافي","Net"],
["الحد","Limit"],
["غياب","Absence"],
["دفعة","Batch"],
["معطل","Disabled"],
["عطلة","Holiday"],
["مخصص","Custom"],
["متصل","Online"],
["متأخر","Late"],
["وردية","Shift"],
["تفريغ","Unload"],
["معتمد","Approved"],
["مقبوض","Received"],
["إجازة","Leave"],
["مسجلة","Recorded"],
["معلّق","Pending"],
["إقفال","Closing"],
["تفعيل","Activation"],
["رواتب","Salaries"],
["منتهي","Ended"],
["محفظة","Wallet"],
["تعطيل","Disable"],
["مفتوح","Open"],
["العجز","The shortage"],
["إيداع","Deposit"],
["الوقت","Time"],
["إضافي","Extra"],
["الأصل","The asset"],
["الأمر","The order"],
["إهلاك","Depreciation"],
["الرقم","The number"],
["تخصيص","Customize"],
["السبب","The reason"],
["عملية","Operation"],
["الفرق","Difference"],
["الطرف","Party"],
["محجوز","Reserved"],
["مطابق","Matched"],
["إكمال","Complete"],
["تغيير","Change"],
["إنشاء","Create"],
["عمالة","Labor"],
["ملغاة","Cancelled"],
["الكشف","The statement"],
["+ بند","+ Item"],
["صيانة","Maintenance"],
["تسويق","Marketing"],
["متوفر","In stock"],
["الفتح","Opening"],
["هاتف:","Phone:"],
["+ سطر","+ Line"],
["البند","The item"],
["الوضع","Mode"],
["مقفول","Locked"],
["إشعار","Notice"],
["تعذر:","Could not:"],
["إيجار","Rent"],
["إجراء","Action"],
["الخطأ","The error"],
["النوع","Type"],
["موقوف","Suspended"],
["تصنيف","Category"],
["المصدر","Source"],
["العطلة","The holiday"],
["التحقق","Verification"],
["واتساب","WhatsApp"],
["الشركة","Company"],
["بحث...","Search..."],
["تعديل:","Edit:"],
["المجمع","Consolidated"],
["قريباً","Coming soon"],
["تفاصيل","Details"],
["الحركة","Movement"],
["مدفوعة","Paid"],
["ملاحظة","Note"],
["الحالي","Current"],
["الصافي","The net"],
["القيمة","Value"],
["خارج −","Out −"],
["مكافآت","Bonuses"],
["فحوصات","Checks"],
["المادة","Material"],
["إجباري","Required"],
["العملة","Currency"],
["خصومات","Deductions"],
["الرابط","Link"],
["كهرباء","Electricity"],
["إنترنت","Internet"],
["الفعلي","Actual"],
["داخل ＋","In ＋"],
["المزود","Provider"],
["البائع","Seller"],
["مكافأة","Bonus"],
["رجوع","Back"],
["البيان","Statement"],
["مطابقة","Reconciliation"],
["الأيام","Days"],
["الأساس","Basis"],
["المتاح","Available"],
["المركز","Center"],
["الجلسة","Session"],
["الفترة","Period"],
["العمولة","Commission"],
["حصل خطأ","An error occurred"],
["التصنيف","Classification"],
["الإيميل","Email"],
["القاعدة","Rule"],
["استبعاد","Exclude"],
["الوظيفة","Job title"],
["المكوّن","Component"],
["عرض سعر","Quotation"],
["شيك دفع","Payment cheque"],
["كشف بنك","Bank statement"],
["حفظ قيد","Save entry"],
["تخصيص","Customize"],
["صنف جرد","Stock count item"],
["الإغلاق","Closing"],
["من مخزن","From warehouse"],
["المتوقع","Expected"],
["العملاء","Customers"],
["القوائم","Lists"],
["الأساسي","Basic"],
["خصم كلي","Total discount"],
["العملية","The operation"],
["التقدير","Estimate"],
["الاسم *","Name *"],
["أمر بيع","Sales order"],
["شيك قبض","Receipt cheque"],
["الأرصدة","Balances"],
["اختياري","Optional"],
["من حساب","From account"],
["الإصدار","Version"],
["المجموع","Total"],
["افتتاحي","Opening"],
["التخصيص","Customization"],
["المتبقي","Remaining"],
["العطلات","Holidays"],
["القائمة","The list"],
["سطر قيد","Journal line"],
["الأصناف","Items"],
["تحميلات","Downloads"],
["العنوان","Address"],
["الاتجاه","Direction"],
["استعادة","Restore"],
["التشغيلة","Batch"],
["من تاريخ","From date"],
["النسبة %","Rate %"],
["طرف جديد","New party"],
["إلى حساب","To account"],
["اختر يوم","Choose day"],
["مش مفعّل","Not activated"],
["فحص سريع","Quick check"],
["الانصراف","Check-out"],
["التفاصيل","Details"],
["الفواتير","Invoices"],
["ملاحظات:","Notes:"],
["إلى مخزن","To warehouse"],
["الصلاحية","Expiry"],
["دفع مرتب","Pay salary"],
["أصل ثابت","Fixed asset"],
["بدون كود","No code"],
["المطابقة","Matching"],
["صالح حتى","Valid until"],
["كشف مرتب","Payslip"],
["حد الخصم","Discount limit"],
["أمر شراء","Purchase order"],
["فتح جلسة","Open session"],
["رفع لوجو","Upload logo"],
["فرع جديد","New branch"],
["جرد جديد","New stock count"],
["غير محدد","Not specified"],
["إذن تسليم","Delivery note"],
["آخر المدة","End of period"],
["المطور بس","Developer only"],
["إضافة سعر","Add price"],
["إهلاك أصل","Asset depreciation"],
["وحدة قياس","Unit of measure"],
["منتج جديد","New product"],
["آخر تحديث","Last updated"],
["يوم مقفول","Closed day"],
["أمر تصنيع","Manufacturing order"],
["المقبوضات","Receipts"],
["تسجيل شيك","Record cheque"],
["إلى تاريخ","To date"],
["اسم الأصل","Asset name"],
["اسم الفرع","Branch name"],
["إنشاء كشف","Create statement"],
["الأصناف ←","Items ←"],
["تم بواسطة","Done by"],
["إضافة فرع","Add branch"],
["تحصيل شيك","Collect cheque"],
["وصول سريع","Quick access"],
["نوع إجازة","Leave type"],
["عميل جديد","New customer"],
["غير مدفوع","Unpaid"],
["AR · فصحى","AR · Formal"],
["طلب إجازة","Leave request"],
["حسب الدور","By role"],
["أول المدة","Start of period"],
["موظف جديد","New employee"],
["فحص الملف","Check file"],
["اكتب كلمة","Type a word"],
["اسم الصنف","Item name"],
["كود الفرع","Branch code"],
["قيد يومية","Journal entry"],
["عشان تأكد","To confirm"],
["رقم الشيك","Cheque number"],
["حدث تكامل","Integration event"],
["سعر البيع","Selling price"],
["حفظ القيد","Save entry"],
["حساب جديد","New account"],
["تسوية جرد","Stock adjustment"],
["تصدير CSV","Export CSV"],
["اسم حساب","Account name"],
["التحويلات","Transfers"],
["الاستحقاق","Due date"],
["حفظ الطرق","Save methods"],
["عرض الكشف","View statement"],
["رسملة أصل","Capitalize asset"],
["الإجمالي:","Total:"],
["الميزانية","Budget"],
["إنشاء BOM","Create BOM"],
["حفظ العرض","Save quotation"],
["أضف بندًا","Add an item"],
["وصف القيد","Entry description"],
["التصنيفات","Categories"],
["الأساسيات","Basics"],
["حساب الدفع","Payment account"],
["عرض الحركة","View movement"],
["خارج الدور","Out of turn"],
["رقم تسلسلي","Serial number"],
["رصيد مخزون","Stock balance"],
["AR · عامية","AR · Colloquial"],
["إنشاء فترة","Create period"],
["إضافة مخزن","Add warehouse"],
["مطابقة بنك","Bank reconciliation"],
["طلب اعتماد","Approval request"],
["كشوف البنك","Bank statements"],
["حفظ الحضور","Save attendance"],
["مكون تصنيع","Manufacturing component"],
["كود المركز","Center code"],
["حركة خزينة","Cash movement"],
["تعديل موظف","Edit employee"],
["حذف سجل من","Delete record from"],
["صباح الخير","Good morning"],
["سعر الشراء","Purchase price"],
["دفعة مخزون","Stock batch"],
["اسم الحساب","Account name"],
["تم استيراد","Imported"],
["الرئيسية","Home"],
["إضافة عطلة","Add holiday"],
["تسجيل دفعة","Record payment"],
["اسم العطلة","Holiday name"],
["الاستحقاق:","Due:"],
["فترة جديدة","New period"],
["عرض البنود","View items"],
["مجمل الربح","Gross profit"],
["تصنيف جديد","New category"],
["اختر الصنف","Select item"],
["نوع الحركة","Movement type"],
["سعر الجملة","Wholesale price"],
["أضف بنودًا","Add items"],
["اسم المخزن","Warehouse name"],
["سعر الوحدة","Unit price"],
["فترة مخصصة","Custom period"],
["عرض الكل ←","View all ←"],
["تذكرة خدمة","Service ticket"],
["وقت الحضور","Check-in time"],
["مساء الخير","Good afternoon"],
["اسم الفترة","Period name"],
["تسجيل حضور","Record attendance"],
["وصفة تصنيع","Manufacturing recipe"],
["اسم المركز","Center name"],
["فحص النظام","System check"],
["مفيش نتايج","No results"],
["مساء النور","Good evening"],
["حركة مخزون","Stock movement"],
["تصنيف أصول","Asset category"],
["فتح الموقع","Open site"],
["تسجيل دخول","Sign in"],
["اختر الشهر","Select month"],
["صنف استلام","Receiving item"],
["مركز تكلفة","Cost center"],
["قفل الموقع","Lock site"],
["حساب عمولة","Commission account"],
["مدة السداد","Payment term"],
["اختر صنفًا","Select an item"],
["جلسة كاشير","Cashier session"],
["اسم الشركة","Company name"],
["كل المخازن","All warehouses"],
["فترة مالية","Fiscal period"],
["اكتب الاسم","Type the name"],
["توزيع دفعة","Allocate batch"],
["حفظ التعديل","Save changes"],
["كلمة المرور","Password"],
["نوع العملية","Operation type"],
["استيراد CSV","Import CSV"],
["طباعة / PDF","Print / PDF"],
["مستند ضريبي","Tax document"],
["تحميل نموذج","Download template"],
["حد الائتمان","Credit limit"],
["إضافة قاعدة","Add rule"],
["عامية مصرية","Egyptian colloquial"],
["ملخص النسخة","Backup summary"],
["حركات الكشف","Statement movements"],
["اختر المخزن","Select warehouse"],
["تذكرة جديدة","New ticket"],
["حفظ المصروف","Save expense"],
["سطر كشف بنك","Bank statement line"],
["تطبيق القفل","Apply lock"],
["إضافة اتصال","Add contact"],
["استبعاد أصل","Exclude asset"],
["اسم القاعدة","Rule name"],
["حفظ المرتجع","Save return"],
["تقديم الطلب","Submit request"],
["كل الفواتير","All invoices"],
["حفظ التحويل","Save transfer"],
["إضافة مكوّن","Add component"],
["الحد الأدنى","Minimum"],
["إنشاء قائمة","Create list"],
["اسم التصنيف","Category name"],
["+ إضافة صنف","+ Add item"],
["صنف عرض سعر","Quotation item"],
["فتح القائمة","Open list"],
["تحصيل / دفع","Collect / Pay"],
["رقم الإصدار","Version number"],
["اختر المورد","Select supplier"],
["رقم التحويل","Transfer number"],
["حفظ التخصيص","Save customization"],
["قاعدة عمولة","Commission rule"],
["صنف أمر بيع","Sales order item"],
["إضافة السعر","Add price"],
["إنشاء الكشف","Create statement"],
["قائمة أسعار","Price list"],
["إضافة الطرف","Add party"],
["اسم الاتصال","Contact name"],
["إضافة الصنف","Add item"],
["المصروفات —","Expenses —"],
["تصنيف الأصل","Asset category"],
["تعديل القفل","Edit lock"],
["لوجو الشركة","Company logo"],
["اسم المشروع","Project name"],
["عدد الأصناف","Number of items"],
["استيراد ملف","Import file"],
["تسجيل مستند","Record document"],
["جلسة مفتوحة","Open session"],
["إنشاء مشروع","Create project"],
["طريقة الدفع","Payment method"],
["إضافة تصنيف","Add category"],
["+ موظف جديد","+ New employee"],
["سجل الدفعات","Payment log"],
["حساب النظام","System account"],
["اتصال تكامل","Integration connection"],
["كود المشروع","Project code"],
["اختر العميل","Select customer"],
["تفاصيل الجرد","Stock count details"],
["إضافة سجل في","Add record to"],
["اختار الموظف","Select employee"],
["تكلفة الوحدة","Unit cost"],
["تعديل الطرف:","Edit party:"],
["مدفوعات مورد","Supplier payments"],
["عمولة مبيعات","Sales commission"],
["الجرد السابق","Previous stock count"],
["إغلاق الجلسة","Close session"],
["تسجيل انصراف","Record check-out"],
["لسه مش مفعّل","Not activated yet"],
["استلام بضاعة","Receive goods"],
["تعديل فاتورة","Edit invoice"],
["إنشاء الفترة","Create period"],
["كمية المرتجع","Return quantity"],
["تعديل الصنف:","Edit item:"],
["كلهم مفعّلين","All activated"],
["عدد المنتجات","Number of products"],
["وقت الانصراف","Check-out time"],
["مرتجع مبيعات","Sales return"],
["كل المرتجعات","All returns"],
["تسجيل الخروج","Sign out"],
["قيمة المخزون","Stock value"],
["اعتماد الجرد","Approve stock count"],
["UUID الخارجي","External UUID"],
["تفاصيل الكشف","Statement details"],
["استعادة نسخة","Restore backup"],
["تفاصيل الفشل","Failure details"],
["إلغاء فاتورة","Cancel invoice"],
["عميل اختياري","Optional customer"],
["فرق غير مسجل","Unrecorded difference"],
["تسجيل الدفعة","Record payment"],
["إضافة وتسجيل","Add and record"],
["فشل الاختبار","Test failed"],
["فاتورة جديدة","New invoice"],
["رقم التشغيلة","Batch number"],
["تحميل البنود","Load items"],
["حركة الخزينة","Cash movement"],
["إظهار اللوجو","Show logo"],
["يحتاج مراجعة","Needs review"],
["ترحيل القيود","Post entries"],
["رصيد افتتاحي","Opening balance"],
["كمية التسليم","Delivery quantity"],
["تأكيد وتفعيل","Confirm and activate"],
["تعديل المخزن","Edit warehouse"],
["بدء جرد جديد","Start new stock count"],
["مقبوضات عميل","Customer receipts"],
["تعديل سجل في","Edit record in"],
["فواتير البيع","Sales invoices"],
["كشف بنك جديد","New bank statement"],
["إقفال الفترة","Close period"],
["الجرد الحالي","Current stock count"],
["اختر أمر بيع","Select sales order"],
["صنف أمر شراء","Purchase order item"],
["منخفض المخزون","Low stock"],
["قواعد العمولة","Commission rules"],
["الجزء المتأثر","Affected part"],
["تفعيل الضريبة","Enable tax"],
["أسعار الأصناف","Item prices"],
["كمية الاستلام","Receipt quantity"],
["الفروع النشطة","Active branches"],
["طالب الاعتماد","Requested by"],
["اليوم · مفتوح","Today · Open"],
["إيقاف الإجبار","Disable enforcement"],
["إضافة + رسملة","Add + capitalize"],
["إلغاء التعديل","Cancel edit"],
["تفعيل الإجبار","Enable enforcement"],
["بدون رقم هاتف","No phone number"],
["تقييم المخزون","Stock valuation"],
["اختار التاريخ","Choose date"],
["آجل / جزء آجل","Credit / partial credit"],
["أصل ثابت جديد","New fixed asset"],
["تمت الاستعادة","Restored"],
["مستحق العملاء","Customer receivables"],
["صنف مرتجع بيع","Sales return item"],
["مشروع اختياري","Optional project"],
["الرقم الضريبي","Tax number"],
["الموقع اتفتح.","The site is open."],
["لا يوجد نتيجة","No result"],
["مدفوعة جزئياً","Partially paid"],
["الدور الأساسي","Primary role"],
["حركات المخزون","Stock movements"],
["سجل التحويلات","Transfer log"],
["مرتجع مشتريات","Purchase return"],
["تخصيص الطباعة","Print settings"],
["تقرير الأرباح","Profit report"],
["تسجيل التسليم","Record delivery"],
["اقتراح الشراء","Purchase suggestion"],
["الجرد الحالي:","Current stock count:"],
["إضافة للتحويل","Add to transfer"],
["إضافة سعر صنف","Add item price"],
["اختصار مستخدم","User shortcut"],
["بدء الاستعادة","Start restore"],
["توقيع المستلم","Receiver signature"],
["حفظ الإعدادات","Save settings"],
["فواتير الشراء","Purchase invoices"],
["توقيع المسؤول","Manager signature"],
["من فضلك انتظر","Please wait"],
["موضوع التذكرة","Ticket subject"],
["العمر بالشهور","Age in months"],
["أعمار العملاء","Customer aging"],
["اختر الفاتورة","Select invoice"],
["إضافة التصنيف","Add category"],
["الحساب المالي","Financial account"],
["تحديث الواجهة","Refresh interface"],
["التدفق النقدي","Cash flow"],
["طباعة القائمة","Print list"],
["أكمل البيانات","Complete the data"],
["تاريخ التعيين","Hire date"],
["ابحث عن الصنف","Search for item"],
["تحديث اليومية","Update journal"],
["صافي المبيعات","Net sales"],
["إرسال التحديث","Send update"],
["— بدون حساب —","— No account —"],
["جاري الفحص...","Checking..."],
["اختر أمر شراء","Select purchase order"],
["ابحث عن الطرف","Search for party"],
["تحويل لفاتورة","Convert to invoice"],
["رصيد غير مخصص","Unallocated balance"],
["صنف إذن تسليم","Delivery note item"],
["شراء أصل ثابت","Buy fixed asset"],
["المركز المالي","Financial position"],
["باسورد النسخة","Backup password"],
["إنشاء القائمة","Create list"],
["مكافأة / جزاء","Bonus / Penalty"],
["رقم كشف البنك","Bank statement number"],
["إضافة القاعدة","Add rule"],
["المدفوع المخصص","Allocated paid amount"],
["رصيد أول المدة","Opening balance"],
["تعديل المستخدم","Edit user"],
["حركة الخزينة —","Cash movement —"],
["أعمار الموردين","Supplier aging"],
["اكتب اسم الصنف","Type item name"],
["نسبة الضريبة %","Tax rate %"],
["دفعة مع فاتورة","Payment with invoice"],
["صلاحيات مستخدم","User permissions"],
["إعدادات الشركة","Company settings"],
["صنف مرتجع شراء","Purchase return item"],
["ميزان المراجعة","Trial balance"],
["المجموع الفرعي","Subtotal"],
["إضافة المستخدم","Add user"],
["رصيد آخر المدة","End balance"],
["إضافة حركة كشف","Add statement movement"],
["النسخة الكاملة","Full backup"],
["رصيد التشغيلات","Batch balance"],
["استيراد وتصدير","Import & export"],
["إضافة صنف جديد","Add new item"],
["مستحق الموردين","Supplier payables"],
["أرصدة الحسابات","Account balances"],
["مكافآت وجزاءات","Bonuses & penalties"],
["بدلًا من الحذف","Instead of deleting"],
["لا توجد حركات.","No movements."],
["تحويل لأمر بيع","Convert to sales order"],
["حساب خزينة/بنك","Cash/bank account"],
["حد إعادة الطلب","Reorder level"],
["قيد يومية يدوي","Manual journal entry"],
["التحقق الثنائي","Two-factor verification"],
["تفاصيل التحويل","Transfer details"],
["الرقم الضريبي:","Tax number:"],
["صنف فاتورة بيع","Sales invoice item"],
["اكتب اسم الطرف","Type party name"],
["نسيت الجهاز ده","Forget this device"],
["تأكيد كلمة السر","Confirm password"],
["تغيير كلمة السر","Change password"],
["تعذر تفعيل MFA:","Could not enable MFA:"],
["نص أسفل الطباعة","Footer text"],
["التحويل المخزني","Stock transfer"],
["صفحة غير متاحة.","Page not available."],
["العطلات الرسمية","Public holidays"],
["اكتب اسم الموظف","Type employee name"],
["دفعات غير مخصصة","Unallocated payments"],
["تحديث Submitted","Submitted update"],
["رصيد دفعة مخزون","Stock batch balance"],
["الكمية المطلوبة","Requested quantity"],
["طباعة هذا اليوم","Print this day"],
["فواتير المبيعات","Sales invoices"],
["حركة تتبع مخزون","Stock tracking movement"],
["المحاسبة العامة","General accounting"],
["القيمة المتبقية","Remaining value"],
["صرف مخزون متتبع","Issue tracked stock"],
["صنف قائمة أسعار","Price list item"],
["تسجيل خروج للكل","Sign out everywhere"],
["تنبيهات المخزون","Stock alerts"],
["+ فاتورة مبيعات","+ Sales invoice"],
["إجمالي الفواتير","Total invoices"],
["جاري التحميل...","Loading..."],
["الخزينة والبنوك","Cash & banks"],
["تحميل نموذج CSV","Download CSV template"],
["صنف تحويل مخزني","Stock transfer item"],
["التوريد المتوقع","Expected supply"],
["مركز تكلفة جديد","New cost center"],
["صنف فاتورة شراء","Purchase invoice item"],
["لون الخط الفاصل","Divider line color"],
["تسجيل حضور يدوي","Manual attendance"],
["أدخل اسم المخزن","Enter warehouse name"],
["إرشادات Go-Live","Go-Live guide"],
["الموارد البشرية","Human resources"],
["كود على الإيميل","Code by email"],
["+ أصل ثابت جديد","+ New fixed asset"],
["اعتماد الاستلام","Approve receipt"],
["بالظبط عشان تكمل","Exactly so you can continue"],
["لا توجد Serials.","No serials."],
["الضريبة والمخزون","Tax & inventory"],
["تتبع وحركة الصنف","Tracking & item movement"],
["الكود من التطبيق","Code from the app"],
["حفظ إعداد التتبع","Save tracking setting"],
["جاري المعالجة...","Processing..."],
["فواتير المشتريات","Purchase invoices"],
["كمية إعادة الطلب","Reorder quantity"],
["بطاقة حركة الصنف","Item movement card"],
["+ إنشاء أمر شراء","+ Create purchase order"],
["الرصيد قبل ← بعد","Balance before ← after"],
["لا توجد تشغيلات.","No batches."],
["اختر جلسة مفتوحة","Select open session"],
["إضافة مركز تكلفة","Add cost center"],
["تم تحديث القيود:","Entries updated:"],
["تغيير كلمة السر:","Change password:"],
["جاري الاختبار...","Testing..."],
["تنزيل نسخة كاملة","Download full backup"],
["الرصيد الافتتاحي","Opening balance"],
["المكونات المعرفة","Defined components"],
["اعرض الكشف الأول","Show first statement"],
["إظهار اسم الشركة","Show company name"],
["الكمية بالفاتورة","Quantity on invoice"],
["الفواتير السابقة","Previous invoices"],
["فترة مالية جديدة","New fiscal period"],
["تعذر بدء التحقق:","Could not start verification:"],
["الأصناف المحوّلة","Transferred items"],
["إنشاء مرتجع جديد","Create new return"],
["الفترات والإقفال","Periods & closing"],
["العمولات المسجلة","Recorded commissions"],
["استلام المشتريات","Purchase receipts"],
["المشاريع والخدمات","Projects & services"],
["تفاصيل كشف المرتب","Payslip details"],
["كود الحساب المدين","Debit account code"],
["تتبع المخزون وMRP","Inventory tracking & MRP"],
["قاعدة عمولة جديدة","New commission rule"],
["جاري الاستعادة...","Restoring..."],
["اختر العميل الأول","Select the first customer"],
["الفواتير المستحقة","Due invoices"],
["فشل اختبار النظام","System test failed"],
["جاري فحص الملف...","Checking file..."],
["تمت العملية بنجاح","Operation completed successfully"],
["اختر المورد الأول","Select the first supplier"],
["إضافة مستخدم جديد","Add new user"],
["حساب عمولة فاتورة","Invoice commission calculation"],
["المرتجعات السابقة","Previous returns"],
["تعذر تحميل الصفحة","Could not load page"],
["جلب المعتمد للشهر","Fetch approved for month"],
["اسم قائمة الأسعار","Price list name"],
["حفظ تخصيص الطباعة","Save print settings"],
["كود الحساب الدائن","Credit account code"],
["مبيعات جلسة كاشير","Cashier session sales"],
["بادئة مرتجع البيع","Sales return prefix"],
["قائمة أسعار جديدة","New price list"],
["المرتجعات المسجلة","Recorded returns"],
["البيانات الأساسية","Basic data"],
["اكتب الباسورد تاني","Type the password again"],
["إنشاء فاتورة جديدة","Create new invoice"],
["تفعيل التتبع للصنف","Enable tracking for item"],
["الحد الأدنى للكمية","Minimum quantity"],
["المدفوعات والتحصيل","Payments & collection"],
["استلام مخزون متتبع","Receive tracked stock"],
["تعذر إلغاء الجهاز:","Could not revoke device:"],
["الإعدادات والإدارة","Settings & administration"],
["الكمية في الفاتورة","Quantity on invoice"],
["تقدير قيمة المرتجع","Estimated return value"],
["اختار المورد أولاً","Select supplier first"],
["بادئة فاتورة البيع","Sales invoice prefix"],
["اختر فاتورة مدفوعة","Select paid invoice"],
["اختار العميل أولاً","Select customer first"],
["تتبع المخزون / MRP","Inventory tracking / MRP"],
["الاستيراد والتصدير","Import & export"],
["صافي الربح المبدئي","Estimated net profit"],
["تم تغيير كلمة السر","Password changed"],
["المحاسبة والتقارير","Accounting & reports"],
["الخزينة والتحويلات","Cash & transfers"],
["تعذر تسجيل الدخول:","Could not sign in:"],
["جاري فتح الصفحة...","Opening page..."],
["خروج كل المستخدمين","Sign out all users"],
["اختر الحساب المالي","Select financial account"],
["المدفوعات والتخصيص","Payments & allocation"],
["التحصيل والمدفوعات","Collections & payments"],
["بادئة مرتجع الشراء","Purchase return prefix"],
["اكتب باسورد النسخة","Type backup password"],
["تحويل بين الحسابات","Transfer between accounts"],
["التحويلات المخزنية","Stock transfers"],
["مدة السداد بالأيام","Payment term in days"],
["أعمار ديون العملاء","Customer debt aging"],
["حساب الدخول للنظام","System login account"],
["الموقع مقفول مؤقتاً","The site is temporarily locked"],
["آخر فواتير المبيعات","Latest sales invoices"],
["· تم تنظيف البيانات","· Data cleaned"],
["لا توجد مرتجعات بعد","No returns yet"],
["تعذر إرسال التحديث:","Could not send update:"],
["لا يوجد عجز حاليًا.","No shortage currently."],
["ما زال يحتاج معالجة","Still needs processing"],
["فعّل التحقق الثنائي","Enable two-factor verification"],
["مرتجع من فاتورة بيع","Return from sales invoice"],
["رقم يتولد عند الحفظ","Number generated on save"],
["تعذر تنفيذ العملية:","Could not complete operation:"],
["عاد الاتصال بالنظام","Connection restored"],
["لا توجد فواتير بعد.","No invoices yet."],
["المدفوع عند التحويل","Paid on transfer"],
["حساب وتسجيل العمولة","Calculate and record commission"],
["اختر مخزنين مختلفين","Select two different warehouses"],
["نجح الاختبار الشامل","Full test passed"],
["اللغة وأسلوب الكلام","Language & speaking style"],
["لا توجد بيانات بعد.","No data yet."],
["بادئة فاتورة الشراء","Purchase invoice prefix"],
["أعمار ديون الموردين","Supplier debt aging"],
["التقارير والتحليلات","Reports & analytics"],
["اختر حسابين مختلفين","Select two different accounts"],
["تعذر تحميل الفاتورة:","Could not load invoice:"],
["خلال الفترة المختارة","During the selected period"],
["صلاحيات المدير كاملة","Full manager permissions"],
["توافر البضاعة والعجز","Stock availability & shortage"],
["جاري تشغيل النظام...","Starting the system..."],
["اتلغى الجهاز المتذكر","Remembered device revoked"],
["مرتجع من فاتورة شراء","Return from purchase invoice"],
["جاري تسجيل الدخول...","Signing in..."],
["لا توجد أصناف مطابقة","No matching items"],
["تعذر تحميل الصلاحيات","Could not load permissions"],
["التحويل بين الحسابات","Transfer between accounts"],
["مراكز التكلفة النشطة","Active cost centers"],
["جاري تسجيل الخروج...","Signing out..."],
["إرجاع لصلاحيات الدور","Reset to role permissions"],
["ربط الفاتورة بالجلسة","Link invoice to session"],
["اختبار المخزون الذكي","Smart inventory test"],
["لا توجد طلبات اعتماد","No approval requests"],
["منظومة إدارة الأعمال","Business management system"],
["اختار الفاتورة واضغط","Select the invoice and press"],
["التحقق الثنائي للأدمن","Admin two-factor verification"],
["إجمالي مستحق علينا","Total we owe them"],
["إجمالي مستحق لنا","Total they owe us"],
["جاري اختبار النظام...","Testing the system..."],
["تشغيل الاختبار الكامل","Run full test"],
["المستخدمون والصلاحيات","Users & permissions"],
["الملف لا يحتوي صفوفًا","The file contains no rows"],
["اتنزلت النسخة الكاملة","Full backup downloaded"],
["% من إجمالي الأصناف =","% of total items ="],
["اختبار Go-Live النهائي","Final Go-Live test"],
["العمر الإنتاجي بالشهور","Useful life in months"],
["النسخ الاحتياطي الكامل","Full backup"],
["لا توجد اختصارات متاحة","No shortcuts available"],
["لا توجد بيانات للتصدير","No data to export"],
["تشغيل الاختبار المتقدم","Run advanced test"],
["الملف ده مش نسخة كاملة","This file is not a full backup"],
["الحساب بانتظار التفعيل","Account awaiting activation"],
["يتم حفظ البيانات بأمان","Data is being saved securely"],
["جاري اختبار المخزون...","Testing inventory..."],
["لا توجد بيانات للطباعة","No data to print"],
["ابحث واختر الصنف أولاً","Search and select an item first"],
["إعدادات التحكم بالنظام","System control settings"],
["بيانات البند غير صحيحة","Item data is invalid"],
["هذه الصفحة للمطور فقط.","This page is for developers only."],
["رسالة SMS على الموبايل","SMS to mobile"],
["فحوصات الصحة وGo-Live.","Health checks & Go-Live."],
["السماح بالمخزون السالب","Allow negative stock"],
["جاري تجهيز الفاتورة...","Preparing invoice..."],
["فاتورة بيع بأصناف ودفع","Sales invoice with items & payment"],
["اختار ملف النسخة الأول","Select the backup file first"],
["Serials: واحد في كل سطر","Serials: one per line"],
["الملف مش نسخة ERP صحيحة","This file is not a valid ERP backup"],
["فاتورة شراء بأصناف ودفع","Purchase invoice with items & payment"],
["ابحث واختار الطرف أولاً","Search and select the party first"],
["لم يتم العثور على الكشف","Statement not found"],
["نجح فحص Go-Live النهائي","Final Go-Live check passed"],
["جارٍ إنهاء الجلسة بأمان","Ending the session securely"],
["استيراد وتصدير البيانات","Import & export data"],
["يوجد صنف آخر بنفس الاسم","Another item has the same name"],
["دون اتصال · وضع القراءة","Offline · Read-only mode"],
["لم يتم إجراء الفحص بعد.","The check has not been run yet."],
["أقصى خصم على الفاتورة %","Maximum invoice discount %"],
["لا يوجد جرد مفتوح الآن.","No stock count is open now."],
["فيه بيانات موجودة حالياً","There is existing data now"],
["اكتب \"استعادة\" عشان تأكد","Type \"restore\" to confirm"],
["النقد الفعلي عند الإغلاق","Actual cash at closing"],
["تم حفظ الصلاحيات المخصصة","Custom permissions saved"],
["نجح اختبار المخزون الذكي","Smart inventory test passed"],
["البنوك والتسويات البنكية","Banks & bank reconciliations"],
["كلمتا السر غير متطابقتين","The two passwords do not match"],
["الرصيد الافتتاحي للمخزون","Opening stock balance"],
["البيانات الأساسية للشركة","Company basic data"],
["اكتب الاسم أو رقم الهاتف","Type the name or phone number"],
["طباعة مصروفات هذا اليوم","Print today's expenses"],
["متقفلش الصفحة لحد ما تخلص","Don't close the page until it finishes"],
["لا توجد فواتير لهذا الطرف","No invoices for this party"],
["نجح اختبار النظام بالكامل","Full system test passed"],
["مطابقة حركة كشف مع مدفوعة","Match statement movement with payment"],
["النسخة الكاملة والاستعادة","Full backup & restore"],
["سجل التحويلات بين الحسابات","Transfers between accounts log"],
["لتتبع المصروفات حسب النشاط","To track expenses by activity"],
["جارٍ الاتصال بالنظام بأمان","Connecting to the system securely"],
["يظهر في الفواتير والتقارير","Appears on invoices and reports"],
["لم تُضف أصناف للتحويل بعد.","No items added to the transfer yet."],
["يبقى الفاتورة من غير بائع.","The invoice will have no seller."],
["هذه الصفحة للأدمن والمطور.","This page is for admins and developers."],
["حركات المخزون في نفس اليوم","Stock movements on the same day"],
["مثلاً: شكراً لتعاملكم معنا","E.g. Thank you for your business"],
["ادخل إلى لوحة إدارة الشركة","Go to the company admin panel"],
["لا توجد حركات في هذا اليوم","No movements on this day"],
["تم حفظ المرتجع. تطبعه الآن؟","Return saved. Print it now?"],
["أقصى خصم على الفاتورة لدورك","Maximum invoice discount for your role"],
["نفتح الموقع لكل المستخدمين؟","Open the site to all users?"],
["يتم تشغيل سيناريوهات الـERP","Running ERP scenarios"],
["المخزون ضمن الحدود الدنيا ","Stock is within minimum limits "],
["حذف نهائي؟ لا يمكن التراجع.","Delete permanently? This cannot be undone."],
["جاري فحص Go-Live النهائي...","Running final Go-Live check..."],
["بنفس تاريخ الفاتورة الأصلية","With the same date as the original invoice"],
["مراجعة العمليات والتغييرات.","Review of operations and changes."],
["اكتب الكود المكون من 6 أرقام","Type the 6-digit code"],
["لا توجد أطراف في هذا التبويب","No parties in this tab"],
["الباسورد غلط أو الملف اتعدّل","Wrong password or the file was modified"],
["إظهار العنوان والرقم الضريبي","Show address & tax number"],
["اختبار شامل بكل الـworkflows","Full test of all workflows"],
["MRP / اقتراحات إعادة التوريد","MRP / reorder suggestions"],
["الكمية لازم تكون أكبر من صفر","Quantity must be greater than zero"],
["تم التحقق، بس الجهاز متفكرش:","Verified, but the device was not remembered:"],
["جاري تجهيز النسخة الكاملة...","Preparing full backup..."],
["اختر الاختصارات اللي تظهر لك","Choose the shortcuts you want to see"],
["الحساب لسه متفعلش. كلم الأدمن","The account is not activated yet. Contact the admin"],
["جاري تشغيل الاختبار الشامل...","Running full test..."],
["ابحث باسم الصنف أو القائمة...","Search by item or list name..."],
["إيميل أو اسم مستخدم أو موبايل","Email, username or mobile"],
["اختبار التتبع وMRP والاستيراد","Tracking, MRP & import test"],
["الكود غلط أو منتهي، جرّب تاني","Wrong or expired code, try again"],
["التعديل هيلغي الفاتورة الأصلية","The edit will cancel the original invoice"],
["لا توجد بيانات للفترة الحالية.","No data for the current period."],
["بحث بالاسم أو الهاتف أو البريد","Search by name, phone or email"],
["الباسورد مش متطابق في الخانتين","The passwords do not match in both fields"],
["اسمح بالنوافذ المنبثقة للطباعة","Allow pop-ups to print"],
["المبيعات − التكلفة − المصروفات","Sales − cost − expenses"],
["قائمة الدخل / الأرباح والخسائر","Income statement / profit & loss"],
["التعديل بيلغي الفاتورة الأصلية","The edit cancels the original invoice"],
["يتم اختبار Batch / Serial / MRP","Testing Batch / Serial / MRP"],
["ابحث بالرقم أو الاسم أو التاريخ","Search by number, name or date"],
["لم يتم الحذف — تحقق من صلاحياتك","Not deleted — check your permissions"],
["بحث بالاسم أو الكود أو الباركود","Search by name, code or barcode"],
["إدارة طلبات الاعتماد والموافقات.","Manage approval requests and approvals."],
["التغيير بيظهر في أي طباعة جديدة.","The change appears on any new print."],
["أسعار البيع حسب القائمة والكمية.","Selling prices by list and quantity."],
["اسمح بالنوافذ المنبثقة عشان تطبع","Allow pop-ups so you can print"],
["جارٍ التحقق من صحة قاعدة البيانات","Verifying database integrity"],
["حركات قبل تسجيل الحركات في النظام","Movements before recording movements in the system"],
["الإجمالي قبل الضريبة/الخصم الكلي:","Total before tax / total discount:"],
["جاري تشغيل فحص Go-Live النهائي...","Running final Go-Live check..."],
["بيانات الفواتير والضريبة والمخزون","Invoice, tax and inventory data"],
["يُربط بشهر المرتب ويدخل في حسابه.","Linked to the payroll month and included in it."],
["تسجيل ومتابعة المصروفات التشغيلية.","Record and track operating expenses."],
["المركز المالي مع العملاء والموردين","Financial position with customers & suppliers"],
["اختار الفاتورة واضغط \"عرض البنود\".","Select the invoice and press \"View items\"."],
["فتح وإقفال الفترات ومراقبة القيود.","Open and close periods and monitor entries."],
["الموقع تحت الصيانة، جرّب بعد شوية.","The site is under maintenance. Try again shortly."],
["ابحث بالاسم أو النوع أو المستند...","Search by name, type or document..."],
["الباسورد لازم يكون 8 حروف على الأقل","The password must be at least 8 characters"],
["ابحث بالاسم أو الوظيفة أو الهاتف...","Search by name, job title or phone..."],
["الصورة لازم تكون PNG أو JPG أو WebP","The image must be PNG, JPG or WebP"],
["رسالة الصيانة اللي هتظهر للمستخدمين","Maintenance message shown to users"],
["اكتب البريد الإلكتروني وكلمة المرور","Enter email and password"],
["الإيميل أو اسم المستخدم أو الموبايل","Email, username or mobile"],
["اكتب كمية مرتجع لصنف واحد على الأقل","Enter a return quantity for at least one item"],
["متابعة المشاريع وتذاكر خدمة العملاء.","Track projects and customer service tickets."],
["لا توجد اقتراحات إعادة توريد حاليًا.","No reorder suggestions right now."],
["إدارة الاتصالات والتكاملات الخارجية.","Manage contacts and external integrations."],
["اكتب الكمية المرتجعة لكل صنف ثم احفظ","Enter the returned quantity for each item, then save"],
["كلمة السر لازم تكون 8 حروف على الأقل","The password must be at least 8 characters"],
["البريد الإلكتروني أو كلمة المرور غلط","Wrong email or password"],
["حجم اللوجو لازم يكون أقل من 512 كيلو","The logo must be smaller than 512 KB"],
["ابحث بالحساب أو المصدر أو المستخدم...","Search by account, source or user..."],
["جاري اختبار التتبع وMRP والاستيراد...","Testing tracking, MRP & import..."],
["اكتب الكمية المرتجعة لكل صنف، ثم احفظ","Enter the returned quantity for each item, then save"],
["بنفك التشفير ونتأكد من الداتا الحالية","Decrypting and verifying the current data"],
["يظهر في سجل الـHR ويُربط بشهر المرتب.","Appears in HR records and is linked to the payroll month."],
["ويعمل فاتورة جديدة بالبيانات المعدّلة","And creates a new invoice with the edited data"],
["إدارة الهيكل التنظيمي ومراكز التكلفة.","Manage the organization structure and cost centers."],
["الحسابات النقدية والتحويلات الداخلية.","Cash accounts and internal transfers."],
["إعدادات الطباعة لكل الكشوف والفواتير.","Print settings for all statements and invoices."],
["دفتر أستاذ، ميزان مراجعة وقيود يدوية.","General ledger, trial balance and manual entries."],
["ويعمل فاتورة جديدة بالبيانات المعدّلة.","And creates a new invoice with the edited data."],
["ابحث بالاسم أو رقم الهاتف، واضغط Enter","Search by name or phone number, then press Enter"],
["أضف تصنيف أصل الأول من تبويب التصنيفات","Add an asset category first from the Categories tab"],
["تعذر تحميل المكافآت والجزاءات المعتمدة","Could not load approved bonuses & penalties"],
["تُستخدم لتحديد حالة Holiday في الحضور.","Used to set the Holiday status in attendance."],
["اكتب الكود اللي في تطبيق Authenticator","Enter the code from the Authenticator app"],
["يتم اختبار الأمان والعمليات والتكاملات","Testing security, operations & integrations"],
["إضافة مخزن جديد وتعديل اسمه، أو تعطيله.","Add a new warehouse, edit its name, or disable it."],
["الحساب بيتفعّل فوراً بالدور اللي تختاره","The account is activated immediately with the role you choose"],
["شيكات قبض/دفع ومتابعة الاستحقاق والحالة.","Receipt/payment cheques and tracking of due dates and status."],
["الكمية الفعلية لازم تكون رقم صفر أو أكبر","The actual quantity must be zero or greater"],
["ممكن ياخد وقت لو ملفات الـ Storage كبيرة","This may take time if the Storage files are large"],
["الحسابات يتم تحميلها داخل شاشة الحسابات.","Accounts are loaded inside the accounts screen."],
["تم إرجاع المستخدم لصلاحيات الدور الأساسي","The user was reset to the primary role permissions"],
["مرتجع مرتبط بفاتورة، يُحفظ ويُطبع كمستند.","A return linked to an invoice, saved and printed as a document."],
["اختبار النظام قبل إدخال البيانات الحقيقية","System test before entering real data"],
["عمولات البائعين: القواعد، الحساب، والسجل.","Seller commissions: rules, calculation and log."],
["بيانات الموظف، ومن يملك حساب دخول للنظام.","Employee data and who has a system login."],
["تم تحميل المكافآت والجزاءات المعتمدة للشهر","Approved bonuses & penalties for the month were loaded"],
["CSV للبيانات الأساسية والأرصدة الافتتاحية.","CSV for basic data and opening balances."],
["لا يُسمح بتعديل فترة مقفولة إلا بعد فتحها.","A closed period cannot be edited until it is reopened."],
["تستخدم أيضًا لتحديد حالة Holiday في الحضور.","Also used to set the Holiday status in attendance."],
["تقارير تشغيلية ومالية من نفس مصدر البيانات.","Operational and financial reports from the same data source."],
["اسم الصنف أو الكود أو الباركود، واضغط Enter","Item name, code or barcode, then press Enter"],
["جارٍ التحقق من جلسة الدخول وتحميل الإعدادات","Verifying the session and loading settings"],
["بيانات الفواتير والضريبة والمخزون وحد الخصم.","Invoice, tax, inventory and discount limit data."],
["القائمة لوحدها. الإضافة والتعديل من النافذة.","The list alone. Add and edit from the window."],
["ابحث باسم الصنف أو المستخدم أو نوع الحركة...","Search by item, user or movement type..."],
["الداتا الحالية فاضية، الاستعادة هتتم مباشرة.","The current data is empty; the restore will run directly."],
["ابحث برقم التحويل أو اسم المخزن أو التاريخ...","Search by transfer number, warehouse name or date..."],
["سيتطلب الحساب تفعيل المدير قبل استخدام النظام.","The account needs admin activation before using the system."],
["الأبعاد التنظيمية التي تربط الحركات والتقارير.","Organizational dimensions linking movements and reports."],
["الجلسات اتقفلت، هنخرجك دلوقتي وتسجل دخول تاني.","Sessions were closed. You will be signed out now and need to sign in again."],
["يخلي كل المستخدمين يحملوا أحدث نسخة أوتوماتيك.","Makes all users load the latest version automatically."],
["الأبعاد التنظيمية اللي بتربط الحركات والتقارير.","Organizational dimensions linking movements and reports."],
["وارد / صادر / تسوية / تحويل مع الرصيد قبل وبعد.","In / out / adjustment / transfer with balance before and after."],
["الطرف بيتسجل مقبوضات ومدفوعات مع بعض، برصيد واحد صافي.","A party is recorded as both customer and supplier, with one net balance."],
["كل طرف عميل ومورد في نفس الوقت، برصيد صافي واحد.","Each party is both a customer and a supplier, with one net balance."],
["ابحث باسم المستخدم أو نوع العملية أو التفاصيل...","Search by user, operation type or details..."],
["كمية كل صنف في كل مخزن، وحالة التوفر وحدّ النقص.","Quantity of each item per warehouse, availability status and shortage limit."],
["اتسجل خروجك تلقائياً بسبب الخمول. سجّل دخول تاني.","You were signed out automatically due to inactivity. Please sign in again."],
["تسجيل الحضور والانصراف للأدمن بس. دي قراءة للسجل.","Check-in/out recording is for admins only. This is a read-only log."],
["تسجيل المقبوضات والمدفوعات وتخصيصها على الفواتير.","Record receipts and payments and allocate them to invoices."],
["انقطع الاتصال — يمكنك متابعة البيانات المخزنة فقط","Connection lost — you can only view stored data"],
["ابدأ جردًا لمخزن، أدخل الكميات الفعلية، ثم اعتمد.","Start a count for a warehouse, enter actual quantities, then approve."],
["مفيش اتصال بالسيرفر. اتأكد من الإنترنت وحاول تاني","No connection to the server. Check your internet and try again."],
["أضف الأصل من الزر، والإهلاك والاستبعاد من نفس الصف.","Add the asset with the button; depreciation and disposal are on the same row."],
["استلام المخزون يتم من أمر الشراء وبالكمية المتبقية.","Stock receipts are made from the purchase order for the remaining quantity."],
["يلغي الجهاز المتذكر، والدخول الجاي يطلب كود التحقق.","Revokes the remembered device; the next sign-in will ask for a verification code."],
["الاستعادة للمطور بس. اختار ملف النسخة واكتب باسورده.","Restore is for developers only. Choose the backup file and enter its password."],
["ابحث عن صنف بالاسم أو الكود أو الباركود، واضغط Enter","Search for an item by name, code or barcode, then press Enter"],
["الجرود السابقة — اضغط تفاصيل لعرض الأصناف والفروقات.","Previous counts — press Details to show items and differences."],
["اختار اللغة اللي تريحك. التغيير ده على الجهاز ده بس.","Choose the language you prefer. The change applies to this device only."],
["اقتناء، رسملة، إهلاك واستبعاد — مع القيود المحاسبية.","Acquisition, capitalization, depreciation and disposal — with accounting entries."],
["ابحث باسم الحساب أو المستخدم أو المبلغ أو التاريخ...","Search by account, user, amount or date..."],
["تعريف BOM، المكونات، أوامر التصنيع والتكلفة الفعلية.","BOM definition, components, manufacturing orders and actual cost."],
["اطلب البضاعة أولًا ثم استلمها ثم أصدر فاتورة المورد.","Order goods first, then receive them, then issue the supplier invoice."],
["لا تسمح للنظام بالتعديل على فترة مغلقة إلا بعد فتحها.","The system does not allow edits to a closed period until it is reopened."],
["أدوات المطور بس. كل تغيير هنا بيتسجل في سجل العمليات.","Developer tools only. Every change here is logged."],
["افصل حركة المخزون عن الفاتورة، واسمح بالتسليم الجزئي.","Separate stock movement from the invoice and allow partial delivery."],
["الأدمن بس. اختار الموظف والتاريخ، وبعدين الوقت لو معاك.","Admins only. Choose the employee and date, then the time if you have it."],
["كشوف البنك، حركاتها، ومطابقتها مع المقبوضات والمدفوعات.","Bank statements, their movements, and matching with receipts and payments."],
["اختار: فاتورة جديدة، أو الفواتير السابقة، أو المستحقات.","Choose: new invoice, previous invoices, or dues."],
["مراجعة واعتماد العمليات قبل ترحيلها أو حسب سياسة الشركة.","Review and approve operations before posting, per company policy."],
["إدخال كشوف البنك ومطابقة الحركات مع المقبوضات والمدفوعات.","Enter bank statements and match movements with receipts and payments."],
["الحسابات النقدية، التحويلات بينها، وحركة الخزينة اليومية.","Cash accounts, transfers between them, and daily cash movement."],
["هذه العملية تحتاج اتصالاً بالإنترنت — لم يتم تسجيل أي تغيير","This operation needs an internet connection — no change was recorded"],
["المصروف بيتسجل بتاريخ اليوم. الأيام السابقة للعرض والطباعة.","The expense is recorded with today's date. Past days are for viewing and printing."],
["حساب عمولات البائعين بناءً على صافي المبيعات أو هامش الربح.","Seller commissions calculated on net sales or profit margin."],
["حساب عمولات البائعين بناءً على صافي المبيعات أو مجمل الربح.","Seller commissions calculated on net sales or gross profit."],
["نسيت الجهاز ده؟ الدخول الجاي من الجهاز ده هيطلب كود التحقق.","Forgot this device? The next sign-in from this device will ask for a verification code."],
["كل أدوات الإدارة في مكان واحد، والقائمة الجانبية تظل مختصرة.","All admin tools in one place, with a shorter side menu."],
["قفل الموقع وفتحه، خروج كل الجلسات، تحديث الواجهة، والفحوصات.","Lock/unlock the site, sign out all sessions, refresh the interface, and checks."],
["نبعت تحديث لكل المستخدمين؟ أي حد فاتح النظام هيتحدث أوتوماتيك.","Send an update to all users? Anyone with the system open will update automatically."],
["تسجيل المصروف يتم بتاريخ اليوم. الأيام السابقة للعرض والطباعة.","The expense is recorded with today's date. Past days are for viewing and printing."],
["الملف بيتشفّر بالباسورد اللي تكتبه. لو نسيته، الملف مش هيتفتح.","The file is encrypted with the password you enter. If you forget it, the file cannot be opened."],
["إنشاء المستخدمين، تفعيلهم، واختيار تخصيص الصلاحيات لكل مستخدم.","Create users, activate them, and customize permissions for each user."],
["اللوجو واسم الشركة والعنوان ولون الخط الفاصل ونص أسفل الطباعة.","Logo, company name, address, divider color, and print footer text."],
["لا يمكن حذف هذا العميل لوجود فواتير أو حركات مرتبطة به — استخدم","This customer cannot be deleted because it has linked invoices or movements — use"],
["حفظ على الحساب/آجل — صلاحية الدفع المباشر غير متاحة لهذا الدور.","Save on account/credit — direct payment is not available for this role."],
["استيراد CSV للبيانات الأساسية وتصدير نسخة قابلة للفتح في Excel.","Import CSV for basic data and export a copy that opens in Excel."],
["عرض فقط — إضافة الأصناف وتعديلها متاحة للإدارة والمحاسب والمخزن.","View only — adding and editing items is available to management, accountants and warehouse staff."],
["نسجّل خروج كل المستخدمين؟ حسابك كمان هيتقفل ولازم تسجل دخول تاني.","Sign out all users? Your account will also be locked and you will need to sign in again."],
["الحضور والإجازات والمكافآت والجزاءات والعطلات — كل قسم في تبويبه.","Attendance, leave, bonuses, penalties and holidays — each section in its tab."],
["الدور الأساسي يحدد الحد الأعلى، والتخصيص يختار ما يظهر لكل مستخدم.","The primary role sets the maximum, and customization chooses what each user sees."],
["اختبار شامل قبل Go-Live. الاختبار ينشئ بيانات مؤقتة ويقوم بتنظيفها.","Full test before Go-Live. The test creates temporary data and cleans it up."],
["الفاتورة تُحفظ آجلة على الحساب، والدفع المباشر غير متاح لهذا الدور.","The invoice is saved on credit to the account; direct payment is not available for this role."],
["يعيد جلب المكافآت والجزاءات والسلف المعتمدة لهذا الموظف في هذا الشهر","Reloads the approved bonuses, penalties and advances for this employee this month"],
["الافتتاحي = الرصيد أول اليوم، والختامي = الرصيد اللي اتقفل بيه اليوم","Opening = balance at the start of the day; closing = the balance locked at end of day"],
["يوجد صنف بنفس الاسم بالفعل — عدّل الصنف الموجود بدل إضافة نسخة جديدة","An item with this name already exists — edit it instead of adding a duplicate"],
["كل عملية مسجلة باسم المستخدم والوقت. الأيام السابقة مقفولة للمراجعة.","Every operation is logged with the user and time. Past days are locked for review."],
["أدخل الاسم واسم المستخدم والإيميل والموبايل وكلمة سر 8 حروف على الأقل","Enter name, username, email, mobile and a password of at least 8 characters"],
["اليوم الحالي مفتوح ويتسجل فيه. أي يوم قبله مقفول: للعرض والطباعة فقط.","Today is open for recording. Any earlier day is locked: for viewing and printing only."],
["الدور الأساسي يحدد الحد الأعلى، والتخصيص يختار ما يظهر لهذا المستخدم.","The primary role sets the maximum, and customization chooses what this user sees."],
["أسعار بيع حسب العميل والكمية — مع إمكانية تخصيص قائمة افتراضية للعميل.","Selling prices by customer and quantity — with the option to assign a default list to the customer."],
["الحساب الأول في المشروع الجديد يُنشأ كمدير حسب إعدادات قاعدة البيانات.","The first account in the new project is created as admin according to the database settings."],
["يمكن ترك الفاتورة فارغة ليصبح المبلغ رصيدًا غير مخصص، ثم تخصيصه لاحقًا.","You can leave the invoice empty so the amount becomes unallocated balance, then allocate it later."],
["الحضور والغياب والإجازات والعطلات والمكافآت والجزاءات والربط مع الرواتب.","Attendance, absence, leave, holidays, bonuses, penalties and payroll linkage."],
["يفحص التوازن المحاسبي، السالب بالمخزون، الباركودات، الفترات والاعتمادات.","Checks accounting balance, negative stock, barcodes, periods and approvals."],
["نفعّل إجبار التحقق الثنائي؟ الأدمن اللي مش مفعّله مش هيقدر يوصل للبيانات.","Enable mandatory two-factor verification? Admins without it will not be able to access the data."],
["جلسات كاشير ومتابعة الإغلاق. الفاتورة نفسها تظل جزءًا من النظام المحاسبي.","Cashier sessions and closing tracking. The invoice itself remains part of the accounting system."],
["ابحث عن صنف فوق وهيتضاف هنا. تقدر تعدّل الكمية والسعر والخصم في نفس السطر.","Search for an item above and it will be added here. You can edit quantity, price and discount on the same line."],
["إنشاء مرتجع لفاتورة مبيعات أو مشتريات، ومتابعة المرتجعات السابقة وطباعتها.","Create a return for a sales or purchase invoice, and track and print previous returns."],
["بيتطبق على دور المبيعات كنسبة من إجمالي الأصناف. الأدمن والمحاسب مالهمش حد.","Applied to the sales role as a percentage of total items. Admins and accountants have no limit."],
["القائمة مختصرة. الإدارة والاستيراد والنسخ الاحتياطي والصلاحيات داخل الإعدادات.","The menu is short. Administration, import, backup and permissions are inside Settings."],
["اسم الشركة والرقم الضريبي وبادئة الفواتير والضريبة والمخزون وحد الخصم واللوجو.","Company name, tax number, invoice prefix, tax, inventory, discount limit and logo."],
["كل سطر: الفاتورة، وبائعها اللي العمولة ليه، والقاعدة المستخدمة، والمبلغ. لو ظهر","Each line: the invoice, its seller who gets the commission, the rule used, and the amount. If it shows"],
["الإعدادات دي بتتطبق على كل تصاميم الطباعة: الكشوف والمرتبات والتحويلات والفواتير.","These settings apply to all print designs: statements, payslips, transfers and invoices."],
["اللوجو بيظهر في الفواتير والمرتجعات والطباعة. PNG أو JPG أو WebP أقل من 512 كيلو.","The logo appears on invoices, returns and prints. PNG, JPG or WebP under 512 KB."],
["اليوم الحالي مفتوح وبيتسجل فيه. أي يوم قبله مقفول: بيتعرض للمراجعة بس ومش بيتعدّل.","Today is open for recording. Any earlier day is locked: it can only be reviewed, not edited."],
["التقدير بيحسب بالسعر قبل الضريبة والخصم. القيمة النهائية بتتحسب على السيرفر عند الحفظ.","The estimate is calculated before tax and discount. The final value is calculated on the server on save."],
["إدارة Batch / Serial / Expiry ومقترحات إعادة التوريد بناءً على المخزون والطلبات المفتوحة.","Batch / Serial / Expiry management and reorder suggestions based on stock and open orders."],
["الأعمدة الأساسية: name, phone, email, address, payment_terms_days, opening_balance, notes.","Required columns: name, phone, email, address, payment_terms_days, opening_balance, notes."],
["الاستعادة هتمسح كل ده وتكتب النسخة مكانه. هنعمل نسخة أمان من الحالية الأول وتتنزل على جهازك.","Restore will erase all of this and write the backup in its place. A safety copy of the current data will be made first and downloaded to your device."],
["حالة تجهيز وإرسال المستندات. التكامل الرسمي مع الجهة الضريبية يحتاج بيانات اعتماد/API حقيقية.","Document preparation and sending status. Official tax-authority integration requires real credentials/API."],
["استخدم code أو barcode و qty. سيتم تطبيق الكميات على المخزن المختار من خلال حركة رصيد افتتاحي.","Use code or barcode and qty. Quantities will be applied to the selected warehouse through an opening balance movement."],
["اختار الطرق اللي تتقبل للتحقق. حالياً التطبيق بيدعم Authenticator بس، والباقي يتفتح لما نربط مزوّد له.","Choose the verification methods you accept. Currently only Authenticator is supported; others open once a provider is connected."],
["الأعمدة الأساسية: name, phone, email, address, credit_limit, payment_terms_days, opening_balance, notes.","Required columns: name, phone, email, address, credit_limit, payment_terms_days, opening_balance, notes."],
["أكيد؟ الاستعادة هتكتب فوق البيانات الحالية. كل المستخدمين هيتقفلوا، ولازم كل حد يسجل دخول تاني بالباسورد من النسخة.","Are you sure? Restore will overwrite the current data. All users will be locked out and must sign in again with the password from the backup."],
["الرصيد الافتتاحي = الكمية الموجودة فعلًا في المخزن المختار وقت بدء استخدام النظام لهذا الصنف. يُسجَّل مرة واحدة فقط.","Opening balance = the quantity actually in the selected warehouse when you start using the system for this item. Recorded only once."],
["كل سطر: الفاتورة، وبائعها اللي العمولة ليه، والقاعدة المستخدمة، والمبلغ. لو ظهر \"غير محدد\" يبقى الفاتورة من غير بائع.","Each line: the invoice, its seller who gets the commission, the rule used, and the amount. If it shows \"Not specified\", the invoice has no seller."],
["ابدأ بتصدير نسخة احتياطية، ثم استورد الأصناف/العملاء/الموردين، ثم أدخل الأرصدة الافتتاحية، وبعدها ابدأ الحركات اليومية.","Start by exporting a backup, then import items/customers/suppliers, then enter opening balances, then start daily operations."],
["طبقة موحدة لتتبع Shopify / WooCommerce / Salla / Magento / Custom. لا يتم إرسال بيانات خارجية تلقائيًا قبل ضبط الاتصال.","A unified layer for Shopify / WooCommerce / Salla / Magento / Custom. No external data is sent automatically before the connection is configured."],
["نسخة كاملة تتنزل على جهازك: كل البيانات والإعدادات والمستخدمين وباسوردتهم وملفات الموقع. مستقلة عن النسخة اليومية على Google Drive.","A full copy downloaded to your device: all data, settings, users and their passwords, and site files. Independent of the daily Google Drive backup."],
["ينشئ بيانات TEST مؤقتة، يختبر البيع والشراء والضريبة والمدفوعات والمرتجعات والتحويل والجرد واليومية والتقارير، ثم ينظف كل بيانات الاختبار تلقائيًا.","Creates temporary TEST data, tests sales, purchases, tax, payments, returns, transfers, stock count, journal and reports, then cleans up all test data automatically."],
["الأعمدة الأساسية: name, code, barcode, category, unit, purchase_price, sale_price, wholesale_price, min_stock, reorder_qty, safety_stock, lead_time_days, notes.","Required columns: name, code, barcode, category, unit, purchase_price, sale_price, wholesale_price, min_stock, reorder_qty, safety_stock, lead_time_days, notes."],
["الرصيد الافتتاحي = الكمية الموجودة فعلًا في المخزن المختار وقت بدء استخدام النظام لهذا الصنف. يُسجَّل مرة واحدة فقط؛ بعد ذلك استخدم فاتورة الشراء أو تسوية الجرد لأي تغيير.","Opening balance = the quantity actually in the selected warehouse when you start using the system for this item. Recorded only once; after that, use a purchase invoice or stock adjustment for any change."],
["اختر الموظف والشهر وستُحمَّل المكافآت والجزاءات المعتمدة تلقائيًا، ويمكن تعديل القيم قبل إنشاء الكشف. زر «جلب المعتمد للشهر» لإعادة التحميل فقط. الكشوف المنشأة تظهر في الجدول بالأسفل، ومن عمود الإجراءات: عرض، طباعة، دفع.","Choose the employee and month; approved bonuses and penalties load automatically, and values can be edited before creating the statement. The \"Fetch approved for month\" button only reloads. Created statements appear in the table below; from the actions column: view, print, pay."]
["مرحبًا بيك","Welcome"],
["ادخل ببريدك الإلكتروني أو اسم المستخدم أو رقم الموبايل.","Sign in with your email, username or mobile number."],
["كل أعمال شركتك في مكان واحد","All your company's operations in one place"],
["مبيعات ومشتريات ومخزون ومحاسبة وموارد بشرية، بصلاحيات دقيقة وتحقق ثنائي للإدارة.","Sales, purchases, inventory, accounting and HR, with precise permissions and two-factor verification for admins."],
["فواتير مبيعات ومشتريات بترقيم مستقل","Sales and purchase invoices with separate numbering"],
["مخزون متعدد المخازن مع تتبع وتنبيهات","Multi-warehouse inventory with tracking and alerts"],
["تقارير مالية وميزان مراجعة لحظي","Financial reports and a live trial balance"],
["حماية بالتحقق الثنائي والجهاز الموثوق","Protected by two-factor verification and trusted devices"],
["إظهار","Show"],
["إخفاء","Hide"],
["أو إخفاء كلمة المرور","or hide the password"],
["الاتصال مشفّر.","The connection is encrypted."],
["حسابك جاهز تقريبًا","Almost there"],
["خطوة واحدة متبقية","One step left"],
["المخزون السليم","Healthy stock"],
["مخزون سليم","Healthy stock"],
["نظرة سريعة على أداء النشاط","A quick look at business performance"]
["الفريق والصلاحيات","Team & permissions"],
["البيانات والنسخ","Data & backups"],
["حسابي","My account"],
["اللغة:","Language:"],
["اضغط عشان تبدّل بين العامية المصرية والفصحى والإنجليزي (على الجهاز ده).","Tap to switch between Egyptian colloquial, formal Arabic and English (on this device)."],
["نسخة كاملة تتنزل على جهازك (كل البيانات والمستخدمين والملفات)، واستعادتها.","Full backup downloaded to your device (all data, users and files), and restore."],
["كل أدوات الإدارة في مكان واحد.","All admin tools in one place."]];
EN_PAIRS.push(["مقبوضات","Receipts"],["مدفوعات","Payments"],["مقبوض","Received"],["مدفوع","Paid"],["التسليم","Delivery"],["المساهمون","Shareholders"],["الأرباح بالتفاصيل","Profit details"],["الموازنة والفعلي","Budget vs actual"],["الفاتورة (اختياري)","Invoice (optional)"],["دفعة على الحساب (بدون تخصيص)","Payment on account (no allocation)"],["عامية","Colloquial"],["فصحى","Formal"]);
EN_PAIRS=EN_PAIRS.filter(p=>Array.isArray(p)&&typeof p[0]==="string"&&typeof p[1]==="string"&&p[0]);
EN_PAIRS.sort((a,b)=>b[0].length-a[0].length);

function langSeg(){const m=dialectMode();const b=(k,l,t)=>`<button type="button" class="${m===k?'on':''}" title="${t}" aria-pressed="${m===k}" onclick="setDialect('${k}')">${l}</button>`;return `<div class="lang-seg" role="group" aria-label="اللغة">${b('eg','عامية','لغة عامية')}${b('msa','فصحى','العربية الفصحى')}${b('en','EN','English')}</div>`}
function dialectMode(){try{return localStorage.getItem('erp_dialect')||'eg'}catch{return 'eg'}}
// ترجمة نص واحد حسب الأسلوب المختار
function dx(s){
  if(typeof s!=='string')return s;
  if(dialectMode()==='en'){let o=s;for(const [ar,en] of EN_PAIRS){if(o.includes(ar))o=o.split(ar).join(en)}return o}
  const msa=dialectMode()==='msa';
  let out=s;
  for(const [eg,ms] of DX_PAIRS){
    const from=msa?eg:ms, to=msa?ms:eg;
    if(from!==to&&out.includes(from))out=out.split(from).join(to);
  }
  return out;
}
function applyDialect(root){
  if(!root)return;
  const w=document.createTreeWalker(root,NodeFilter.SHOW_TEXT,{acceptNode:t=>{const p=t.parentNode;return p&&!/^(SCRIPT|STYLE|TEXTAREA|CODE)$/.test(p.nodeName)?NodeFilter.FILTER_ACCEPT:NodeFilter.FILTER_REJECT}});
  const nodes=[];let n;while((n=w.nextNode()))nodes.push(n);
  for(const t of nodes){
    if(t.__orig===undefined)t.__orig=t.nodeValue;
    const out=dx(t.__orig);
    if(t.nodeValue!==out)t.nodeValue=out;
  }
  root.querySelectorAll?.('[placeholder],[title],[aria-label]').forEach(el=>{
    for(const at of ['placeholder','title','aria-label']){
      if(!el.hasAttribute(at))continue;
      const k='__o_'+at;if(el[k]===undefined)el[k]=el.getAttribute(at);
      const out=dx(el[k]);if(el.getAttribute(at)!==out)el.setAttribute(at,out);
    }
  });
}
function setDialect(x){try{localStorage.setItem('erp_dialect',x)}catch{}document.querySelectorAll('.lang-seg button').forEach(b=>{const on=b.getAttribute('onclick')?.includes("'"+x+"'");b.classList.toggle('on',!!on);b.setAttribute('aria-pressed',String(!!on))});applyDialect(document.body);document.documentElement.lang=x==='en'?'en':'ar';if(me)R()}
function toggleDialect(){
  const cur=dialectMode();
  const opts=[['eg','عامية مصرية'],['msa','فصحى'],['en','English']];
  formModal('اللغة وأسلوب الكلام',
    `<div class="fm-f"><span>اختار اللغة اللي تريحك. التغيير ده على الجهاز ده بس.</span>${opts.map(([k,l])=>`<label style="display:block;margin:8px 0"><input type="radio" name="lang" value="${k}" ${cur===k?'checked':''}> ${l}</label>`).join('')}</div>`,
    async()=>{
      const x=document.querySelector('input[name=lang]:checked')?.value||'eg';
      setDialect(x);
    },'حفظ');
}
// الرسايل المنبثقة والتوست بتتترجم كمان
const _toastDx=toast;
toast=function(m){return _toastDx(dx(m))};
const _alertDx=window.alert.bind(window);
window.alert=function(m){return _alertDx(dx(String(m)))};
(function(){
  const app=document.getElementById('app');
  if(!app)return;
  let queued=false;
  new MutationObserver(()=>{if(queued)return;queued=true;requestAnimationFrame(()=>{queued=false;applyDialect(document.body)})}).observe(document.body,{childList:true,subtree:true});
})();

// ===== v1.57 =====
// ---- الحضور: الأدمن بس يسجل (يوم + وقت حضور/انصراف) ----
async function attSave(){
  const d=v('hd');
  if(!v('he'))return alert('اختار الموظف');
  if(!d)return alert('اختار التاريخ');
  const toIso=t=>t?new Date(d+'T'+t).toISOString():null;
  const row={employee_id:v('he'),work_date:d,status:v('hs')||'Present'};
  if(toIso(v('hi')))row.check_in=toIso(v('hi'));
  if(toIso(v('ho')))row.check_out=toIso(v('ho'));
  await act(async()=>{const{error}=await sb.from('attendance').upsert(row,{onConflict:'employee_id,work_date'});if(error)throw error});
}

// ---- تخصيص الطباعة (الأدمن والمطور من الويب) ----
const PRINT_DEFAULTS={showLogo:true,showName:true,showAddress:true,logoMaxH:60,accent:'#095F4A',footer:'',vendorName:'GHONIMX Technologies',vendorUrl:'',vendorLogo:true,paperSize:'A4',marginMm:14,fontPx:13,headerAlign:'start',showSignatures:true,showNotes:true};
const POWERED_BY_TEXT='Powered by GHONIMX Technologies';
function pcJustify(c){return c.headerAlign==='center'?'center':(c.headerAlign==='end'?'flex-start':'space-between')}
// رصيد مزوّد النظام أسفل الطباعة (اسم + موقع + لوجو النظام)، قابل للتخصيص من تخصيص الطباعة
function vendorCreditHtml(){const c=printCfg();if(!c.vendorName&&!c.vendorUrl&&!c.vendorLogo)return '';
  const logo=c.vendorLogo?`<img src="${e(new URL('brand/fedo-logo-light.svg',location.href).href)}" alt="" style="height:16px;vertical-align:middle;margin-inline-end:6px">`:'';
  const name=c.vendorName?`Powered by <b>${e(c.vendorName)}</b>`:'';
  const url=c.vendorUrl?`${name?' · ':''}<span dir="ltr">${e(c.vendorUrl)}</span>`:'';
  return `<div class="vendor-credit" style="margin-top:14px;padding-top:8px;border-top:1px solid #E3E0D4;color:#5B6878;font-size:11px;text-align:center">${logo}${name}${url}</div>`}
function printCfg(){const s=(window._co&&window._co.print_settings)||{};return Object.assign({},PRINT_DEFAULTS,s)}
function printCardHtml(){
  if(!me||me.role!=='admin')return '';
  const c=printCfg();
  const chk=(id,on,lbl)=>`<label class="co-switch"><input type="checkbox" id="${id}" ${on?'checked':''}><span><b>${lbl}</b></span></label>`;
  const sel=(id,opts,cur)=>`<select id="${id}">${opts.map(([v,l])=>`<option value="${v}" ${String(cur)===v?'selected':''}>${l}</option>`).join('')}</select>`;
  return `<div class="card co-card"><div class="co-sec"><h4>تخصيص الطباعة</h4>
    <p class="muted" style="margin:0 0 12px">الإعدادات دي بتتطبق على كل تصاميم الطباعة: الكشوف والمرتبات والتحويلات والفواتير.</p>
    <h5 class="pc-h">1) الهيدر والهوية</h5>
    <div class="co-switches">${chk('pc_logo',c.showLogo,'إظهار لوجو الشركة')}${chk('pc_name',c.showName,'إظهار اسم الشركة')}${chk('pc_addr',c.showAddress,'إظهار العنوان والرقم الضريبي')}</div>
    <div class="fm-grid">
      <label class="fm-f"><span>حجم اللوجو (بكسل)</span><input id="pc_h" type="number" min="20" max="160" value="${e(c.logoMaxH)}"></label>
      <label class="fm-f"><span>محاذاة الهيدر</span>${sel('pc_align',[['start','يمين (بداية)'],['center','وسط'],['end','يسار (نهاية)']],c.headerAlign)}</label>
      <label class="fm-f"><span>لون الخط الفاصل والعناوين</span><input id="pc_acc" type="color" value="${e(c.accent)}" style="min-height:42px;padding:4px"></label>
    </div>
    <h5 class="pc-h">2) الصفحة والخط</h5>
    <div class="fm-grid">
      <label class="fm-f"><span>حجم الورقة</span>${sel('pc_paper',[['A4','A4'],['A5','A5'],['Letter','Letter']],c.paperSize)}</label>
      <label class="fm-f"><span>الهوامش (ملم)</span><input id="pc_margin" type="number" min="5" max="30" value="${e(c.marginMm)}"></label>
      <label class="fm-f"><span>حجم الخط</span>${sel('pc_font',[['11','صغير (11)'],['13','عادي (13)'],['15','كبير (15)']],c.fontPx)}</label>
    </div>
    <h5 class="pc-h">3) المحتوى والتذييل</h5>
    <div class="co-switches">${chk('pc_notes',c.showNotes,'إظهار الملاحظات')}${chk('pc_sign',c.showSignatures,'إظهار خانات التوقيع')}${chk('pc_vlogo',c.vendorLogo,'إظهار لوجو النظام أسفل الطباعة')}</div>
    <div class="fm-grid">
      <label class="fm-f"><span>نص أسفل الطباعة</span><input id="pc_foot" value="${e(c.footer)}" placeholder="مثلاً: شكراً لتعاملكم معنا"></label>
      <label class="fm-f"><span>اسم صاحب النظام (Powered by)</span><input id="pc_vname" value="${e(c.vendorName)}" placeholder="مثلاً: GHONIMX Technologies أو اسمك"></label>
      <label class="fm-f"><span>موقع أو رابط (اختياري)</span><input id="pc_vurl" value="${e(c.vendorUrl)}" placeholder="example.com" dir="ltr"></label>
    </div>
    <div class="co-foot"><small class="muted">التغيير بيظهر في أي طباعة جديدة.</small><button onclick="savePrintCfg()">حفظ تخصيص الطباعة</button></div></div></div>`;
}
async function savePrintCfg(){
  const cfg={showLogo:$('#pc_logo').checked,showName:$('#pc_name').checked,showAddress:$('#pc_addr').checked,
    logoMaxH:Math.max(20,Math.min(160,parseInt(v('pc_h'))||60)),accent:v('pc_acc')||'#095F4A',footer:v('pc_foot')||'',
    vendorName:v('pc_vname')||'',vendorUrl:v('pc_vurl')||'',vendorLogo:$('#pc_vlogo').checked,
    paperSize:v('pc_paper')||'A4',marginMm:Math.max(5,Math.min(30,parseInt(v('pc_margin'))||14)),fontPx:parseInt(v('pc_font'))||13,
    headerAlign:v('pc_align')||'start',showSignatures:$('#pc_sign').checked,showNotes:$('#pc_notes').checked};
  await act(async()=>{await upd('company_settings',1,{print_settings:cfg});await refreshCo()});
}

// ---- مسح الملفات المخزنة محلياً عند الدخول والخروج ----
async function clearLocalData(){
  let dial=null,trust=null;try{dial=localStorage.getItem('erp_dialect');trust=localStorage.getItem(TRUST_KEY)}catch{}
  try{if(window.caches){const ks=await caches.keys();await Promise.all(ks.map(k=>caches.delete(k)))}}catch{}
  try{sessionStorage.clear()}catch{}
  try{localStorage.clear()}catch{}
  try{if(dial)localStorage.setItem('erp_dialect',dial)}catch{}
  try{if(trust)localStorage.setItem(TRUST_KEY,trust)}catch{}
}
const _login157=login;
login=async function(){await clearLocalData();return _login157()};
const _logout157=logout;
logout=async function(){const r=await _logout157();await clearLocalData();return r};


/* v1.90: زرار Excel موحد على كل الكروت اللي فيها جداول (بدل ما يتكتب في كل صفحة لوحدها) */
function addXlButtons(){
  document.querySelectorAll('.page .card').forEach(c=>{
    if(c.dataset.xl||c.classList.contains('form-card')||c.classList.contains('np')||c.classList.contains('report-cards'))return;
    if(!c.querySelector('table'))return;
    const t=c.querySelector('.card-title');
    if(!t||t.querySelector('.xl-btn')||c.querySelector('button[onclick="exportCard(this)"]'))return;
    c.dataset.xl='1';
    t.insertAdjacentHTML('beforeend','<button type="button" class="btn soft sm xl-btn" onclick="exportCard(this)">'+ico('save')+' Excel</button>');
  });
}
document.addEventListener('DOMContentLoaded',()=>{
  const app=document.getElementById('app');if(!app)return;
  let tm=null;
  new MutationObserver(()=>{clearTimeout(tm);tm=setTimeout(addXlButtons,120)}).observe(app,{childList:true,subtree:true});
});
